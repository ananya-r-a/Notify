"""Application wiring: builds every component from a config file."""

from __future__ import annotations

import logging
import logging.handlers
import sys
from dataclasses import dataclass

from .config import Config, load_config
from .db import Database
from .engine import Engine
from .httpclient import HttpClient
from .matching import Matcher
from .notify import NotificationService, build_notifiers
from .pipeline import Pipeline
from .sources import Source, build_sources
from .util import RedactingFormatter


@dataclass
class App:
    """Bundle of the fully wired components."""

    cfg: Config
    db: Database
    http: HttpClient
    sources: list[Source]
    matcher: Matcher
    pipeline: Pipeline
    notifier: NotificationService
    engine: Engine


def setup_logging(cfg: Config, verbose: bool = False) -> None:
    """Console + rotating file logging; every line passes through the secret redactor."""
    fmt = RedactingFormatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    for h in list(root.handlers):
        root.removeHandler(h)
    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(fmt)
    root.addHandler(console)
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    fileh = logging.handlers.RotatingFileHandler(cfg.log_path, maxBytes=5_000_000, backupCount=3, encoding="utf-8")
    fileh.setFormatter(fmt)
    root.addHandler(fileh)
    logging.getLogger("urllib3").setLevel(logging.WARNING)  # request URLs may embed tokens
    logging.getLogger("werkzeug").setLevel(logging.WARNING)


def build_http(cfg: Config, db: Database | None) -> HttpClient:
    h = cfg.http
    return HttpClient(
        user_agent=h["user_agent"], timeout=float(h["timeout"]), max_retries=int(h["max_retries"]),
        backoff_base=float(h["backoff_base"]), backoff_max=float(h["backoff_max"]),
        min_host_interval=float(h["min_host_interval"]), respect_robots=bool(h["respect_robots"]), db=db,
    )


def build_app(config_path: str = "config.yaml") -> App:
    """Load configuration and construct all components (raises ``ConfigError`` on bad config)."""
    cfg = load_config(config_path)
    db = Database(cfg.db_path)
    http = build_http(cfg, db)
    sources = build_sources(cfg.sources, http, min_interval=int(cfg.engine["min_interval"]))
    matcher = Matcher(cfg.prefs)
    pipeline = Pipeline(db, matcher, cfg.engine)
    notifiers = build_notifiers(cfg.notifications)
    notifier = NotificationService(
        db, notifiers, cfg.notifications["routing"],
        whatsapp_only_priority=bool(cfg.notifications.get("whatsapp", {}).get("only_priority", True)),
    )
    engine = Engine(cfg, db, sources, pipeline, notifier)
    return App(cfg, db, http, sources, matcher, pipeline, notifier, engine)
