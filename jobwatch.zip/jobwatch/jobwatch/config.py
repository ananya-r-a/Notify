"""Configuration loading, defaults, ``${ENV}`` interpolation and validation."""

from __future__ import annotations

import copy
import logging
import os
import re
from dataclasses import dataclass, field
from datetime import tzinfo
from pathlib import Path
from typing import Any

import yaml

from .util import get_timezone


log = logging.getLogger(__name__)


class ConfigError(Exception):
    """Raised for invalid or unreadable configuration."""


# --------------------------------------------------------------------------- defaults

DEFAULT_ROLES_INCLUDE = [
    "software", "developer", "programmer", "sde", "swe", "backend", "back-end", "back end", "frontend", "front-end",
    "front end", "full stack", "full-stack", "fullstack", "web developer", "mobile developer", "android", "ios",
    "devops", "sre", "site reliability", "cloud engineer", "cloud architect", "platform engineer", "infrastructure engineer",
    "data engineer", "data scientist", "machine learning", "ml engineer", "ai engineer", "deep learning", "nlp",
    "computer vision", "applied scientist", "research engineer", "research scientist", "r&d", "research and development",
    "embedded", "firmware", "fpga", "asic", "rtl", "vlsi", "design verification", "physical design", "silicon",
    "autosar", "adas", "automotive software", "systems engineer", "qa engineer", "sdet", "test automation",
    "quality engineer", "security engineer", "cybersecurity", "application security", "solutions architect",
    "software architect", "technical lead", "engineering manager", "scientist", "computer science",
]
DEFAULT_ROLES_EXCLUDE = [
    "sales", "recruiter", "talent acquisition", "marketing", "accountant", "content writer", "payroll",
    "receptionist", "customer support", "telecaller", "business development",
]

DEFAULTS: dict[str, Any] = {
    "timezone": "Asia/Kolkata",
    "data_dir": "data",
    "preferences": {
        "locations": ["bengaluru", "bangalore", "bengaluru urban", "bangalore urban", "bengalooru"],
        "include_remote_india": True,
        "allow_unknown_location": False,
        "roles": {"priority": [], "include": DEFAULT_ROLES_INCLUDE, "exclude": DEFAULT_ROLES_EXCLUDE},
        "skills": {"core": [], "nice": []},
        "keywords": {"include": [], "exclude": []},
        "experience": {"my_years": None, "min": None, "max": None, "unknown": "allow"},
        "work_modes": [],
        "employment_types": [],
        "salary_min_lpa": None,
        "max_age_days": 45,
        "exclude_companies": [],
        "priority_companies": [],
        "min_score": 35,
        "priority_score": 70,
        "weights": {
            "title": 30, "skills": 30, "experience": 15, "location": 10, "recency": 5, "salary": 5, "company": 5,
        },
    },
    "engine": {
        "workers": 6,
        "min_interval": 60,
        "default_interval": 300,
        "jitter": 0.1,
        "max_backoff": 3600,
        "expire_after_misses": 3,
        "store_rejected": True,
        "first_run": "summary",  # summary | silent | notify
        "first_run_summary_top": 15,
        "max_individual_per_flush": 10,
        "max_notify_attempts": 12,
        "fail_alert_threshold": 5,
        "notify_updates": False,
        "digest_time": "09:00",
        "dead_source_after_404": 3,
    },
    "http": {
        "timeout": 20,
        "max_retries": 4,
        "backoff_base": 1.5,
        "backoff_max": 60,
        "min_host_interval": 1.0,
        "respect_robots": True,
        "user_agent": "JobWatch/1.0 (+personal job monitor; polite polling)",
    },
    "notifications": {
        "routing": {
            "job": ["telegram", "ntfy", "desktop", "email"],
            "priority": ["telegram", "ntfy", "desktop", "email", "whatsapp"],
            "digest": ["email", "telegram"],
            "system": ["email", "telegram"],
        },
        "telegram": {
            "enabled": False,
            "bot_token": "${TELEGRAM_BOT_TOKEN}",
            "chat_id": "${TELEGRAM_CHAT_ID}",
            "api_base": "https://api.telegram.org",
        },
        "email": {
            "enabled": False,
            "host": "${SMTP_HOST:-smtp.gmail.com}",
            "port": "${SMTP_PORT:-465}",
            "security": "${SMTP_SECURITY:-ssl}",  # ssl | starttls | none
            "username": "${SMTP_USER}",
            "password": "${SMTP_PASSWORD}",
            "sender": "${EMAIL_FROM}",
            "to": "${EMAIL_TO}",  # comma separated
            "subject_prefix": "[JobWatch]",
        },
        "whatsapp": {
            "enabled": False,
            "provider": "${WHATSAPP_PROVIDER:-cloud}",  # cloud | twilio
            "only_priority": True,
            "to": "${WHATSAPP_TO}",  # E.164 digits, e.g. 919876543210
            "cloud": {
                "access_token": "${WHATSAPP_ACCESS_TOKEN}",
                "phone_number_id": "${WHATSAPP_PHONE_NUMBER_ID}",
                "api_version": "v21.0",
                "api_base": "https://graph.facebook.com",
                "mode": "template",  # template | text
                "template_name": "${WHATSAPP_TEMPLATE_NAME:-job_alert}",
                "template_language": "en",
            },
            "twilio": {
                "account_sid": "${TWILIO_ACCOUNT_SID}",
                "auth_token": "${TWILIO_AUTH_TOKEN}",
                "from_number": "${TWILIO_WHATSAPP_FROM:-whatsapp:+14155238886}",
                "api_base": "https://api.twilio.com",
            },
        },
        "desktop": {"enabled": False},
        "ntfy": {
            "enabled": False,
            "server": "${NTFY_SERVER:-https://ntfy.sh}",
            "topic": "${NTFY_TOPIC}",
            "token": "${NTFY_TOKEN}",
        },
    },
    "dashboard": {"host": "${DASHBOARD_HOST:-127.0.0.1}", "port": "${DASHBOARD_PORT:-8765}", "token": "${DASHBOARD_TOKEN}", "page_size": 25},
    "profile": {
        "name": "",
        "email": "",
        "phone": "",
        "links": {},
        "answers": {},
        "cover_note": (
            "Hi {company} team,\n\nI'm interested in the {title} role. My background includes {skills}. "
            "I'd love to discuss how I can contribute.\n\nBest regards,\n{name}"
        ),
    },
    "sources_files": [],
    "sources": [],
}


# --------------------------------------------------------------------------- helpers

_ENV_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")


def interpolate(value: Any) -> Any:
    """Recursively replace ``${VAR}`` / ``${VAR:-default}`` in strings using the environment."""
    if isinstance(value, str):
        return _ENV_RE.sub(lambda m: os.environ.get(m.group(1)) or (m.group(2) or ""), value)
    if isinstance(value, list):
        return [interpolate(v) for v in value]
    if isinstance(value, dict):
        return {k: interpolate(v) for k, v in value.items()}
    return value


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Return ``base`` updated with ``override`` (dicts merged recursively, everything else replaced)."""
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [v.strip() for v in value.split(",") if v.strip()]
    return [str(v).strip() for v in value if str(v).strip()]


# --------------------------------------------------------------------------- preferences


@dataclass
class Preferences:
    """User search criteria used for filtering and scoring."""

    locations: list[str]
    include_remote_india: bool
    allow_unknown_location: bool
    roles_priority: list[str]
    roles_include: list[str]
    roles_exclude: list[str]
    core_skills: list[str]
    nice_skills: list[str]
    keywords_include: list[str]
    keywords_exclude: list[str]
    my_years: float | None
    exp_min: float
    exp_max: float
    unknown_experience: str
    work_modes: list[str]
    employment_types: list[str]
    salary_min_lpa: float | None
    max_age_days: int | None
    exclude_companies: list[str]
    priority_companies: list[str]
    min_score: float
    priority_score: float
    weights: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Preferences":
        roles = d.get("roles", {})
        skills = d.get("skills", {})
        kw = d.get("keywords", {})
        exp = d.get("experience", {})
        my_years = exp.get("my_years")
        try:
            my_years = float(my_years) if my_years not in (None, "") else None
        except (TypeError, ValueError) as e:
            raise ConfigError(f"preferences.experience.my_years must be a number, got {my_years!r}") from e
        exp_min, exp_max = exp.get("min"), exp.get("max")
        if my_years is not None:  # derive a sensible window when the user only gave their own years
            exp_min = max(0.0, my_years - 2) if exp_min in (None, "") else exp_min
            exp_max = my_years + 1 if exp_max in (None, "") else exp_max
        exp_min = float(exp_min) if exp_min not in (None, "") else 0.0
        exp_max = float(exp_max) if exp_max not in (None, "") else 99.0
        if exp_min > exp_max:
            raise ConfigError("preferences.experience.min cannot be greater than max")
        unknown = str(exp.get("unknown", "allow")).lower()
        if unknown not in ("allow", "reject"):
            raise ConfigError("preferences.experience.unknown must be 'allow' or 'reject'")
        modes = [m.lower() for m in _as_list(d.get("work_modes"))]
        bad = [m for m in modes if m not in ("remote", "hybrid", "onsite")]
        if bad:
            raise ConfigError(f"preferences.work_modes has invalid values {bad}; use remote/hybrid/onsite")
        weights = {k: float(v) for k, v in (d.get("weights") or {}).items()}
        if not weights or sum(weights.values()) <= 0:
            raise ConfigError("preferences.weights must contain positive numbers")
        salary = d.get("salary_min_lpa")
        age = d.get("max_age_days")
        return cls(
            locations=[s.lower() for s in _as_list(d.get("locations"))],
            include_remote_india=bool(d.get("include_remote_india", True)),
            allow_unknown_location=bool(d.get("allow_unknown_location", False)),
            roles_priority=[s.lower() for s in _as_list(roles.get("priority"))],
            roles_include=[s.lower() for s in _as_list(roles.get("include"))],
            roles_exclude=[s.lower() for s in _as_list(roles.get("exclude"))],
            core_skills=[s.lower() for s in _as_list(skills.get("core"))],
            nice_skills=[s.lower() for s in _as_list(skills.get("nice"))],
            keywords_include=[s.lower() for s in _as_list(kw.get("include"))],
            keywords_exclude=[s.lower() for s in _as_list(kw.get("exclude"))],
            my_years=my_years,
            exp_min=exp_min,
            exp_max=exp_max,
            unknown_experience=unknown,
            work_modes=modes,
            employment_types=[s.lower() for s in _as_list(d.get("employment_types"))],
            salary_min_lpa=float(salary) if salary not in (None, "") else None,
            max_age_days=int(age) if age not in (None, "", 0) else None,
            exclude_companies=[s.lower() for s in _as_list(d.get("exclude_companies"))],
            priority_companies=[s.lower() for s in _as_list(d.get("priority_companies"))],
            min_score=float(d.get("min_score", 35)),
            priority_score=float(d.get("priority_score", 70)),
            weights=weights,
        )


# --------------------------------------------------------------------------- config


@dataclass
class Config:
    """Fully resolved application configuration."""

    raw: dict[str, Any]
    base_dir: Path
    data_dir: Path
    timezone: tzinfo
    prefs: Preferences
    engine: dict[str, Any]
    http: dict[str, Any]
    notifications: dict[str, Any]
    dashboard: dict[str, Any]
    profile: dict[str, Any]
    sources: list[dict[str, Any]]

    @property
    def db_path(self) -> Path:
        return self.data_dir / "jobwatch.db"

    @property
    def log_path(self) -> Path:
        return self.data_dir / "jobwatch.log"


def _read_yaml(path: Path) -> dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    except FileNotFoundError as e:
        raise ConfigError(f"Config file not found: {path}") from e
    except yaml.YAMLError as e:
        raise ConfigError(f"Invalid YAML in {path}: {e}") from e
    if not isinstance(data, dict):
        raise ConfigError(f"{path} must contain a YAML mapping at the top level")
    return data


def build_config(raw_user: dict[str, Any], base_dir: Path) -> Config:
    """Merge user settings over defaults, resolve env vars, validate and return a :class:`Config`."""
    merged = deep_merge(DEFAULTS, raw_user)
    sources = list(merged.get("sources") or [])
    for rel in _as_list(merged.get("sources_files")):
        path = (base_dir / rel) if not os.path.isabs(rel) else Path(rel)
        if not path.exists():  # optional include: warn, do not fail
            log.warning("sources_files entry %s does not exist; skipping it", path)
            continue
        sources.extend(_read_yaml(path).get("sources") or [])
    merged["sources"] = sources
    resolved = interpolate(merged)

    for i, src in enumerate(resolved["sources"]):
        if not isinstance(src, dict) or "type" not in src:
            raise ConfigError(f"sources[{i}] must be a mapping with a 'type' key")
    engine = resolved["engine"]
    if engine["first_run"] not in ("summary", "silent", "notify"):
        raise ConfigError("engine.first_run must be summary, silent or notify")
    if int(engine["workers"]) < 1:
        raise ConfigError("engine.workers must be >= 1")
    if not re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", str(engine["digest_time"])):
        raise ConfigError("engine.digest_time must look like HH:MM (24h)")

    data_dir = Path(resolved["data_dir"])
    if not data_dir.is_absolute():
        data_dir = base_dir / data_dir
    return Config(
        raw=resolved,
        base_dir=base_dir,
        data_dir=data_dir,
        timezone=get_timezone(str(resolved["timezone"])),
        prefs=Preferences.from_dict(resolved["preferences"]),
        engine=engine,
        http=resolved["http"],
        notifications=resolved["notifications"],
        dashboard=resolved["dashboard"],
        profile=resolved["profile"],
        sources=resolved["sources"],
    )


def load_config(path: str | os.PathLike[str] = "config.yaml") -> Config:
    """Load ``path`` (plus a sibling ``.env``) and return the resolved configuration."""
    cfg_path = Path(path).expanduser().resolve()
    try:
        from dotenv import load_dotenv

        load_dotenv(cfg_path.parent / ".env", override=False)
    except ImportError:  # python-dotenv is optional at runtime
        pass
    cfg = build_config(_read_yaml(cfg_path), cfg_path.parent)
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    return cfg
