"""Hard filters and 0-100 relevance scoring against the user's preferences."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .config import Preferences
from .extract import canonical_skill, find_skills
from .models import Job
from .util import utcnow


def _phrase(p: str) -> re.Pattern[str]:
    return re.compile(r"(?<![a-z0-9])" + re.escape(p.lower()) + r"(?![a-z0-9])")


@dataclass
class MatchResult:
    """Outcome of evaluating one job against the preferences."""

    passed: bool  # survived every hard filter
    score: float  # 0-100
    matched: bool  # passed and score >= min_score → eligible for notification
    priority: bool  # high-priority alert
    breakdown: dict[str, float] = field(default_factory=dict)  # component → 0..1
    reasons: list[str] = field(default_factory=list)
    rejects: list[str] = field(default_factory=list)


class Matcher:
    """Evaluates :class:`Job` objects against :class:`Preferences`."""

    def __init__(self, prefs: Preferences):
        self.prefs = prefs
        self._loc = [_phrase(x) for x in prefs.locations]
        self._prio_roles = [_phrase(x) for x in prefs.roles_priority]
        self._inc_roles = [_phrase(x) for x in prefs.roles_include]
        self._exc_roles = [_phrase(x) for x in prefs.roles_exclude]
        self._kw_inc = [_phrase(x) for x in prefs.keywords_include]
        self._kw_exc = [_phrase(x) for x in prefs.keywords_exclude]
        self._core = [canonical_skill(s) for s in prefs.core_skills]
        self._nice = [canonical_skill(s) for s in prefs.nice_skills]

    # -- hard filters -----------------------------------------------------------------
    def location_kind(self, job: Job) -> str | None:
        """'city' | 'remote_india' | 'unknown' | 'any' when acceptable, else ``None``."""
        p = self.prefs
        if not p.locations:
            return "any"
        loc = (job.location or "").lower()
        if any(rx.search(loc) for rx in self._loc):
            return "city"
        if p.include_remote_india and job.work_mode == "remote" and "india" in loc:
            return "remote_india"
        if not loc.strip() and (p.allow_unknown_location or job.extra.get("location_assumed")):
            return "unknown"
        return None

    def _title_tier(self, title: str) -> float | None:
        t = title.lower()
        if any(rx.search(t) for rx in self._prio_roles):
            return 1.0
        if not self._inc_roles:
            return 0.6
        if any(rx.search(t) for rx in self._inc_roles):
            return 0.7
        return None

    # -- evaluate ------------------------------------------------------------------------
    def evaluate(self, job: Job) -> MatchResult:
        p = self.prefs
        rejects: list[str] = []
        reasons: list[str] = []
        text = f"{job.title}\n{job.description}".lower()

        loc_kind = self.location_kind(job)
        if loc_kind is None:
            rejects.append(f"location '{job.location or 'unknown'}' not in preferred locations")

        title_tier = self._title_tier(job.title)
        if title_tier is None:
            rejects.append("title matches no wanted role keyword")
        if any(rx.search(job.title.lower()) for rx in self._exc_roles):
            rejects.append("title contains an excluded role keyword")

        company_l = (job.company or "").lower()
        if any(x in company_l for x in p.exclude_companies):
            rejects.append("company is excluded")

        if self._kw_inc and not any(rx.search(text) for rx in self._kw_inc):
            rejects.append("none of the required keywords found")
        hit_ex = [rx.pattern for rx in self._kw_exc if rx.search(text)]
        if hit_ex:
            rejects.append("contains an excluded keyword")

        if job.exp_min is not None:
            if not (p.exp_min <= job.exp_min <= p.exp_max):
                rejects.append(f"experience {job.exp_min:g}+ yrs outside {p.exp_min:g}-{p.exp_max:g}")
        elif p.unknown_experience == "reject":
            rejects.append("experience not stated")

        if p.work_modes and job.work_mode and job.work_mode not in p.work_modes:
            rejects.append(f"work mode '{job.work_mode}' not wanted")
        if p.employment_types and job.employment_type and job.employment_type.lower() not in p.employment_types:
            rejects.append(f"employment type '{job.employment_type}' not wanted")
        if p.salary_min_lpa is not None and job.salary_max_lpa is not None and job.salary_max_lpa < p.salary_min_lpa:
            rejects.append(f"salary up to {job.salary_max_lpa:g} LPA is below {p.salary_min_lpa:g}")
        if p.max_age_days and job.posted_at is not None:
            age = (utcnow() - job.posted_at).days
            if age > p.max_age_days:
                rejects.append(f"posted {age} days ago (limit {p.max_age_days})")

        passed = not rejects
        breakdown = self._components(job, title_tier or 0.0, loc_kind, text)
        w = p.weights
        total_w = sum(w.values())
        score = round(100.0 * sum(w.get(k, 0.0) * breakdown.get(k, 0.0) for k in w) / total_w, 1)

        if passed:
            if title_tier == 1.0:
                reasons.append("title matches a priority role")
            if breakdown["skills"] >= 0.66 and (self._core or self._nice):
                reasons.append("strong skills overlap")
            if loc_kind == "city":
                reasons.append("in a preferred city")
            elif loc_kind == "remote_india":
                reasons.append("remote role open in India")
            if breakdown["company"] >= 1.0:
                reasons.append("priority company")
        prio_company = any(x in company_l for x in p.priority_companies)
        matched = passed and score >= p.min_score
        priority = matched and (score >= p.priority_score or prio_company)
        return MatchResult(passed, score, matched, priority, breakdown, reasons, rejects)

    # -- scoring components ------------------------------------------------------------
    def _components(self, job: Job, title_tier: float, loc_kind: str | None, text: str) -> dict[str, float]:
        p = self.prefs
        out: dict[str, float] = {"title": title_tier}

        # skills
        job_skills = set(job.skills_required) | set(job.skills_preferred) | find_skills(job.title)
        for s in self._core + self._nice:  # skills outside the built-in vocabulary
            if s not in job_skills and _phrase(s).search(text):
                job_skills.add(s)
        core_hits = len([s for s in self._core if s in job_skills])
        nice_hits = len([s for s in self._nice if s in job_skills])
        if self._core:
            core = min(1.0, core_hits / min(len(self._core), 3))
            skills = 0.8 * core + 0.2 * (nice_hits / len(self._nice)) if self._nice else core
        elif self._nice:
            skills = min(1.0, nice_hits / min(len(self._nice), 3))
        else:
            skills = 0.5
        out["skills"] = round(skills, 3)

        # experience
        if job.exp_min is None:
            exp = 0.5
        elif p.my_years is not None:
            gap = max(0.0, job.exp_min - p.my_years)
            exp = max(0.0, 1.0 - gap / 3.0)
            ceiling = job.exp_max if job.exp_max is not None else job.exp_min
            if p.my_years - ceiling > 3:
                exp *= 0.7
        else:
            exp = 1.0
        out["experience"] = round(exp * (0.8 if job.exp_inferred else 1.0), 3)

        out["location"] = {"city": 1.0, "remote_india": 0.7}.get(loc_kind or "", 0.5 if loc_kind else 0.0)

        if job.posted_at is None:
            out["recency"] = 0.6
        else:
            horizon = float(p.max_age_days or 30)
            out["recency"] = round(max(0.0, 1.0 - (utcnow() - job.posted_at).total_seconds() / 86400.0 / horizon), 3)

        if p.salary_min_lpa is None or job.salary_max_lpa is None:
            out["salary"] = 0.5
        else:
            out["salary"] = 1.0 if job.salary_max_lpa >= p.salary_min_lpa else 0.0

        company_l = (job.company or "").lower()
        out["company"] = 1.0 if any(x in company_l for x in p.priority_companies) else 0.0
        return out
