"""Small shared helpers: time handling, hashing, text normalisation, secret redaction."""

from __future__ import annotations

import hashlib
import logging
import os
import re
from datetime import datetime, timedelta, timezone, tzinfo
from email.utils import parsedate_to_datetime
from typing import Any


def utcnow() -> datetime:
    """Current time as an aware UTC datetime."""
    return datetime.now(timezone.utc)


def to_iso(dt: datetime | None) -> str | None:
    """Serialise a datetime to an ISO-8601 UTC string (or None)."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def from_iso(value: str | None) -> datetime | None:
    """Parse a string produced by :func:`to_iso`."""
    return parse_dt(value)


def parse_dt(value: Any) -> datetime | None:
    """Best-effort parse of the many date formats job sources use.

    Accepts datetimes, epoch seconds/milliseconds, ISO-8601 strings
    (with or without timezone) and RFC-822 strings. Returns an aware UTC
    datetime, or ``None`` when the value cannot be understood.
    """
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, (int, float)):
        seconds = float(value)
        if seconds > 1e11:  # milliseconds
            seconds /= 1000.0
        try:
            return datetime.fromtimestamp(seconds, timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    text = str(value).strip()
    if not text:
        return None
    if text.isdigit():
        return parse_dt(int(text))
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        pass
    try:
        dt = parsedate_to_datetime(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError, IndexError):
        return None


def get_timezone(name: str) -> tzinfo:
    """Return a tzinfo for ``name``; falls back to a fixed IST offset for Asia/Kolkata."""
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(name)
    except Exception:  # missing tzdata (e.g. minimal Windows installs)
        if name in ("Asia/Kolkata", "Asia/Calcutta", "IST"):
            return timezone(timedelta(hours=5, minutes=30), "IST")
        return timezone.utc


def sha1(*parts: str) -> str:
    """Stable SHA-1 hex digest of the given string parts."""
    h = hashlib.sha1()
    for part in parts:
        h.update((part or "").encode("utf-8", "replace"))
        h.update(b"\x1f")
    return h.hexdigest()


_WS = re.compile(r"\s+")


def norm(text: str) -> str:
    """Lower-case, strip punctuation noise and collapse whitespace."""
    text = re.sub(r"[^a-z0-9+#&. ]+", " ", (text or "").lower())
    return _WS.sub(" ", text).strip()


_CITY_ALIASES = {
    "bangalore": "bengaluru",
    "bengaluru urban": "bengaluru",
    "bangalore urban": "bengaluru",
    "bengalooru": "bengaluru",
}


def primary_city(location: str) -> str:
    """First city token of a location string, with Bengaluru spellings unified."""
    first = re.split(r"[,;/|()]| - ", location or "")[0]
    city = norm(first)
    return _CITY_ALIASES.get(city, city)


# --------------------------------------------------------------------------- secrets

_SECRET_PATTERNS = [
    re.compile(r"bot\d{5,}:[A-Za-z0-9_-]{20,}"),
    re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]{10,}"),
    re.compile(r"(?i)((?:access_token|token|password|passwd|secret|api_key|apikey|auth)=)[^&\s'\"]+"),
]
_SECRET_ENV_HINTS = ("TOKEN", "PASSWORD", "SECRET", "API_KEY", "APIKEY", "AUTH_TOKEN", "ACCOUNT_SID", "APP_PASSWORD")


def _secret_values() -> list[str]:
    values = []
    for key, value in os.environ.items():
        if value and len(value) >= 8 and any(h in key.upper() for h in _SECRET_ENV_HINTS):
            values.append(value)
    return values


def redact(text: str) -> str:
    """Mask API tokens, passwords and any configured secret values inside ``text``."""
    if not text:
        return text
    out = text
    for value in _secret_values():
        if value in out:
            out = out.replace(value, "***")
    out = _SECRET_PATTERNS[0].sub("bot***", out)
    out = _SECRET_PATTERNS[1].sub(r"\1***", out)
    out = _SECRET_PATTERNS[2].sub(r"\1***", out)
    return out


class RedactingFormatter(logging.Formatter):
    """Log formatter that masks secrets in every formatted record (including tracebacks)."""

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003 - stdlib signature
        return redact(super().format(record))


def truncate(text: str, limit: int, suffix: str = "…") -> str:
    """Trim ``text`` to ``limit`` characters."""
    text = text or ""
    return text if len(text) <= limit else text[: max(0, limit - len(suffix))] + suffix
