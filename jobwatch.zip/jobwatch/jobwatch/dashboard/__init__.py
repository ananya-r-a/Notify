"""Flask dashboard: browse, search, filter and manage jobs; view source health."""

from __future__ import annotations

import hashlib
import hmac
import secrets
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from flask import Flask, abort, jsonify, redirect, render_template, request, session, url_for

from ..apply import build_kit
from ..app import build_app
from ..db import USER_STATUSES
from ..notify.format import experience_text
from ..pipeline import breakdown_for_display

PUBLIC_ENDPOINTS = {"login", "static", "healthz"}


def create_app(config_path: str = "config.yaml") -> Flask:
    """Build the dashboard. Refuses to listen on a non-local address without an access token."""
    core = build_app(config_path)
    cfg, db = core.cfg, core.db
    token = str(cfg.dashboard.get("token") or "")
    host = str(cfg.dashboard.get("host"))
    if not token and host not in ("127.0.0.1", "localhost", "::1"):
        raise RuntimeError(
            f"dashboard.host is {host!r} but no dashboard.token is set. Set DASHBOARD_TOKEN in .env "
            "or bind to 127.0.0.1: an open dashboard would expose your job search to the network."
        )
    page_size = int(cfg.dashboard.get("page_size", 25))

    app = Flask(__name__, template_folder=str(Path(__file__).parent / "templates"), static_folder=str(Path(__file__).parent / "static"))
    app.secret_key = hashlib.sha256(("jobwatch-session:" + (token or secrets.token_hex(16))).encode()).digest()
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=64 * 1024)

    # -- security -----------------------------------------------------------------------------
    @app.before_request
    def guard() -> Any:
        if request.endpoint in PUBLIC_ENDPOINTS:
            return None
        if token and not session.get("ok"):
            if request.path.startswith("/api/"):
                return jsonify(error="unauthorised"), 401
            return redirect(url_for("login", next=request.path))
        if request.method == "POST":  # CSRF: same-origin only
            origin = request.headers.get("Origin") or request.headers.get("Referer") or ""
            if origin and urlsplit(origin).netloc != request.host:
                abort(403)
        return None

    @app.after_request
    def headers(resp: Any) -> Any:
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'"
        return resp

    @app.template_filter("exp")
    def _exp(job: dict[str, Any]) -> str:
        return experience_text(job)

    @app.template_filter("day")
    def _day(value: str | None) -> str:
        return (value or "")[:10] or "—"

    @app.template_filter("safe_url")
    def _safe_url(value: str | None) -> str:
        return value if value and value.startswith(("http://", "https://")) else "#"

    # -- auth ---------------------------------------------------------------------------------
    @app.route("/login", methods=["GET", "POST"])
    def login() -> Any:
        error = ""
        if request.method == "POST":
            if token and hmac.compare_digest(request.form.get("token", ""), token):
                session["ok"] = True
                nxt = request.args.get("next", "/")
                return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else "/")
            error = "Wrong token"
        return render_template("login.html", error=error)

    @app.route("/logout")
    def logout() -> Any:
        session.clear()
        return redirect(url_for("login"))

    @app.route("/healthz")
    def healthz() -> Any:
        return jsonify(status="ok")

    # -- pages ----------------------------------------------------------------------------------
    def _filters() -> dict[str, Any]:
        a = request.args
        try:
            page = max(1, int(a.get("page", 1)))
        except ValueError:
            page = 1
        try:
            min_score = float(a.get("min_score") or 0)
        except ValueError:
            min_score = 0
        days = int(a["days"]) if a.get("days", "").isdigit() else None
        return {
            "q": a.get("q", "").strip(), "source": a.get("source", ""), "min_score": min_score,
            "matched_only": a.get("scope", "matched") == "matched", "status": a.get("status", "active"),
            "user_status": a.get("user_status", ""), "work_mode": a.get("work_mode", ""), "days": days,
            "sort": a.get("sort", "score"), "page": page,
        }

    @app.route("/")
    def index() -> Any:
        f = _filters()
        page = f.pop("page")
        rows, total = db.query_jobs(**f, limit=page_size, offset=(page - 1) * page_size)
        return render_template(
            "index.html", jobs=rows, total=total, page=page, pages=max(1, -(-total // page_size)), f={**f, "scope": request.args.get("scope", "matched")},
            stats=db.stats(), sources=db.distinct_sources(), statuses=USER_STATUSES,
            args={k: v for k, v in request.args.items() if k != "page"},
        )

    @app.route("/job/<int:job_id>")
    def job_detail(job_id: int) -> Any:
        job = db.get_job_by_id(job_id)
        if not job:
            abort(404)
        comps, reasons, rejects = breakdown_for_display(job["score_breakdown"])
        kit = build_kit(job, cfg.profile)
        return render_template("job.html", job=job, comps=comps, reasons=reasons, rejects=rejects, kit=kit, statuses=USER_STATUSES)

    @app.route("/job/<int:job_id>/status", methods=["POST"])
    def set_status(job_id: int) -> Any:
        job = db.get_job_by_id(job_id)
        if not job:
            abort(404)
        status = request.form.get("user_status", "")
        if status not in USER_STATUSES:
            abort(400)
        fields: dict[str, Any] = {"user_status": status}
        if "notes" in request.form:
            fields["notes"] = request.form["notes"][:4000]
        db.update_job(job["uid"], fields)
        db.add_event("user_status", job["source"], job["uid"], status)
        return redirect(request.form.get("next") if (request.form.get("next") or "").startswith("/") else url_for("job_detail", job_id=job_id))

    @app.route("/sources")
    def sources_page() -> Any:
        known = {s["source"]: s for s in db.all_source_states()}
        rows = []
        for s in core.sources:
            st = known.get(s.name, {})
            rows.append({"name": s.name, "platform": s.platform, "interval": s.interval, **st})
        return render_template("sources.html", rows=rows, events=db.recent_events(40), stats=db.stats())

    @app.route("/sources/run", methods=["POST"])
    def run_now() -> Any:
        db.add_command("run_now", request.form.get("source", ""))
        return redirect(url_for("sources_page"))

    @app.route("/rescore", methods=["POST"])
    def rescore() -> Any:
        db.add_command("rescore")
        return redirect(url_for("sources_page"))

    # -- JSON API ------------------------------------------------------------------------------------
    @app.route("/api/jobs")
    def api_jobs() -> Any:
        f = _filters()
        page = f.pop("page")
        limit = min(int(request.args.get("limit", page_size)) if request.args.get("limit", "").isdigit() else page_size, 200)
        rows, total = db.query_jobs(**f, limit=limit, offset=(page - 1) * limit)
        for r in rows:
            r.pop("description", None)
        return jsonify(total=total, page=page, jobs=rows)

    @app.route("/api/stats")
    def api_stats() -> Any:
        return jsonify(db.stats())

    @app.route("/api/sources")
    def api_sources() -> Any:
        return jsonify(db.all_source_states())

    return app
