"""HTTP client with exponential backoff, per-host throttling, conditional GETs and robots.txt."""

from __future__ import annotations

import logging
import random
import threading
import time
from typing import Any, Callable
from urllib import robotparser
from urllib.parse import urlsplit

import requests

from .db import Database
from .models import NotModified, SourceBlocked, SourceError, SourceNotFound
from .util import redact

log = logging.getLogger(__name__)

RETRY_STATUSES = {429, 500, 502, 503, 504}


class HttpClient:
    """A polite ``requests`` wrapper used by every adapter.

    * retries network errors, timeouts, 429 and 5xx with exponential backoff + jitter
      (honouring ``Retry-After``), then raises :class:`SourceError`
    * 404 → :class:`SourceNotFound`, 401/403 → :class:`SourceBlocked` (never retried)
    * enforces a minimum delay between requests to the same host (thread-safe)
    * optional ETag / Last-Modified conditional requests persisted in the database
    """

    def __init__(
        self,
        user_agent: str = "JobWatch/1.0",
        timeout: float = 20,
        max_retries: int = 4,
        backoff_base: float = 1.5,
        backoff_max: float = 60,
        min_host_interval: float = 1.0,
        respect_robots: bool = True,
        db: Database | None = None,
        sleep: Callable[[float], None] = time.sleep,
        session: requests.Session | None = None,
    ):
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        self.backoff_max = backoff_max
        self.min_host_interval = min_host_interval
        self.respect_robots = respect_robots
        self.db = db
        self._sleep = sleep
        self.session = session or requests.Session()
        self.session.headers.update({"User-Agent": user_agent, "Accept": "application/json, text/html;q=0.9, */*;q=0.8"})
        self._last_hit: dict[str, float] = {}
        self._host_lock = threading.Lock()
        self._robots: dict[str, robotparser.RobotFileParser | None] = {}
        self.user_agent = user_agent

    # -- throttling -------------------------------------------------------------------
    def _throttle(self, host: str) -> None:
        if self.min_host_interval <= 0:
            return
        with self._host_lock:
            now = time.monotonic()
            ready = self._last_hit.get(host, 0.0) + self.min_host_interval
            wait = max(0.0, ready - now)
            self._last_hit[host] = max(now, ready)  # reserve our slot
        if wait > 0:
            self._sleep(wait)

    def _backoff(self, attempt: int, retry_after: str | None = None) -> float:
        if retry_after:
            try:
                return min(float(retry_after), 120.0)
            except ValueError:
                pass
        delay = min(self.backoff_max, self.backoff_base * (2**attempt))
        return delay + random.uniform(0, delay * 0.25)

    # -- robots.txt -------------------------------------------------------------------
    def allowed_by_robots(self, url: str) -> bool:
        """True if robots.txt permits fetching ``url`` (unreachable robots.txt → allowed)."""
        if not self.respect_robots:
            return True
        parts = urlsplit(url)
        origin = f"{parts.scheme}://{parts.netloc}"
        if origin not in self._robots:
            rp = robotparser.RobotFileParser()
            try:
                self._throttle(parts.netloc)
                resp = self.session.get(origin + "/robots.txt", timeout=self.timeout)
                if resp.status_code == 200:
                    rp.parse(resp.text.splitlines())
                    self._robots[origin] = rp
                elif resp.status_code in (401, 403):
                    rp.disallow_all = True
                    self._robots[origin] = rp
                else:
                    self._robots[origin] = None  # no robots.txt → everything allowed
            except requests.RequestException:
                self._robots[origin] = None
        rp = self._robots[origin]
        return True if rp is None else rp.can_fetch(self.user_agent, url)

    # -- requests ---------------------------------------------------------------------
    def request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        data: Any = None,
        headers: dict[str, str] | None = None,
        conditional: bool = False,
        check_robots: bool = False,
        timeout: float | None = None,
    ) -> requests.Response:
        """Perform a request with retries. Raises :class:`NotModified` on a 304 when ``conditional``."""
        if check_robots and not self.allowed_by_robots(url):
            raise SourceBlocked(f"robots.txt disallows fetching {url}")
        host = urlsplit(url).netloc
        hdrs = dict(headers or {})
        if conditional and self.db is not None:
            cached = self.db.get_http_cache(url)
            if cached:
                if cached.get("etag"):
                    hdrs["If-None-Match"] = cached["etag"]
                if cached.get("last_modified"):
                    hdrs["If-Modified-Since"] = cached["last_modified"]

        last_error = "unknown error"
        for attempt in range(self.max_retries + 1):
            self._throttle(host)
            try:
                resp = self.session.request(
                    method, url, params=params, json=json, data=data, headers=hdrs, timeout=timeout or self.timeout
                )
            except (requests.ConnectionError, requests.Timeout) as e:
                last_error = f"{type(e).__name__}: {redact(str(e))[:200]}"
            except requests.RequestException as e:
                raise SourceError(f"Request failed: {redact(str(e))[:300]}") from e
            else:
                code = resp.status_code
                if code == 304 and conditional:
                    raise NotModified(url)
                if code == 404:
                    raise SourceNotFound(f"404 Not Found: {redact(url)}")
                if code in (401, 403):
                    raise SourceBlocked(f"HTTP {code} from {host} (access refused / anti-bot protection)")
                if code in RETRY_STATUSES:
                    last_error = f"HTTP {code}"
                    if attempt < self.max_retries:
                        delay = self._backoff(attempt, resp.headers.get("Retry-After"))
                        log.warning("HTTP %s from %s; retry %d/%d in %.1fs", code, host, attempt + 1, self.max_retries, delay)
                        self._sleep(delay)
                        continue
                elif code >= 400:
                    raise SourceError(f"HTTP {code} from {host}")
                else:
                    if conditional and self.db is not None and method.upper() == "GET":
                        etag, lm = resp.headers.get("ETag"), resp.headers.get("Last-Modified")
                        if etag or lm:
                            self.db.set_http_cache(url, etag, lm)
                    return resp
            if attempt < self.max_retries:
                delay = self._backoff(attempt)
                log.warning("%s on %s; retry %d/%d in %.1fs", last_error, host, attempt + 1, self.max_retries, delay)
                self._sleep(delay)
        raise SourceError(f"Giving up after {self.max_retries + 1} attempts on {host}: {last_error}")

    def get(self, url: str, **kw: Any) -> requests.Response:
        return self.request("GET", url, **kw)

    def post(self, url: str, **kw: Any) -> requests.Response:
        return self.request("POST", url, **kw)

    def get_json(self, url: str, **kw: Any) -> Any:
        resp = self.get(url, **kw)
        try:
            return resp.json()
        except ValueError as e:
            raise SourceError(f"Response from {urlsplit(url).netloc} was not valid JSON") from e
