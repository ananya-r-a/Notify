"""SQLite persistence: jobs, per-source health, notification log, events, HTTP cache.

Every method opens its own short-lived connection (WAL mode + busy timeout), so the
scheduler's worker threads, the notification flusher and the dashboard process can
all use the same database file safely. Data survives restarts.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator

from .util import to_iso, utcnow

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL,
  platform TEXT NOT NULL,
  external_id TEXT NOT NULL,
  title TEXT NOT NULL,
  company TEXT NOT NULL DEFAULT '',
  location TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  url TEXT NOT NULL DEFAULT '',
  apply_url TEXT NOT NULL DEFAULT '',
  company_page TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  employment_type TEXT NOT NULL DEFAULT '',
  work_mode TEXT NOT NULL DEFAULT '',
  salary_text TEXT NOT NULL DEFAULT '',
  salary_min_lpa REAL,
  salary_max_lpa REAL,
  experience_text TEXT NOT NULL DEFAULT '',
  exp_min REAL,
  exp_max REAL,
  exp_inferred INTEGER NOT NULL DEFAULT 0,
  skills_required TEXT NOT NULL DEFAULT '[]',
  skills_preferred TEXT NOT NULL DEFAULT '[]',
  posted_at TEXT,
  deadline TEXT,
  discovered_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  updated_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  missing_count INTEGER NOT NULL DEFAULT 0,
  score REAL NOT NULL DEFAULT 0,
  score_breakdown TEXT NOT NULL DEFAULT '{}',
  matched INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 0,
  content_hash TEXT NOT NULL DEFAULT '',
  apply_hash TEXT NOT NULL DEFAULT '',
  fingerprint TEXT NOT NULL DEFAULT '',
  duplicate_of TEXT,
  baseline INTEGER NOT NULL DEFAULT 0,
  notified_at TEXT,
  notify_attempts INTEGER NOT NULL DEFAULT 0,
  user_status TEXT NOT NULL DEFAULT 'new',
  notes TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_jobs_source ON jobs(source, status);
CREATE INDEX IF NOT EXISTS idx_jobs_fp ON jobs(fingerprint);
CREATE INDEX IF NOT EXISTS idx_jobs_pending ON jobs(matched, notified_at, baseline);
CREATE INDEX IF NOT EXISTS idx_jobs_discovered ON jobs(discovered_at);

CREATE TABLE IF NOT EXISTS source_state (
  source TEXT PRIMARY KEY,
  platform TEXT NOT NULL DEFAULT '',
  last_attempt TEXT,
  last_success TEXT,
  last_error TEXT,
  last_warning TEXT,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  consecutive_404 INTEGER NOT NULL DEFAULT 0,
  total_runs INTEGER NOT NULL DEFAULT 0,
  total_failures INTEGER NOT NULL DEFAULT 0,
  jobs_seen INTEGER NOT NULL DEFAULT 0,
  jobs_stored INTEGER NOT NULL DEFAULT 0,
  last_duration_ms INTEGER,
  failure_alerted INTEGER NOT NULL DEFAULT 0,
  disabled_reason TEXT
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_uid TEXT NOT NULL,
  channel TEXT NOT NULL,
  ok INTEGER NOT NULL,
  error TEXT,
  sent_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_job ON notifications(job_uid, channel, ok);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  kind TEXT NOT NULL,
  source TEXT,
  job_uid TEXT,
  detail TEXT
);

CREATE TABLE IF NOT EXISTS http_cache (
  url TEXT PRIMARY KEY,
  etag TEXT,
  last_modified TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS commands (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  arg TEXT,
  created_at TEXT NOT NULL,
  done_at TEXT
);
"""

JOB_COLUMNS = {
    "uid", "source", "platform", "external_id", "title", "company", "location", "description", "url", "apply_url",
    "company_page", "department", "employment_type", "work_mode", "salary_text", "salary_min_lpa", "salary_max_lpa",
    "experience_text", "exp_min", "exp_max", "exp_inferred", "skills_required", "skills_preferred", "posted_at",
    "deadline", "discovered_at", "last_seen_at", "updated_at", "status", "missing_count", "score", "score_breakdown",
    "matched", "priority", "content_hash", "apply_hash", "fingerprint", "duplicate_of", "baseline", "notified_at",
    "notify_attempts", "user_status", "notes",
}
_JSON_COLUMNS = ("skills_required", "skills_preferred", "score_breakdown")
USER_STATUSES = ("new", "saved", "applied", "interview", "offer", "rejected", "ignored")


def _decode(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    d = dict(row)
    for col in _JSON_COLUMNS:
        if col in d:
            try:
                d[col] = json.loads(d[col] or ("{}" if col == "score_breakdown" else "[]"))
            except json.JSONDecodeError:
                d[col] = {} if col == "score_breakdown" else []
    return d


class Database:
    """Thin wrapper around a SQLite file."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.init()

    # -- plumbing -----------------------------------------------------------------
    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA busy_timeout=30000")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init(self) -> None:
        with self.connect() as c:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript(SCHEMA)

    # -- jobs ---------------------------------------------------------------------
    def get_job(self, uid: str) -> dict[str, Any] | None:
        with self.connect() as c:
            return _decode(c.execute("SELECT * FROM jobs WHERE uid=?", (uid,)).fetchone())

    def get_job_by_id(self, job_id: int) -> dict[str, Any] | None:
        with self.connect() as c:
            return _decode(c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())

    def insert_job(self, row: dict[str, Any]) -> None:
        self._check_columns(row)
        row = self._encode(row)
        cols = ",".join(row)
        marks = ",".join("?" for _ in row)
        with self.connect() as c:
            c.execute(f"INSERT INTO jobs ({cols}) VALUES ({marks})", list(row.values()))

    def update_job(self, uid: str, fields: dict[str, Any]) -> None:
        if not fields:
            return
        self._check_columns(fields)
        fields = self._encode(fields)
        sets = ",".join(f"{k}=?" for k in fields)
        with self.connect() as c:
            c.execute(f"UPDATE jobs SET {sets} WHERE uid=?", [*fields.values(), uid])

    def touch_seen(self, uids: Iterable[str]) -> None:
        """Mark jobs as seen now and reset their missing counters."""
        now = to_iso(utcnow())
        uids = list(uids)
        if not uids:
            return
        with self.connect() as c:
            for i in range(0, len(uids), 500):
                chunk = uids[i : i + 500]
                marks = ",".join("?" for _ in chunk)
                c.execute(
                    f"UPDATE jobs SET last_seen_at=?, missing_count=0, "
                    f"status=CASE WHEN status='expired' THEN 'active' ELSE status END WHERE uid IN ({marks})",
                    [now, *chunk],
                )

    def known_external_ids(self, source: str, described_only: bool = False) -> set[str]:
        """External ids already stored for ``source`` (optionally only those with a description)."""
        sql = "SELECT external_id FROM jobs WHERE source=?" + (" AND description<>''" if described_only else "")
        with self.connect() as c:
            rows = c.execute(sql, (source,)).fetchall()
        return {r["external_id"] for r in rows}

    def active_count(self, source: str) -> int:
        with self.connect() as c:
            return c.execute("SELECT COUNT(*) FROM jobs WHERE source=? AND status='active'", (source,)).fetchone()[0]

    def mark_missing(self, source: str, seen_uids: set[str], expire_after: int) -> list[dict[str, Any]]:
        """Increment the missing counter of active jobs not in ``seen_uids``; return newly expired jobs."""
        expired: list[dict[str, Any]] = []
        with self.connect() as c:
            rows = c.execute("SELECT uid, missing_count FROM jobs WHERE source=? AND status='active'", (source,)).fetchall()
            for r in rows:
                if r["uid"] in seen_uids:
                    continue
                misses = r["missing_count"] + 1
                if misses >= expire_after:
                    c.execute("UPDATE jobs SET status='expired', missing_count=? WHERE uid=?", (misses, r["uid"]))
                    expired.append(_decode(c.execute("SELECT * FROM jobs WHERE uid=?", (r["uid"],)).fetchone()))
                else:
                    c.execute("UPDATE jobs SET missing_count=? WHERE uid=?", (misses, r["uid"]))
        return expired

    def duplicate_notified(self, fingerprint: str, exclude_uid: str, source: str) -> str | None:
        """uid of an already-notified job with the same fingerprint on a *different* source, if any.

        Same-source look-alikes are deliberately not treated as duplicates: a company can legitimately
        list several identical-looking requisitions on its own board.
        """
        with self.connect() as c:
            row = c.execute(
                "SELECT uid FROM jobs WHERE fingerprint=? AND uid<>? AND source<>? AND notified_at IS NOT NULL "
                "AND duplicate_of IS NULL AND status='active' LIMIT 1",
                (fingerprint, exclude_uid, source),
            ).fetchone()
        return row["uid"] if row else None

    # -- notification bookkeeping ---------------------------------------------------
    def pending_notifications(self, limit: int, max_attempts: int) -> list[dict[str, Any]]:
        with self.connect() as c:
            rows = c.execute(
                "SELECT * FROM jobs WHERE matched=1 AND notified_at IS NULL AND baseline=0 AND status='active' "
                "AND duplicate_of IS NULL AND notify_attempts<? ORDER BY priority DESC, score DESC, discovered_at ASC LIMIT ?",
                (max_attempts, limit),
            ).fetchall()
        return [_decode(r) for r in rows]

    def pending_baseline(self) -> list[dict[str, Any]]:
        with self.connect() as c:
            rows = c.execute(
                "SELECT * FROM jobs WHERE matched=1 AND baseline=1 AND notified_at IS NULL AND status='active' "
                "AND duplicate_of IS NULL ORDER BY priority DESC, score DESC"
            ).fetchall()
        return [_decode(r) for r in rows]

    def mark_notified(self, uids: Iterable[str]) -> None:
        now = to_iso(utcnow())
        with self.connect() as c:
            for uid in uids:
                c.execute("UPDATE jobs SET notified_at=? WHERE uid=?", (now, uid))

    def bump_attempts(self, uid: str) -> None:
        with self.connect() as c:
            c.execute("UPDATE jobs SET notify_attempts=notify_attempts+1 WHERE uid=?", (uid,))

    def record_notification(self, uid: str, channel: str, ok: bool, error: str | None = None) -> None:
        with self.connect() as c:
            c.execute(
                "INSERT INTO notifications (job_uid, channel, ok, error, sent_at) VALUES (?,?,?,?,?)",
                (uid, channel, 1 if ok else 0, (error or "")[:500] or None, to_iso(utcnow())),
            )

    def channels_done(self, uid: str) -> set[str]:
        with self.connect() as c:
            rows = c.execute("SELECT DISTINCT channel FROM notifications WHERE job_uid=? AND ok=1", (uid,)).fetchall()
        return {r["channel"] for r in rows}

    def recent_matched(self, since_iso: str, min_score: float = 0) -> list[dict[str, Any]]:
        with self.connect() as c:
            rows = c.execute(
                "SELECT * FROM jobs WHERE matched=1 AND discovered_at>=? AND score>=? AND status='active' "
                "AND duplicate_of IS NULL ORDER BY score DESC",
                (since_iso, min_score),
            ).fetchall()
        return [_decode(r) for r in rows]

    # -- source state -------------------------------------------------------------
    def get_source_state(self, source: str) -> dict[str, Any]:
        with self.connect() as c:
            row = c.execute("SELECT * FROM source_state WHERE source=?", (source,)).fetchone()
        return dict(row) if row else {"source": source, "consecutive_failures": 0, "consecutive_404": 0, "last_success": None}

    def all_source_states(self) -> list[dict[str, Any]]:
        with self.connect() as c:
            return [dict(r) for r in c.execute("SELECT * FROM source_state ORDER BY source").fetchall()]

    def save_source_state(self, source: str, **fields: Any) -> None:
        with self.connect() as c:
            c.execute("INSERT OR IGNORE INTO source_state (source) VALUES (?)", (source,))
            if fields:
                sets = ",".join(f"{k}=?" for k in fields)
                c.execute(f"UPDATE source_state SET {sets} WHERE source=?", [*fields.values(), source])

    # -- events / meta / commands ---------------------------------------------------
    def add_event(self, kind: str, source: str | None = None, job_uid: str | None = None, detail: str = "") -> None:
        with self.connect() as c:
            c.execute(
                "INSERT INTO events (ts, kind, source, job_uid, detail) VALUES (?,?,?,?,?)",
                (to_iso(utcnow()), kind, source, job_uid, detail[:1000]),
            )

    def recent_events(self, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as c:
            return [dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

    def get_meta(self, key: str, default: str | None = None) -> str | None:
        with self.connect() as c:
            row = c.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_meta(self, key: str, value: str) -> None:
        with self.connect() as c:
            c.execute("INSERT INTO meta (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def get_http_cache(self, url: str) -> dict[str, Any] | None:
        with self.connect() as c:
            row = c.execute("SELECT * FROM http_cache WHERE url=?", (url,)).fetchone()
        return dict(row) if row else None

    def set_http_cache(self, url: str, etag: str | None, last_modified: str | None) -> None:
        with self.connect() as c:
            c.execute(
                "INSERT INTO http_cache (url, etag, last_modified, updated_at) VALUES (?,?,?,?) "
                "ON CONFLICT(url) DO UPDATE SET etag=excluded.etag, last_modified=excluded.last_modified, updated_at=excluded.updated_at",
                (url, etag, last_modified, to_iso(utcnow())),
            )

    def add_command(self, kind: str, arg: str = "") -> None:
        with self.connect() as c:
            c.execute("INSERT INTO commands (kind, arg, created_at) VALUES (?,?,?)", (kind, arg, to_iso(utcnow())))

    def pop_commands(self) -> list[dict[str, Any]]:
        with self.connect() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM commands WHERE done_at IS NULL ORDER BY id").fetchall()]
            now = to_iso(utcnow())
            for r in rows:
                c.execute("UPDATE commands SET done_at=? WHERE id=?", (now, r["id"]))
        return rows

    # -- dashboard queries ----------------------------------------------------------
    _SORTS = {
        "score": "score DESC, discovered_at DESC",
        "discovered": "discovered_at DESC",
        "posted": "COALESCE(posted_at, discovered_at) DESC",
        "company": "company COLLATE NOCASE ASC, score DESC",
    }

    def query_jobs(
        self,
        q: str = "",
        source: str = "",
        min_score: float = 0,
        matched_only: bool = True,
        status: str = "active",
        user_status: str = "",
        work_mode: str = "",
        days: int | None = None,
        sort: str = "score",
        limit: int = 25,
        offset: int = 0,
    ) -> tuple[list[dict[str, Any]], int]:
        where, args = ["1=1"], []
        if q:
            like = f"%{q.lower()}%"
            where.append("(LOWER(title) LIKE ? OR LOWER(company) LIKE ? OR LOWER(location) LIKE ? OR LOWER(description) LIKE ?)")
            args += [like] * 4
        if source:
            where.append("source=?")
            args.append(source)
        if min_score:
            where.append("score>=?")
            args.append(min_score)
        if matched_only:
            where.append("matched=1")
        if status and status != "all":
            where.append("status=?")
            args.append(status)
        if user_status:
            where.append("user_status=?")
            args.append(user_status)
        if work_mode:
            where.append("work_mode=?")
            args.append(work_mode)
        if days:
            from datetime import timedelta

            where.append("discovered_at>=?")
            args.append(to_iso(utcnow() - timedelta(days=days)))
        clause = " AND ".join(where)
        order = self._SORTS.get(sort, self._SORTS["score"])
        with self.connect() as c:
            total = c.execute(f"SELECT COUNT(*) FROM jobs WHERE {clause}", args).fetchone()[0]
            rows = c.execute(f"SELECT * FROM jobs WHERE {clause} ORDER BY {order} LIMIT ? OFFSET ?", [*args, limit, offset]).fetchall()
        return [_decode(r) for r in rows], total

    def distinct_sources(self) -> list[str]:
        with self.connect() as c:
            return [r[0] for r in c.execute("SELECT DISTINCT source FROM jobs ORDER BY source").fetchall()]

    def stats(self) -> dict[str, Any]:
        from datetime import timedelta

        day_ago = to_iso(utcnow() - timedelta(days=1))
        with self.connect() as c:
            one = lambda sql, *a: c.execute(sql, a).fetchone()[0]  # noqa: E731
            return {
                "active": one("SELECT COUNT(*) FROM jobs WHERE status='active'"),
                "matched": one("SELECT COUNT(*) FROM jobs WHERE status='active' AND matched=1"),
                "new_24h": one("SELECT COUNT(*) FROM jobs WHERE discovered_at>=? AND matched=1", day_ago),
                "priority": one("SELECT COUNT(*) FROM jobs WHERE status='active' AND priority=1"),
                "expired": one("SELECT COUNT(*) FROM jobs WHERE status='expired'"),
                "applied": one("SELECT COUNT(*) FROM jobs WHERE user_status='applied'"),
                "sources": one("SELECT COUNT(*) FROM source_state"),
                "failing": one("SELECT COUNT(*) FROM source_state WHERE consecutive_failures>0 AND disabled_reason IS NULL"),
                "disabled": one("SELECT COUNT(*) FROM source_state WHERE disabled_reason IS NOT NULL"),
            }

    # -- internals ------------------------------------------------------------------
    @staticmethod
    def _check_columns(row: dict[str, Any]) -> None:
        bad = set(row) - JOB_COLUMNS
        if bad:
            raise ValueError(f"Unknown job columns: {sorted(bad)}")

    @staticmethod
    def _encode(row: dict[str, Any]) -> dict[str, Any]:
        out = dict(row)
        for col in _JSON_COLUMNS:
            if col in out and not isinstance(out[col], str):
                out[col] = json.dumps(out[col])
        return out
