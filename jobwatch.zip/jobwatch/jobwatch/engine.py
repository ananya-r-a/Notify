"""Monitoring engine: per-source scheduling, retries/backoff, health tracking, notification flushing."""

from __future__ import annotations

import logging
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from typing import Any

from .config import Config
from .db import Database
from .models import NotModified, SourceBlocked, SourceError, SourceNotFound
from .notify import NotificationService
from .pipeline import Pipeline
from .sources.base import Source
from .util import redact, to_iso, utcnow

log = logging.getLogger(__name__)


class Engine:
    """Runs every enabled source on its own interval, independently of the others.

    * a failing source backs off exponentially (capped) and never affects the rest
    * ``last_success`` is persisted, so after a restart sources resume on schedule instead of
      all firing at once
    * the notification flusher runs separately from fetching, so alerts that failed earlier are retried
    """

    def __init__(self, cfg: Config, db: Database, sources: list[Source], pipeline: Pipeline, notifier: NotificationService):
        self.cfg = cfg
        self.db = db
        self.sources = {s.name: s for s in sources}
        self.pipeline = pipeline
        self.notifier = notifier
        self.stop_event = threading.Event()
        self._running: set[str] = set()
        self._lock = threading.Lock()
        self._next_run: dict[str, float] = {}
        self._flush_lock = threading.Lock()
        self._retry_after: dict[str, float] = {}  # job uid -> earliest time of the next delivery attempt
        self._baseline_retry_at = 0.0
        self._warned_no_channels = False
        self.ecfg = cfg.engine

    # -- scheduling helpers -----------------------------------------------------------------
    def _interval_with_jitter(self, interval: float) -> float:
        j = float(self.ecfg.get("jitter", 0.1))
        return interval * (1 + random.uniform(-j, j))

    def _backoff_interval(self, src: Source, failures: int, blocked: bool) -> float:
        base = src.interval * (4 if blocked else 1)
        return min(float(self.ecfg.get("max_backoff", 3600)), base * (2 ** min(failures, 8)))

    def schedule_initial(self) -> None:
        """Pick the first run time per source: stagger, and respect the last persisted success."""
        now, stagger = time.time(), 0.0
        for name, src in self.sources.items():
            state = self.db.get_source_state(name)
            if state.get("disabled_reason"):
                log.warning("Source %s is disabled: %s (run 'jobwatch enable %s' after fixing)", name, state["disabled_reason"], name)
                continue
            due = now + stagger
            last = state.get("last_success")
            if last:
                try:
                    last_ts = datetime.fromisoformat(last).timestamp()
                    due = max(due, last_ts + src.interval)
                except ValueError:
                    pass
            self._next_run[name] = due
            stagger += 0.5

    # -- one source run -----------------------------------------------------------------------
    def run_source(self, name: str) -> dict[str, Any]:
        """Fetch, process and record the outcome of one source. Never raises."""
        src = self.sources[name]
        started = time.monotonic()
        state = self.db.get_source_state(name)
        self.db.save_source_state(name, platform=src.platform, last_attempt=to_iso(utcnow()), total_runs=state.get("total_runs", 0) + 1)
        outcome: dict[str, Any] = {"source": name, "ok": False}
        try:
            src.known_ids = self.db.known_external_ids(name, described_only=True)
            jobs = src.fetch()
            result = self.pipeline.process(name, jobs, complete=src.complete_listing)
            self._on_success(src, state, result, started)
            outcome.update(ok=True, seen=result.seen, new=result.new, new_matched=result.new_matched, updated=result.updated, expired=len(result.expired))
            if result.apply_changed and self.ecfg.get("notify_updates"):
                for j in result.apply_changed:
                    if j.get("notified_at"):
                        self.notifier.send_system(f"Application link changed: {j['title']}", f"{j['company']}\n{j.get('apply_url') or j.get('url')}")
        except NotModified:
            self.db.save_source_state(
                name, last_success=to_iso(utcnow()), consecutive_failures=0, consecutive_404=0, last_error=None,
                last_duration_ms=int((time.monotonic() - started) * 1000),
            )
            outcome.update(ok=True, not_modified=True)
            log.debug("[%s] not modified", name)
        except SourceNotFound as e:
            self._on_failure(src, state, e, not_found=True)
            outcome["error"] = str(e)
        except SourceBlocked as e:
            self._on_failure(src, state, e, blocked=True)
            outcome["error"] = str(e)
        except SourceError as e:
            self._on_failure(src, state, e)
            outcome["error"] = str(e)
        except Exception as e:  # adapter bug or unexpected payload: record, never crash the engine
            log.exception("[%s] unexpected error", name)
            self._on_failure(src, state, SourceError(f"{type(e).__name__}: {e}"))
            outcome["error"] = f"{type(e).__name__}: {e}"
        return outcome

    def _on_success(self, src: Source, state: dict[str, Any], result: Any, started: float) -> None:
        was_alerted = bool(state.get("failure_alerted"))
        self.db.save_source_state(
            src.name, last_success=to_iso(utcnow()), last_error=None, last_warning=result.warning or None,
            consecutive_failures=0, consecutive_404=0, failure_alerted=0,
            jobs_seen=result.seen, jobs_stored=self.db.active_count(src.name),
            last_duration_ms=int((time.monotonic() - started) * 1000),
        )
        if result.warning:
            log.warning("[%s] %s", src.name, result.warning)
        log.info(
            "[%s] seen=%d new=%d (matched %d) updated=%d expired=%d%s", src.name, result.seen, result.new, result.new_matched,
            result.updated, len(result.expired), " [first run baseline]" if result.baseline else "",
        )
        if was_alerted:
            self.notifier.send_system(f"Source recovered: {src.name}", "It is working again.")

    def _on_failure(self, src: Source, state: dict[str, Any], err: Exception, blocked: bool = False, not_found: bool = False) -> None:
        failures = state.get("consecutive_failures", 0) + 1
        nf = state.get("consecutive_404", 0) + 1 if not_found else 0
        msg = redact(str(err))
        fields: dict[str, Any] = {
            "last_error": msg[:500], "consecutive_failures": failures, "consecutive_404": nf,
            "total_failures": state.get("total_failures", 0) + 1,
        }
        log.error("[%s] fetch failed (%d in a row): %s", src.name, failures, msg)
        self.db.add_event("source_error", src.name, None, msg)
        if not_found and nf >= int(self.ecfg.get("dead_source_after_404", 3)):
            fields["disabled_reason"] = f"{nf} consecutive 404s: board/slug probably wrong or closed ({msg[:120]})"
            self.db.save_source_state(src.name, **fields)
            self._next_run.pop(src.name, None)
            self.notifier.send_system(f"Source disabled: {src.name}", fields["disabled_reason"] + "\nFix the config, then run: jobwatch enable " + src.name)
            return
        threshold = int(self.ecfg.get("fail_alert_threshold", 5))
        if failures >= threshold and not state.get("failure_alerted"):
            fields["failure_alerted"] = 1
            self.notifier.send_system(f"Source failing: {src.name}", f"{failures} consecutive failures.\nLast error: {msg[:300]}")
        self.db.save_source_state(src.name, **fields)
        self._next_run[src.name] = time.time() + self._interval_with_jitter(self._backoff_interval(src, failures, blocked))

    # -- notifications ----------------------------------------------------------------------------
    def _schedule_retry(self, job: dict[str, Any]) -> None:
        """Exponential, time-based retry (30s, 60s, 2m … capped at 15 min) after a failed delivery."""
        attempts = int(job.get("notify_attempts", 0)) + 1  # notify_job already bumped the stored counter
        self._retry_after[job["uid"]] = time.time() + min(900.0, 30.0 * (2 ** max(0, attempts - 1)))
        if attempts >= int(self.ecfg.get("max_notify_attempts", 12)):
            log.error("Giving up on alert '%s' after %d failed delivery attempts", job["title"], attempts)
            self.notifier.send_system(
                "Job alert could not be delivered",
                f"{job['title']} @ {job.get('company')}\n{job.get('apply_url') or job.get('url')}\nAll channels failed {attempts} times; see the dashboard.",
            )

    def flush_notifications(self) -> int:
        """Send alerts for every matched, un-notified job. Returns the number of jobs delivered.

        Safe to call repeatedly: failed deliveries wait for their retry time and are never lost
        (they stay pending in the database), and a missing channel configuration is reported once.
        """
        with self._flush_lock:
            if not self.notifier.has_usable_channel():
                if not self._warned_no_channels:
                    log.warning("No notification channel is configured and working: matching jobs are stored but NOT announced. "
                                "Run 'python -m jobwatch check' and fix the channel settings.")
                    self._warned_no_channels = True
                return 0
            self._warned_no_channels = False
            sent = self._flush_baseline()
            now = time.time()
            pending = [j for j in self.db.pending_notifications(500, int(self.ecfg.get("max_notify_attempts", 12)))
                       if self._retry_after.get(j["uid"], 0.0) <= now]
            if not pending:
                return sent
            first_seen: dict[str, dict[str, Any]] = {}
            fresh = []
            for job in pending:  # collapse the same job posted on several *different* sources in one batch
                fp = job.get("fingerprint", "")
                prior = first_seen.get(fp)
                if fp and prior is not None and prior["source"] != job["source"]:
                    self.db.update_job(job["uid"], {"duplicate_of": prior["uid"]})
                    continue
                first_seen.setdefault(fp, job)
                fresh.append(job)
            cap = int(self.ecfg.get("max_individual_per_flush", 10))
            individual, rest = fresh[:cap], fresh[cap:]
            for job in individual:
                if self.notifier.notify_job(job):
                    sent += 1
                    self._retry_after.pop(job["uid"], None)
                else:
                    self._schedule_retry(job)
            if rest:
                channels = self.notifier.send_digest(rest, f"{len(rest)} more matching jobs")
                if channels:
                    self.db.mark_notified([j["uid"] for j in rest])
                    sent += len(rest)
                else:
                    for j in rest:
                        self.db.bump_attempts(j["uid"])
                        self._schedule_retry(j)
            return sent

    def _flush_baseline(self) -> int:
        """First run of a source: one summary (or nothing) instead of a flood of alerts."""
        rows = self.db.pending_baseline()
        if not rows or time.time() < self._baseline_retry_at:
            return 0
        mode = self.ecfg.get("first_run", "summary")
        if mode == "summary":
            top = rows[: int(self.ecfg.get("first_run_summary_top", 15))]
            title = f"Initial scan: {len(rows)} matching jobs already open (top {len(top)})"
            if not self.notifier.send_digest(top, title):
                log.warning("Initial summary could not be delivered on any channel; retrying in 60s")
                self._baseline_retry_at = time.time() + 60
                return 0
        self.db.mark_notified([r["uid"] for r in rows])
        self.db.add_event("baseline", None, None, f"{len(rows)} jobs marked as initial baseline ({mode})")
        return 0

    def maybe_daily_digest(self) -> bool:
        """Send the daily summary once per local day after ``digest_time``."""
        now_local = datetime.now(self.cfg.timezone)
        hh, mm = (int(x) for x in str(self.ecfg["digest_time"]).split(":"))
        if (now_local.hour, now_local.minute) < (hh, mm):
            return False
        today = now_local.date().isoformat()
        if self.db.get_meta("last_digest_date") == today:
            return False
        since = to_iso(utcnow() - timedelta(hours=24))
        rows = self.db.recent_matched(since, min_score=self.cfg.prefs.min_score)
        self.db.set_meta("last_digest_date", today)
        if not rows:
            return False
        self.notifier.send_digest(rows, f"Daily job summary: {len(rows)} new matches in the last 24h")
        return True

    # -- commands from the dashboard / CLI -------------------------------------------------------------
    def _handle_commands(self) -> None:
        for cmd in self.db.pop_commands():
            kind, arg = cmd["kind"], cmd.get("arg") or ""
            log.info("Command received: %s %s", kind, arg)
            if kind == "run_now":
                for name in ([arg] if arg else list(self.sources)):
                    if name in self.sources:
                        self._next_run[name] = 0.0
            elif kind == "rescore":
                n = self.pipeline.rescore_all()
                log.info("Re-scored all jobs; %d now match", n)
            elif kind == "digest":
                self.db.set_meta("last_digest_date", "")
                self.maybe_daily_digest()

    # -- loops --------------------------------------------------------------------------------------------
    def run_once(self) -> list[dict[str, Any]]:
        """Poll every enabled source one time (in parallel), then flush notifications."""
        names = [n for n in self.sources if not self.db.get_source_state(n).get("disabled_reason")]
        with ThreadPoolExecutor(max_workers=int(self.ecfg["workers"]), thread_name_prefix="src") as pool:
            outcomes = list(pool.map(self.run_source, names))
        self.flush_notifications()
        return outcomes

    def _submit(self, pool: ThreadPoolExecutor, name: str) -> None:
        with self._lock:
            if name in self._running:
                return
            self._running.add(name)

        def task() -> None:
            try:
                out = self.run_source(name)
                if out.get("ok"):
                    self._next_run[name] = time.time() + self._interval_with_jitter(self.sources[name].interval)
            finally:
                with self._lock:
                    self._running.discard(name)

        pool.submit(task)

    def run_forever(self) -> None:
        """Main loop; returns when :attr:`stop_event` is set."""
        self.schedule_initial()
        if not self._next_run:
            log.error("No enabled sources to monitor. Add some to config.yaml.")
        log.info("Monitoring %d source(s); Ctrl+C to stop", len(self._next_run))
        last_flush = 0.0
        with ThreadPoolExecutor(max_workers=int(self.ecfg["workers"]), thread_name_prefix="src") as pool:
            while not self.stop_event.is_set():
                try:
                    self._handle_commands()
                    now = time.time()
                    for name, due in list(self._next_run.items()):
                        if due <= now:
                            self._submit(pool, name)
                    if now - last_flush >= 5:
                        last_flush = now
                        self.flush_notifications()
                        self.maybe_daily_digest()
                except Exception:  # the supervisor loop itself must survive anything
                    log.exception("Supervisor loop error (continuing)")
                self.stop_event.wait(1.0)
            log.info("Stop requested: waiting for running fetches to finish (press Ctrl+C again to force quit)…")
        try:
            self.flush_notifications()
        except Exception:
            log.exception("Final flush failed")
