"""JobWatch: near-real-time job opening monitor with filtering and instant notifications."""

__version__ = "1.0.0"
