"""Turns the raw jobs returned by a source into stored, scored, de-duplicated records.

Responsibilities: enrich → evaluate → classify as new / updated / unchanged → persist →
detect jobs that disappeared (expiry). Notification is *not* done here; matched, un-notified
rows are picked up by the engine's flusher, so a crash between storing and notifying never
loses an alert.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any

from .db import Database
from .extract import enrich
from .matching import Matcher
from .models import Job
from .util import from_iso, to_iso, utcnow

log = logging.getLogger(__name__)


@dataclass
class ProcessResult:
    """Counters and details from processing one source fetch."""

    seen: int = 0
    new: int = 0
    new_matched: int = 0
    updated: int = 0
    apply_changed: list[dict[str, Any]] = field(default_factory=list)
    expired: list[dict[str, Any]] = field(default_factory=list)
    unchanged: int = 0
    warning: str = ""
    baseline: bool = False


def row_to_job(row: dict[str, Any]) -> Job:
    """Rebuild a :class:`Job` from a stored row (used when re-scoring after a preference change)."""
    return Job(
        source=row["source"], platform=row["platform"], external_id=row["external_id"], title=row["title"],
        company=row["company"], location=row["location"], description=row["description"], url=row["url"],
        apply_url=row["apply_url"], posted_at=from_iso(row["posted_at"]), deadline=from_iso(row["deadline"]),
        employment_type=row["employment_type"], work_mode=row["work_mode"], salary_text=row["salary_text"],
        department=row["department"], company_page=row["company_page"], experience_text=row["experience_text"],
        skills_required=row["skills_required"], skills_preferred=row["skills_preferred"], exp_min=row["exp_min"],
        exp_max=row["exp_max"], exp_inferred=bool(row["exp_inferred"]), salary_min_lpa=row["salary_min_lpa"],
        salary_max_lpa=row["salary_max_lpa"],
    )


class Pipeline:
    """Stateless processor bound to a database and a matcher."""

    def __init__(self, db: Database, matcher: Matcher, engine_cfg: dict[str, Any]):
        self.db = db
        self.matcher = matcher
        self.cfg = engine_cfg

    # -- row construction ----------------------------------------------------------------
    def _evaluate(self, job: Job) -> dict[str, Any]:
        res = self.matcher.evaluate(job)
        return {
            "score": res.score,
            "matched": 1 if res.matched else 0,
            "priority": 1 if res.priority else 0,
            "score_breakdown": {**res.breakdown, "_rejects": res.rejects, "_reasons": res.reasons},
        }

    def _content_fields(self, job: Job) -> dict[str, Any]:
        return {
            "title": job.title, "company": job.company, "location": job.location, "description": job.description,
            "url": job.url, "apply_url": job.apply_url, "company_page": job.company_page, "department": job.department,
            "employment_type": job.employment_type, "work_mode": job.work_mode, "salary_text": job.salary_text,
            "salary_min_lpa": job.salary_min_lpa, "salary_max_lpa": job.salary_max_lpa,
            "experience_text": job.experience_text, "exp_min": job.exp_min, "exp_max": job.exp_max,
            "exp_inferred": 1 if job.exp_inferred else 0, "skills_required": job.skills_required,
            "skills_preferred": job.skills_preferred, "posted_at": to_iso(job.posted_at), "deadline": to_iso(job.deadline),
            "content_hash": job.content_hash(), "apply_hash": job.apply_hash(), "fingerprint": job.fingerprint(),
        }

    # -- main entry ----------------------------------------------------------------------
    def process(self, source_name: str, jobs: list[Job], complete: bool = True) -> ProcessResult:
        """Persist one fetch. ``complete`` means the fetch lists *every* open job (enables expiry)."""
        res = ProcessResult(seen=len(jobs))
        known_total = len(self.db.known_external_ids(source_name))
        first_run = known_total == 0
        res.baseline = first_run and self.cfg.get("first_run", "summary") != "notify"
        now = to_iso(utcnow())
        seen_uids: set[str] = set()
        touch_only: list[str] = []

        for job in jobs:
            seen_uids.add(job.uid)
            existing = self.db.get_job(job.uid)
            stub = job.extra.get("partial") or job.extra.get("unchanged")
            if existing is not None and stub:
                touch_only.append(job.uid)
                res.unchanged += 1
                continue
            if existing is None and job.extra.get("unchanged"):
                continue  # cannot create a job from a stub without data

            enrich(job)
            if existing is None:
                self._insert(job, res, now)
                continue
            if existing["status"] == "expired":
                self.db.add_event("reappeared", job.source, job.uid, job.title)
            changed_content = existing["content_hash"] != job.content_hash()
            changed_apply = existing["apply_hash"] != job.apply_hash()
            if not changed_content and not changed_apply:
                touch_only.append(job.uid)
                res.unchanged += 1
                continue
            fields = self._content_fields(job)
            fields.update(self._evaluate(job))
            fields.update({"last_seen_at": now, "updated_at": now, "missing_count": 0, "status": "active"})
            if existing["notified_at"] is None and not existing["baseline"]:
                pass  # still pending: the new evaluation decides whether it is sent
            self.db.update_job(job.uid, fields)
            res.updated += 1
            if changed_apply:
                res.apply_changed.append({**existing, **fields})
                self.db.add_event("apply_url_changed", job.source, job.uid, f"{existing['apply_url']} -> {job.apply_url}")
            if changed_content:
                self.db.add_event("description_updated", job.source, job.uid, job.title)

        self.db.touch_seen(touch_only)

        if complete:
            active_before = self.db.active_count(source_name)
            if not jobs and active_before > 0:
                res.warning = (
                    f"source returned 0 jobs but {active_before} are stored as active: not expiring anything "
                    "(page structure may have changed or the board is temporarily empty)"
                )
            elif jobs:
                res.expired = self.db.mark_missing(source_name, seen_uids, int(self.cfg.get("expire_after_misses", 3)))
                for ex in res.expired:
                    self.db.add_event("expired", source_name, ex["uid"], ex["title"])
        return res

    def _insert(self, job: Job, res: ProcessResult, now: str) -> None:
        ev = self._evaluate(job)
        if not ev["matched"] and not self.cfg.get("store_rejected", True):
            return
        dup = self.db.duplicate_notified(job.fingerprint(), job.uid, job.source) if ev["matched"] else None
        row = {
            "uid": job.uid, "source": job.source, "platform": job.platform, "external_id": job.external_id,
            **self._content_fields(job), **ev,
            "discovered_at": now, "last_seen_at": now, "status": "active", "baseline": 1 if res.baseline else 0,
            "duplicate_of": dup,
        }
        self.db.insert_job(row)
        res.new += 1
        if ev["matched"]:
            res.new_matched += 1
            self.db.add_event("new_match", job.source, job.uid, f"{job.title} @ {job.company} [{ev['score']}]")

    # -- re-scoring --------------------------------------------------------------------------
    def rescore_all(self) -> int:
        """Re-evaluate every stored active job after the preferences changed. Returns jobs now matched.

        Jobs that become matched are *not* flagged as baseline, so they are notified normally unless
        they were already notified before.
        """
        count = 0
        offset = 0
        while True:
            rows, _ = self.db.query_jobs(matched_only=False, status="active", sort="discovered", limit=500, offset=offset)
            if not rows:
                break
            for row in rows:
                job = row_to_job(row)
                ev = self._evaluate(job)
                self.db.update_job(row["uid"], ev)
                count += ev["matched"]
            offset += len(rows)
        return count


def breakdown_for_display(raw: dict[str, Any]) -> tuple[dict[str, float], list[str], list[str]]:
    """Split a stored ``score_breakdown`` into (components, reasons, rejects)."""
    comps = {k: v for k, v in (raw or {}).items() if not k.startswith("_")}
    return comps, list((raw or {}).get("_reasons", [])), list((raw or {}).get("_rejects", []))


def dumps(obj: Any) -> str:
    return json.dumps(obj, default=str)
