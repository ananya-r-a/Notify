"""Ashby public Job Postings API (https://developers.ashbyhq.com/docs/public-job-posting-api)."""

from __future__ import annotations

from urllib.parse import urlsplit

from ..extract import join_unique
from ..models import Job
from ..textutil import clean_line, html_to_text
from ..util import parse_dt
from .base import Source


class AshbySource(Source):
    """``GET /posting-api/job-board/{board}`` — official, unauthenticated, JSON.

    Config: ``board`` (``jobs.ashbyhq.com/<board>``), optional ``company``.
    The documented schema has no ``id`` field, so the id is taken from ``jobUrl``.
    """

    platform = "ashby"
    required = ("board",)
    default_interval = 300

    def fetch(self) -> list[Job]:
        base = self.cfg.get("api_base", "https://api.ashbyhq.com").rstrip("/")
        board = self.cfg["board"]
        data = self.http.get_json(f"{base}/posting-api/job-board/{board}", params={"includeCompensation": "true"})
        company = self.company or board.replace("-", " ").title()
        jobs: list[Job] = []
        for item in data.get("jobs", []):
            if item.get("isListed") is False:
                continue
            job_url = item.get("jobUrl", "")
            ext = str(item.get("id") or urlsplit(job_url).path.rstrip("/").rsplit("/", 1)[-1] or item.get("title", ""))
            secondary = [s.get("location", "") for s in item.get("secondaryLocations") or []]
            html = item.get("descriptionHtml") or ""
            comp = item.get("compensation") or data.get("compensation") or {}
            salary = ""
            if isinstance(comp, dict):
                salary = comp.get("scrapeableCompensationSalarySummary") or comp.get("compensationTierSummary") or ""
            jobs.append(
                self.make_job(
                    external_id=ext,
                    title=clean_line(item.get("title")),
                    company=company,
                    location=join_unique([item.get("location", ""), *secondary]),
                    description=html_to_text(html) if html else (item.get("descriptionPlain") or ""),
                    url=job_url,
                    apply_url=item.get("applyUrl") or job_url,
                    posted_at=parse_dt(item.get("publishedAt")),
                    employment_type=item.get("employmentType", ""),
                    work_mode=item.get("workplaceType", ""),
                    department=join_unique([item.get("department", ""), item.get("team", "")]),
                    salary_text=salary,
                )
            )
        return jobs
