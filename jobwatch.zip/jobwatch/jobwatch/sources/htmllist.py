"""Configurable CSS-selector adapter for company, startup and government career/notification pages."""

from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urldefrag, urljoin, urlsplit

from bs4 import BeautifulSoup

from ..models import Job, SourceError
from ..textutil import clean_line
from ..util import sha1
from .base import Source

log = logging.getLogger(__name__)


class HtmlListSource(Source):
    """Scrape a page that lists openings, using CSS selectors from the config.

    Config keys:

    * ``url`` / ``urls`` — page(s) to fetch (required)
    * ``item_selector`` — CSS selector matching one element per opening (required)
    * ``title_selector`` — relative to the item; default: the first link's text
    * ``link_selector`` — relative to the item; default ``a[href]``
    * ``location_selector`` — relative to the item (optional)
    * ``company`` / ``assume_location`` — fixed values when the page does not show them
    * ``id_from`` — ``link`` (default) or ``title`` to build the stable id

    The whole text of the item is stored as the description, so experience/skill extraction
    works on whatever the row shows. HTML structure changes are detected indirectly: if a
    previously non-empty page suddenly yields zero items the engine raises a warning instead
    of expiring every job.
    """

    platform = "htmllist"
    default_interval = 900

    @classmethod
    def validate(cls, cfg: dict[str, Any]) -> list[str]:
        problems = []
        if not (cfg.get("url") or cfg.get("urls")):
            problems.append("missing required key 'url' (or 'urls')")
        if not cfg.get("item_selector"):
            problems.append("missing required key 'item_selector'")
        return problems

    @classmethod
    def default_name(cls, cfg: dict[str, Any]) -> str:
        url = cfg.get("url") or (cfg.get("urls") or [""])[0]
        return f"htmllist:{urlsplit(url).netloc or 'page'}"

    def fetch(self) -> list[Job]:
        urls = self.cfg.get("urls") or [self.cfg["url"]]
        conditional = len(urls) == 1
        jobs: dict[str, Job] = {}
        for url in urls:
            resp = self.http.get(url, conditional=conditional, check_robots=True)
            soup = BeautifulSoup(resp.text, "lxml")
            for item in soup.select(self.cfg["item_selector"]):
                job = self._parse_item(item, url)
                if job:
                    jobs[job.external_id] = job
        return list(jobs.values())

    def _parse_item(self, item: Any, page_url: str) -> Job | None:
        link_sel = self.cfg.get("link_selector", "a[href]")
        a = item.select_one(link_sel)
        href = urldefrag(urljoin(page_url, a["href"]))[0] if a is not None and a.get("href") else ""
        title_sel = self.cfg.get("title_selector")
        title_el = item.select_one(title_sel) if title_sel else a
        title = clean_line(title_el.get_text(" ") if title_el is not None else "")
        if not title:
            return None
        loc_sel = self.cfg.get("location_selector")
        location = clean_line(item.select_one(loc_sel).get_text(" ")) if loc_sel and item.select_one(loc_sel) else ""
        ident = href if (self.cfg.get("id_from", "link") == "link" and href) else sha1(title, self.company)
        return self.make_job(
            external_id=ident,
            title=title,
            location=location,
            description=clean_line(item.get_text(" ")),
            url=href or page_url,
        )
