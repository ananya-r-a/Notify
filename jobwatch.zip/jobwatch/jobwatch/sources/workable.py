"""Workable public widget API (``apply.workable.com/api/v1/widget/accounts/{slug}``)."""

from __future__ import annotations

from ..extract import join_unique
from ..models import Job
from ..textutil import clean_line, html_to_text
from ..util import parse_dt
from .base import Source


class WorkableSource(Source):
    """Public, unauthenticated JSON used by Workable-hosted career pages.

    Config: ``account`` (the slug in ``apply.workable.com/<account>``), optional ``company``.
    Every field is read defensively because Workable does not publish a formal schema for
    this endpoint.
    """

    platform = "workable"
    required = ("account",)
    default_interval = 600

    def fetch(self) -> list[Job]:
        base = self.cfg.get("api_base", "https://apply.workable.com").rstrip("/")
        account = self.cfg["account"]
        data = self.http.get_json(f"{base}/api/v1/widget/accounts/{account}", params={"details": "true"})
        company = self.company or data.get("name") or account.replace("-", " ").title()
        jobs: list[Job] = []
        for item in data.get("jobs", []):
            ext = str(item.get("shortcode") or item.get("id") or item.get("shortlink") or item.get("url") or item.get("title"))
            locs = []
            for loc in item.get("locations") or []:
                locs.append(", ".join(x for x in (loc.get("city"), loc.get("region") or loc.get("state_code"), loc.get("country_name") or loc.get("country")) if x))
            if not locs:
                locs.append(", ".join(x for x in (item.get("city"), item.get("state"), item.get("country")) if x))
            if (item.get("telecommuting") or (item.get("location") or {}).get("telecommuting")) and not any("remote" in l.lower() for l in locs):
                locs.append("Remote")
            mode = (item.get("location") or {}).get("workplace_type") or ("remote" if item.get("telecommuting") else "")
            url = item.get("url") or item.get("shortlink") or ""
            jobs.append(
                self.make_job(
                    external_id=ext,
                    title=clean_line(item.get("title")),
                    company=company,
                    location=join_unique(locs),
                    description=html_to_text(item.get("description") or item.get("full_description")),
                    url=url,
                    apply_url=item.get("application_url") or url,
                    posted_at=parse_dt(item.get("published_on") or item.get("created_at")),
                    employment_type=item.get("employment_type", ""),
                    work_mode=mode,
                    department=item.get("department", "") if isinstance(item.get("department"), str) else "",
                    experience_text=item.get("experience", "") if isinstance(item.get("experience"), str) else "",
                )
            )
        return jobs
