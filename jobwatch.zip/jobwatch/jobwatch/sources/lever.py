"""Lever public Postings API (https://github.com/lever/postings-api)."""

from __future__ import annotations

from ..extract import join_unique
from ..models import Job
from ..textutil import clean_line, html_to_text
from ..util import parse_dt
from .base import Source


class LeverSource(Source):
    """``GET /v0/postings/{site}?mode=json`` — official, unauthenticated, JSON.

    Config: ``site`` (``jobs.lever.co/<site>``), optional ``api_base`` (use
    ``https://api.eu.lever.co`` for EU-hosted accounts) and ``company``.
    """

    platform = "lever"
    required = ("site",)
    default_interval = 300

    PAGE = 100

    def fetch(self) -> list[Job]:
        base = self.cfg.get("api_base", "https://api.lever.co").rstrip("/")
        site = self.cfg["site"]
        company = self.company or site.replace("-", " ").title()
        items: list = []
        skip = 0
        for _ in range(int(self.cfg.get("max_pages", 30))):
            page = self.http.get_json(f"{base}/v0/postings/{site}", params={"mode": "json", "limit": self.PAGE, "skip": skip})
            if not isinstance(page, list):
                raise ValueError("Lever returned an unexpected payload (expected a JSON list)")
            items.extend(page)
            if len(page) < self.PAGE:
                break
            skip += self.PAGE

        jobs: list[Job] = []
        for item in items:
            cats = item.get("categories") or {}
            parts = [item.get("descriptionPlain") or html_to_text(item.get("description"))]
            for section in item.get("lists") or []:
                parts.append(f"{section.get('text', '')}\n{html_to_text(section.get('content'))}")
            parts.append(item.get("additionalPlain") or html_to_text(item.get("additional")))
            salary = ""
            sr = item.get("salaryRange")
            if isinstance(sr, dict) and sr.get("min") and sr.get("max"):
                salary = f"{sr.get('currency', '')} {sr['min']:,} - {sr['max']:,}".strip()
                if "year" in str(sr.get("interval", "")).lower():
                    salary += " per year"
            jobs.append(
                self.make_job(
                    external_id=str(item["id"]),
                    title=clean_line(item.get("text")),
                    company=company,
                    location=join_unique([cats.get("location", ""), *(cats.get("allLocations") or [])]),
                    description="\n\n".join(p for p in parts if p).strip(),
                    url=item.get("hostedUrl", ""),
                    apply_url=item.get("applyUrl") or item.get("hostedUrl", ""),
                    posted_at=parse_dt(item.get("createdAt")),
                    employment_type=cats.get("commitment", ""),
                    work_mode=item.get("workplaceType", ""),
                    department=join_unique([cats.get("department", ""), cats.get("team", "")]),
                    salary_text=salary,
                )
            )
        return jobs
