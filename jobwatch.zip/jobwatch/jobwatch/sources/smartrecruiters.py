"""SmartRecruiters public Posting API (https://developers.smartrecruiters.com/reference/v1listpostings)."""

from __future__ import annotations

import logging

from ..extract import join_unique
from ..models import Job, SourceError
from ..textutil import clean_line, html_to_text
from ..util import parse_dt
from .base import Source

log = logging.getLogger(__name__)

_COUNTRIES = {"in": "India", "us": "United States", "gb": "United Kingdom", "de": "Germany", "sg": "Singapore"}


class SmartRecruitersSource(Source):
    """``GET /v1/companies/{id}/postings`` (max 100 per page) plus optional per-posting detail.

    Config: ``company_id`` (case-sensitive identifier, e.g. ``BoschGroup``), optional
    server-side filters ``country`` (e.g. ``in``), ``city``, ``q``; ``fetch_details``
    (default true) adds the description for *new* postings only (``max_details`` per run).
    The list response carries no description, so detail calls are what make skill and
    experience matching possible.
    """

    platform = "smartrecruiters"
    required = ("company_id",)
    default_interval = 600
    PAGE = 100

    def fetch(self) -> list[Job]:
        base = self.cfg.get("api_base", "https://api.smartrecruiters.com").rstrip("/")
        cid = self.cfg["company_id"]
        params: dict[str, object] = {"limit": self.PAGE}
        for key in ("country", "region", "city", "q"):
            if self.cfg.get(key):
                params[key] = self.cfg[key]
        items: list[dict] = []
        offset = 0
        for _ in range(int(self.cfg.get("max_pages", 30))):
            params["offset"] = offset
            page = self.http.get_json(f"{base}/v1/companies/{cid}/postings", params=params)
            content = page.get("content") or []
            items.extend(content)
            offset += len(content)
            if not content or offset >= int(page.get("totalFound", 0)):
                break

        want_details = bool(self.cfg.get("fetch_details", True))
        budget = int(self.cfg.get("max_details", 30))
        jobs: list[Job] = []
        for item in items:
            ext = str(item.get("id") or item.get("uuid"))
            loc = item.get("location") or {}
            country = _COUNTRIES.get(str(loc.get("country", "")).lower(), str(loc.get("country", "")).upper())
            location = join_unique([loc.get("city", ""), loc.get("region", ""), country], sep=", ")
            mode = "remote" if loc.get("remote") else ("hybrid" if loc.get("hybrid") else "")
            company = (item.get("company") or {}).get("name") or self.company or cid
            public_url = f"https://jobs.smartrecruiters.com/{cid}/{ext}"
            description, apply_url, partial = "", public_url, False

            if want_details:
                if ext in self.known_ids:
                    partial = True  # keep the stored description; no request needed
                elif budget > 0:
                    budget -= 1
                    try:
                        detail = self.http.get_json(f"{base}/v1/companies/{cid}/postings/{ext}")
                        sections = ((detail.get("jobAd") or {}).get("sections")) or {}
                        description = "\n\n".join(
                            f"{(s.get('title') or '')}\n{html_to_text(s.get('text'))}"
                            for s in sections.values()
                            if isinstance(s, dict) and s.get("text")
                        )
                        public_url = detail.get("postingUrl") or public_url
                        apply_url = detail.get("applyUrl") or public_url
                    except SourceError as e:
                        log.warning("[%s] detail fetch failed for %s: %s", self.name, ext, e)

            jobs.append(
                self.make_job(
                    external_id=ext,
                    title=clean_line(item.get("name")),
                    company=company,
                    location=location,
                    description=description,
                    url=public_url,
                    apply_url=apply_url,
                    posted_at=parse_dt(item.get("releasedDate")),
                    employment_type=(item.get("typeOfEmployment") or {}).get("label", ""),
                    work_mode=mode,
                    department=(item.get("department") or {}).get("label", ""),
                    extra={"partial": partial, "experience_level": (item.get("experienceLevel") or {}).get("name", "")},
                )
            )
        return jobs
