"""Greenhouse public Job Board API (https://developers.greenhouse.io/job-board.html)."""

from __future__ import annotations

from ..extract import join_unique
from ..models import Job
from ..textutil import clean_line, html_to_text
from .base import Source


class GreenhouseSource(Source):
    """``GET /v1/boards/{board}/jobs?content=true`` — official, unauthenticated, JSON.

    Config: ``board`` (the token in ``boards.greenhouse.io/<board>``), optional ``company``.
    Note: the list endpoint has no ``first_published``; ``posted_at`` stays unknown and the
    ``updated_at`` value is kept in ``extra``.
    """

    platform = "greenhouse"
    required = ("board",)
    default_interval = 300

    def fetch(self) -> list[Job]:
        base = self.cfg.get("api_base", "https://boards-api.greenhouse.io").rstrip("/")
        board = self.cfg["board"]
        data = self.http.get_json(f"{base}/v1/boards/{board}/jobs", params={"content": "true"})
        company = self.company or board.replace("-", " ").title()
        jobs: list[Job] = []
        for item in data.get("jobs", []):
            loc = (item.get("location") or {}).get("name", "")
            offices = [o.get("location") or o.get("name") or "" for o in item.get("offices") or []]
            departments = [d.get("name", "") for d in item.get("departments") or []]
            url = item.get("absolute_url", "")
            jobs.append(
                self.make_job(
                    external_id=str(item["id"]),
                    title=clean_line(item.get("title")),
                    company=company,
                    location=join_unique([loc, *offices]),
                    description=html_to_text(item.get("content")),
                    url=url,
                    apply_url=url,
                    department=join_unique(departments),
                    extra={"updated_at": item.get("updated_at"), "requisition_id": item.get("requisition_id")},
                )
            )
        return jobs
