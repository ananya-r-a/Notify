"""Source adapter registry."""

from __future__ import annotations

from typing import Any

from ..config import ConfigError
from ..httpclient import HttpClient
from .ashby import AshbySource
from .base import Source
from .email_alerts import ImapAlertSource
from .greenhouse import GreenhouseSource
from .hn_hiring import HNHiringSource
from .htmllist import HtmlListSource
from .jsonld import JsonLdSource
from .lever import LeverSource
from .rss import RssSource
from .smartrecruiters import SmartRecruitersSource
from .workable import WorkableSource
from .workday import WorkdaySource

SOURCE_TYPES: dict[str, type[Source]] = {
    "greenhouse": GreenhouseSource,
    "lever": LeverSource,
    "ashby": AshbySource,
    "smartrecruiters": SmartRecruitersSource,
    "workable": WorkableSource,
    "workday": WorkdaySource,
    "jsonld": JsonLdSource,
    "htmllist": HtmlListSource,
    "rss": RssSource,
    "hn_hiring": HNHiringSource,
    "email_alerts": ImapAlertSource,
}

__all__ = ["SOURCE_TYPES", "Source", "build_sources"]


def build_sources(entries: list[dict[str, Any]], http: HttpClient, min_interval: int = 60) -> list[Source]:
    """Instantiate enabled sources from config entries, validating all of them first.

    Raises :class:`ConfigError` listing *every* problem so the user can fix them in one pass.
    """
    problems: list[str] = []
    sources: list[Source] = []
    names: set[str] = set()
    for i, entry in enumerate(entries):
        if entry.get("enabled", True) is False:
            continue
        stype = str(entry.get("type"))
        cls = SOURCE_TYPES.get(stype)
        label = f"sources[{i}] ({stype})"
        if cls is None:
            problems.append(f"{label}: unknown type; choose one of {', '.join(sorted(SOURCE_TYPES))}")
            continue
        errs = cls.validate(entry)
        if errs:
            problems.extend(f"{label}: {e}" for e in errs)
            continue
        name = str(entry.get("name") or cls.default_name(entry))
        if name in names:
            problems.append(f"{label}: duplicate source name '{name}' (set a unique 'name')")
            continue
        names.add(name)
        src = cls(name, entry, http)
        src.interval = max(int(min_interval), src.interval)
        sources.append(src)
    if problems:
        raise ConfigError("Invalid source configuration:\n  - " + "\n  - ".join(problems))
    return sources
