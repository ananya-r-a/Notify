"""Base class and helpers shared by every source adapter."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar

from ..httpclient import HttpClient
from ..models import Job


class Source(ABC):
    """One independent job source (a company board, a feed, a mailbox, …).

    Subclasses implement :meth:`fetch`, which returns **every currently open job** the
    source exposes (set ``complete_listing = False`` for sources that only return a
    window of recent items, which disables expiry detection for them).

    Adapters must never swallow errors: raise :class:`~jobwatch.models.SourceError`
    (or a subclass) so the engine can log, back off and report them.
    """

    platform: ClassVar[str] = "base"
    complete_listing: ClassVar[bool] = True
    default_interval: ClassVar[int] = 300
    required: ClassVar[tuple[str, ...]] = ()

    def __init__(self, name: str, cfg: dict[str, Any], http: HttpClient):
        self.name = name
        self.cfg = cfg
        self.http = http
        self.company: str = cfg.get("company", "")
        self.interval: int = int(cfg.get("interval", self.default_interval))
        self.assume_location: str = cfg.get("assume_location", "")
        #: external ids of jobs already stored *with* a description; adapters may use it to
        #: skip expensive per-job detail requests (and then flag the job ``extra['partial']``).
        self.known_ids: set[str] = set()

    # -- naming / validation ------------------------------------------------------------
    @classmethod
    def default_name(cls, cfg: dict[str, Any]) -> str:
        key = next((str(cfg[k]) for k in cls.required if cfg.get(k)), "")
        return f"{cls.platform}:{key}" if key else cls.platform

    @classmethod
    def validate(cls, cfg: dict[str, Any]) -> list[str]:
        """Return a list of human-readable config problems (empty when valid)."""
        return [f"missing required key '{k}'" for k in cls.required if not cfg.get(k)]

    # -- API ----------------------------------------------------------------------------
    @abstractmethod
    def fetch(self) -> list[Job]:
        """Fetch and normalise all currently open jobs."""

    def make_job(self, **fields: Any) -> Job:
        """Create a :class:`Job` stamped with this source's identity and fallbacks."""
        fields.setdefault("company", self.company)
        job = Job(source=self.name, platform=self.platform, **fields)
        if not job.location and self.assume_location:
            job.location = self.assume_location
            job.extra["location_assumed"] = True
        if not job.company_page:
            job.company_page = self.cfg.get("company_page", "")
        if not job.apply_url:
            job.apply_url = job.url
        return job
