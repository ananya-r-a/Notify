"""Hacker News monthly "Ask HN: Who is hiring?" threads (startup hiring announcements).

Uses the official, documented HN Search API (https://hn.algolia.com/api). Comments are
posted live, so new announcements are picked up within one polling interval.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup

from ..models import Job, SourceError
from ..textutil import clean_line, html_to_text
from ..util import parse_dt, sha1
from .base import Source

_ROLE = re.compile(
    r"engineer|developer|scientist|architect|devops|sre|researcher|full[- ]?stack|back[- ]?end|front[- ]?end|"
    r"\bml\b|\bai\b|embedded|firmware|programmer|\bsde\b|data ",
    re.I,
)
_LOC = re.compile(r"remote|onsite|on-site|hybrid|bangalore|bengaluru|india|[A-Z][a-z]+,\s*[A-Z]{2}\b", re.I)


class HNHiringSource(Source):
    """Config (all optional): ``keywords`` (default bengaluru, bangalore, india, remote),
    ``max_pages`` of 1000 comments (default 4), ``api_base``.
    """

    platform = "hn_hiring"
    default_interval = 900
    complete_listing = False  # a monthly thread is a stream of posts, not a roster

    def fetch(self) -> list[Job]:
        base = self.cfg.get("api_base", "https://hn.algolia.com").rstrip("/")
        stories = self.http.get_json(
            f"{base}/api/v1/search_by_date",
            params={"query": "Ask HN: Who is hiring?", "tags": "story,author_whoishiring", "hitsPerPage": 6},
        )
        story = next((h for h in stories.get("hits", []) if str(h.get("title", "")).lower().startswith("ask hn: who is hiring")), None)
        if story is None:
            raise SourceError("Could not find the current 'Ask HN: Who is hiring?' thread")
        story_id = str(story["objectID"])

        keywords = [k.lower() for k in self.cfg.get("keywords", ["bengaluru", "bangalore", "india", "remote"])]
        kw_rx = re.compile(r"(?<![a-z0-9])(?:" + "|".join(re.escape(k) for k in keywords) + r")(?![a-z0-9])", re.I) if keywords else None

        jobs: list[Job] = []
        page = 0
        while page < int(self.cfg.get("max_pages", 4)):
            data = self.http.get_json(
                f"{base}/api/v1/search_by_date",
                params={"tags": f"comment,story_{story_id}", "hitsPerPage": 1000, "page": page},
            )
            for hit in data.get("hits", []):
                if str(hit.get("parent_id")) != story_id or not hit.get("comment_text"):
                    continue  # replies to postings are not postings
                if kw_rx and not kw_rx.search(html_to_text(hit["comment_text"])):
                    continue
                jobs.append(self._to_job(hit))
            page += 1
            if page >= int(data.get("nbPages", 1)):
                break
        return jobs

    def _to_job(self, hit: dict[str, Any]) -> Job:
        html = hit["comment_text"]
        text = html_to_text(html)
        header = clean_line(text.split("\n", 1)[0])
        parts = [p.strip() for p in header.split("|")]
        lines = [clean_line(x) for x in text.split("\n") if x.strip()][:8]
        company = parts[0][:80] if parts else "Unknown"
        title = next((p for p in parts[1:] if _ROLE.search(p)), "")
        if not title:  # free-form post: take the first early line that names a role
            title = next((ln[:110] for ln in lines if _ROLE.search(ln)), "")
        if not title:
            title = header[:140] if len(parts) == 1 else (parts[1] if len(parts) > 1 else header)
        location = next((p for p in parts[1:] if _LOC.search(p)), "")
        if not location:  # e.g. "Location: Bangalore, India" as the first line, or a later "Location:" line
            location = next((re.sub(r"^location\s*:\s*", "", ln, flags=re.I)[:80] for ln in lines if _LOC.search(ln)), "")
        soup = BeautifulSoup(html, "lxml")
        apply_url = next((a["href"] for a in soup.find_all("a", href=True) if "ycombinator.com" not in a["href"]), "")
        url = f"https://news.ycombinator.com/item?id={hit['objectID']}"
        return self.make_job(
            external_id=str(hit["objectID"]),
            title=title,
            company=company,
            location=location or ("Remote" if re.search(r"\bremote\b", header, re.I) else ""),
            description=text,
            url=url,
            apply_url=apply_url or url,
            posted_at=parse_dt(hit.get("created_at")),
            extra={"author": hit.get("author"), "header": header, "fp": sha1(header)},
        )