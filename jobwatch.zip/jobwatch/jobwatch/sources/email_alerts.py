"""Ingest job-alert emails from big portals through IMAP (read-only).

LinkedIn, Naukri, Indeed, Foundit, Instahyre, Cutshort, Wellfound and Work at a Startup
offer no public job-search API and their terms forbid scraping. Each of them *does* e-mail
saved-search alerts. This adapter reads those alerts from your own mailbox and turns every
job link into a normalised job, so the platforms stay in the loop without being scraped.

How fresh the data is depends on the alert frequency you pick on each platform (most offer
"instant"/"as soon as posted" for at least some searches, otherwise daily).
"""

from __future__ import annotations

import email
import imaplib
import logging
import re
from datetime import timedelta
from email.header import decode_header, make_header
from email.message import Message
from email.utils import parseaddr
from typing import Any, Callable
from urllib.parse import parse_qs, urlsplit

from bs4 import BeautifulSoup

from ..models import Job, SourceError
from ..textutil import clean_line
from ..util import parse_dt, utcnow
from .base import Source

log = logging.getLogger(__name__)


def _linkedin(m: re.Match[str], url: str) -> tuple[str, str]:
    return m.group(1), f"https://www.linkedin.com/jobs/view/{m.group(1)}"


def _generic(m: re.Match[str], url: str) -> tuple[str, str]:
    return m.group(1), url.split("?")[0].split("#")[0]


def _indeed(m: re.Match[str], url: str) -> tuple[str, str]:
    host = urlsplit(url).netloc or "in.indeed.com"
    host = host if host.endswith("indeed.com") and not host.startswith("cts.") else "in.indeed.com"
    return m.group(1), f"https://{host}/viewjob?jk={m.group(1)}"


#: platform → (host regex, path/query regex capturing the id, canonicaliser). Alert-email link
#: formats are controlled by the platforms and change; extend via ``extra_patterns`` in the config.
PLATFORM_PATTERNS: list[tuple[str, re.Pattern[str], re.Pattern[str], Callable[[re.Match[str], str], tuple[str, str]]]] = [
    ("linkedin", re.compile(r"(?:^|\.)linkedin\.com$"), re.compile(r"/(?:comm/)?jobs/view/(?:[^/?#]*?-)?(\d{6,})"), _linkedin),
    ("naukri", re.compile(r"(?:^|\.)naukri\.com$"), re.compile(r"job-listings-[^?#]*?-(\d{9,})"), _generic),
    ("indeed", re.compile(r"(?:^|\.)indeed\.com$"), re.compile(r"[?&]jk=([0-9a-fA-F]{8,})"), _indeed),
    ("foundit", re.compile(r"(?:^|\.)foundit\.in$"), re.compile(r"/job/[^?#]*?-(\d{5,})"), _generic),
    ("instahyre", re.compile(r"(?:^|\.)instahyre\.com$"), re.compile(r"/job-(\d+)-"), _generic),
    ("cutshort", re.compile(r"(?:^|\.)cutshort\.io$"), re.compile(r"/job/([A-Za-z0-9-]{6,})"), _generic),
    ("wellfound", re.compile(r"(?:^|\.)(?:wellfound\.com|angel\.co)$"), re.compile(r"/jobs/(\d+)"), _generic),
    ("workatastartup", re.compile(r"(?:^|\.)workatastartup\.com$"), re.compile(r"/jobs/(\d+)"), _generic),
]

DEFAULT_SENDER_DOMAINS = [
    "linkedin.com", "naukri.com", "indeed.com", "foundit.in", "monsterindia.com", "instahyre.com",
    "cutshort.io", "wellfound.com", "angel.co", "workatastartup.com", "ycombinator.com",
]

_GENERIC_TEXT = re.compile(
    r"^(?:apply(?: now| on [a-z ]+)?|easy apply|view(?: job| jobs| details)?|see (?:more|job|details)|view all jobs?|"
    r"unsubscribe|learn more|click here|more jobs|job alert|manage alerts?|save|share|here)$",
    re.I,
)
_URLISH = re.compile(r"https?://|www\.|^\W+$", re.I)


def decode_mime(value: str | None) -> str:
    """Decode an RFC-2047 header value to plain text."""
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except Exception:  # malformed header: fall back to the raw value
        return value


def _classify(url: str, extra: list[Any] | None = None) -> tuple[str, str, str] | None:
    """Return ``(platform, job_id, canonical_url)`` when ``url`` is a recognised job link."""
    parts = urlsplit(url)
    host = parts.netloc.lower().split("@")[-1].split(":")[0]
    target = f"{parts.path}?{parts.query}" if parts.query else parts.path
    for platform, host_rx, id_rx, canon in [*PLATFORM_PATTERNS, *(extra or [])]:
        if host_rx.search(host):
            m = id_rx.search(target) or id_rx.search(url)
            if m:
                job_id, canonical = canon(m, url)
                return platform, job_id, canonical
    # redirect wrappers such as ?url=https%3A%2F%2F…
    for values in parse_qs(parts.query).values():
        for v in values:
            if v.startswith("http") and v != url:
                found = _classify(v, extra)
                if found:
                    return found
    return None


def _message_html(msg: Message) -> tuple[str, str]:
    html, text = "", ""
    for part in msg.walk() if msg.is_multipart() else [msg]:
        ctype = part.get_content_type()
        if ctype not in ("text/html", "text/plain"):
            continue
        payload = part.get_payload(decode=True)
        if payload is None:
            continue
        body = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
        if ctype == "text/html" and not html:
            html = body
        elif ctype == "text/plain" and not text:
            text = body
    return html, text


def _context_lines(anchor: Any, own_ids: set[str], extra: list[Any] | None) -> list[str]:
    """Lines of text around the title anchor inside the smallest block holding only this job."""
    node, best = anchor, anchor
    for _ in range(5):
        parent = node.parent
        if parent is None or parent.name in ("body", "html", "[document]"):
            break
        other_job = False
        for a in parent.find_all("a", href=True):
            c = _classify(a["href"], extra)
            if c and c[1] not in own_ids:
                other_job = True
                break
        if other_job:
            break
        node = best = parent
    lines = [clean_line(x) for x in best.get_text("\n").split("\n")]
    return [x for x in lines if x]


def parse_alert_message(msg: Message, extra_patterns: list[Any] | None = None) -> list[dict[str, Any]]:
    """Extract job records from one alert e-mail.

    Returns dicts with ``platform, job_id, url, title, company, location, description, posted_at``.
    URLs and ids are reliable; ``company``/``location`` come from the text around the link and are
    best-effort (they may be empty).
    """
    html, text = _message_html(msg)
    posted = parse_dt(msg.get("Date"))
    jobs: dict[tuple[str, str], dict[str, Any]] = {}

    if html:
        soup = BeautifulSoup(html, "lxml")
        groups: dict[tuple[str, str], list[Any]] = {}
        meta: dict[tuple[str, str], str] = {}
        for a in soup.find_all("a", href=True):
            c = _classify(a["href"], extra_patterns)
            if c:
                key = (c[0], c[1])
                groups.setdefault(key, []).append(a)
                meta[key] = c[2]
        for key, anchors in groups.items():
            texts = [(clean_line(a.get_text(" ")), a) for a in anchors]
            texts = [(t, a) for t, a in texts if len(t) >= 4 and not _GENERIC_TEXT.match(t) and not _URLISH.search(t)]
            if not texts:
                continue
            title, title_anchor = max(texts, key=lambda ta: len(ta[0]))
            lines = _context_lines(title_anchor, {key[1]}, extra_patterns)
            company = location = ""
            if title in lines:
                after = [x for x in lines[lines.index(title) + 1 :] if not _GENERIC_TEXT.match(x) and not _URLISH.search(x)][:3]
                if after:
                    first = after[0]
                    if " · " in first:
                        company, _, location = (s.strip() for s in first.partition(" · "))
                    else:
                        company = first
                        if len(after) > 1 and len(after[1]) < 80:
                            location = after[1]
            jobs[key] = {
                "platform": key[0], "job_id": key[1], "url": meta[key], "title": title, "company": company,
                "location": location, "description": " ".join(lines)[:3000], "posted_at": posted,
            }
    else:  # plain-text alert: use "Title\nCompany\nURL" layout
        lines = [x.strip() for x in text.splitlines()]
        for i, line in enumerate(lines):
            for m in re.finditer(r"https?://\S+", line):
                url = m.group(0).rstrip(").,>")
                c = _classify(url, extra_patterns)
                if not c or (c[0], c[1]) in jobs:
                    continue
                prev = [x for x in lines[max(0, i - 3) : i] if x and not _URLISH.search(x)]
                jobs[(c[0], c[1])] = {
                    "platform": c[0], "job_id": c[1], "url": c[2], "title": prev[0] if prev else "",
                    "company": prev[1] if len(prev) > 1 else "", "location": "",
                    "description": " ".join(prev), "posted_at": posted,
                }
    return [j for j in jobs.values() if j["title"]]


class ImapAlertSource(Source):
    """Read-only IMAP reader for job-alert e-mails.

    Config: ``host``, ``username``, ``password`` (use an app password), optional ``port``
    (993), ``security`` (``ssl`` | ``starttls`` | ``none``), ``folder`` (INBOX),
    ``lookback_days`` (3), ``sender_domains`` (default: the platforms above),
    ``assume_location`` (e.g. ``Bengaluru``: alerts you created for Bengaluru searches),
    ``max_messages`` (150). The mailbox is opened read-only; nothing is marked read or deleted.
    """

    platform = "email_alerts"
    required = ("host", "username")
    default_interval = 120
    complete_listing = False

    def __init__(self, name: str, cfg: dict[str, Any], http: Any):
        super().__init__(name, cfg, http)
        self._seen_uids: set[bytes] = set()
        self._extra: list[Any] = []

    @classmethod
    def default_name(cls, cfg: dict[str, Any]) -> str:
        return f"email_alerts:{cfg.get('username', 'mailbox')}"

    @classmethod
    def validate(cls, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        if not cfg.get("password"):
            problems.append("missing 'password' (set IMAP_PASSWORD in .env and reference it as ${IMAP_PASSWORD})")
        return problems

    # -- IMAP plumbing -------------------------------------------------------------------
    def _connect(self) -> imaplib.IMAP4:
        host, security = self.cfg["host"], str(self.cfg.get("security", "ssl")).lower()
        port = int(self.cfg.get("port", 993 if security == "ssl" else 143))
        try:
            if security == "ssl":
                conn: imaplib.IMAP4 = imaplib.IMAP4_SSL(host, port, timeout=30)
            else:
                conn = imaplib.IMAP4(host, port, timeout=30)
                if security == "starttls":
                    conn.starttls()
            conn.login(self.cfg["username"], self.cfg["password"])
        except (imaplib.IMAP4.error, OSError) as e:
            raise SourceError(f"IMAP connection/login failed: {type(e).__name__}: {e}") from e
        return conn

    @staticmethod
    def _sender_criteria(domains: list[str]) -> list[str]:
        crit: list[str] = []
        for i, d in enumerate(domains):
            if i < len(domains) - 1:
                crit += ["OR", "FROM", f'"{d}"']
            else:
                crit += ["FROM", f'"{d}"']
        return crit

    def fetch_messages(self) -> list[Message]:
        """Return new alert messages (not yet processed in this process lifetime)."""
        domains = self.cfg.get("sender_domains") or DEFAULT_SENDER_DOMAINS
        since = (utcnow() - timedelta(days=int(self.cfg.get("lookback_days", 3)))).strftime("%d-%b-%Y")
        conn = self._connect()
        messages: list[Message] = []
        try:
            typ, _ = conn.select(self.cfg.get("folder", "INBOX"), readonly=True)
            if typ != "OK":
                raise SourceError(f"Cannot open IMAP folder {self.cfg.get('folder', 'INBOX')!r}")
            typ, data = conn.uid("SEARCH", None, "SINCE", since, *self._sender_criteria(list(domains)))
            if typ != "OK":
                raise SourceError("IMAP SEARCH failed")
            uids = data[0].split() if data and data[0] else []
            for uid in uids[-int(self.cfg.get("max_messages", 150)) :]:
                if uid in self._seen_uids:
                    continue
                typ, parts = conn.uid("FETCH", uid, "(BODY.PEEK[])")
                if typ != "OK" or not parts or not isinstance(parts[0], tuple):
                    log.warning("[%s] could not fetch message uid %s", self.name, uid)
                    continue
                messages.append(email.message_from_bytes(parts[0][1]))
                self._seen_uids.add(uid)
        except imaplib.IMAP4.error as e:
            raise SourceError(f"IMAP error: {e}") from e
        finally:
            try:
                conn.logout()
            except Exception:  # connection already gone
                pass
        return messages

    def fetch(self) -> list[Job]:
        jobs: dict[str, Job] = {}
        for msg in self.fetch_messages():
            sender = parseaddr(msg.get("From", ""))[1]
            for rec in parse_alert_message(msg, self._extra):
                job = self.make_job(
                    external_id=f"{rec['platform']}:{rec['job_id']}",
                    title=rec["title"],
                    company=rec["company"] or "(see posting)",
                    location=rec["location"],
                    description=rec["description"],
                    url=rec["url"],
                    posted_at=rec["posted_at"],
                    extra={"via": rec["platform"], "alert_sender": sender, "subject": decode_mime(msg.get("Subject"))[:120]},
                )
                jobs[job.external_id] = job
        return list(jobs.values())
