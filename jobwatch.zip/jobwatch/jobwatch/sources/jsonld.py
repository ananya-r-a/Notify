"""Generic career-page adapter based on schema.org ``JobPosting`` JSON-LD.

Google for Jobs requires employers to embed ``JobPosting`` structured data, so a large
share of company career pages (including many startups and Indian IT/product companies)
expose clean machine-readable data without any site-specific scraping.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Iterator
from urllib.parse import urldefrag, urljoin

from bs4 import BeautifulSoup

from ..extract import join_unique
from ..models import Job, NotModified, SourceError
from ..textutil import clean_line, html_to_text
from ..util import parse_dt, sha1
from .base import Source

log = logging.getLogger(__name__)


def _iter_objects(node: Any) -> Iterator[dict[str, Any]]:
    if isinstance(node, list):
        for n in node:
            yield from _iter_objects(n)
    elif isinstance(node, dict):
        types = node.get("@type")
        types = types if isinstance(types, list) else [types]
        if "JobPosting" in types:
            yield node
        for key in ("@graph", "itemListElement", "mainEntity", "item"):
            if key in node:
                yield from _iter_objects(node[key])


def extract_jobpostings(html: str) -> list[dict[str, Any]]:
    """Return every schema.org ``JobPosting`` object embedded in ``html``."""
    soup = BeautifulSoup(html, "lxml")
    found: list[dict[str, Any]] = []
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text()
        try:
            found.extend(_iter_objects(json.loads(raw)))
        except (json.JSONDecodeError, TypeError):
            log.debug("Skipping unparsable JSON-LD block")
    return found


def _address_text(addr: Any) -> str:
    if isinstance(addr, str):
        return addr
    if not isinstance(addr, dict):
        return ""
    country = addr.get("addressCountry")
    if isinstance(country, dict):
        country = country.get("name", "")
    if str(country).upper() == "IN":
        country = "India"
    return join_unique([addr.get("addressLocality", ""), addr.get("addressRegion", ""), str(country or "")], sep=", ")


def _location_text(obj: dict[str, Any]) -> str:
    places = obj.get("jobLocation") or []
    places = places if isinstance(places, list) else [places]
    texts = [_address_text(p.get("address")) if isinstance(p, dict) else str(p) for p in places]
    if str(obj.get("jobLocationType", "")).upper() == "TELECOMMUTE":
        req = obj.get("applicantLocationRequirements")
        reqs = req if isinstance(req, list) else [req] if req else []
        names = [r.get("name", "") for r in reqs if isinstance(r, dict)]
        texts.append("Remote " + "/".join(n for n in names if n) if names else "Remote")
    return join_unique(texts)


def _salary_text(obj: dict[str, Any]) -> str:
    base = obj.get("baseSalary")
    if not isinstance(base, dict):
        return ""
    value = base.get("value") if isinstance(base.get("value"), dict) else {}
    lo, hi = value.get("minValue"), value.get("maxValue")
    if not (lo and hi):
        return ""
    cur = base.get("currency", "")
    fmt = (lambda n: f"{n:,}") if isinstance(lo, (int, float)) and isinstance(hi, (int, float)) else str
    unit = str(value.get("unitText", "year")).lower()
    return f"{cur} {fmt(lo)} - {fmt(hi)} per {unit}".strip()


def jobposting_to_job(source: Source, obj: dict[str, Any], page_url: str) -> Job:
    """Convert one ``JobPosting`` dict to a :class:`Job` (raises ``KeyError`` if no title)."""
    org = obj.get("hiringOrganization")
    company = (org.get("name") if isinstance(org, dict) else org) or source.company
    ident = obj.get("identifier")
    ident_val = ident.get("value") if isinstance(ident, dict) else ident
    url = obj.get("url") or page_url
    title = clean_line(html_to_text(str(obj["title"])))
    ext = str(ident_val or url or sha1(title, str(company)))
    emp = obj.get("employmentType")
    emp = emp[0] if isinstance(emp, list) and emp else (emp or "")
    exp_req = obj.get("experienceRequirements")
    exp_text = ""
    if isinstance(exp_req, dict) and exp_req.get("monthsOfExperience"):
        exp_text = f"{float(exp_req['monthsOfExperience']) / 12:g} years of experience"
    elif isinstance(exp_req, str):
        exp_text = exp_req
    return source.make_job(
        external_id=ext,
        title=title,
        company=str(company or ""),
        location=_location_text(obj),
        description=html_to_text(obj.get("description")),
        url=url,
        apply_url=url,
        posted_at=parse_dt(obj.get("datePosted")),
        deadline=parse_dt(obj.get("validThrough")),
        employment_type=str(emp),
        work_mode="remote" if str(obj.get("jobLocationType", "")).upper() == "TELECOMMUTE" else "",
        salary_text=_salary_text(obj),
        department=str(obj.get("occupationalCategory", "") or ""),
        experience_text=exp_text,
    )


class JsonLdSource(Source):
    """Fetch one or more pages and read their ``JobPosting`` JSON-LD.

    Config: ``url`` or ``urls``; optional ``company``, ``assume_location``.
    For listing pages whose job links lead to detail pages carrying the JSON-LD, set
    ``follow_links: true`` plus ``link_selector`` (CSS, e.g. ``a[href*='/jobs/']``) and
    optionally ``max_follow`` (default 40 new detail pages per run).
    robots.txt is honoured unless ``http.respect_robots`` is false.
    """

    platform = "jsonld"
    default_interval = 900

    @classmethod
    def validate(cls, cfg: dict[str, Any]) -> list[str]:
        problems = []
        if not (cfg.get("url") or cfg.get("urls")):
            problems.append("missing required key 'url' (or 'urls')")
        if cfg.get("follow_links") and not cfg.get("link_selector"):
            problems.append("follow_links requires link_selector")
        return problems

    @classmethod
    def default_name(cls, cfg: dict[str, Any]) -> str:
        from urllib.parse import urlsplit

        url = cfg.get("url") or (cfg.get("urls") or [""])[0]
        return f"jsonld:{urlsplit(url).netloc or 'page'}"

    def fetch(self) -> list[Job]:
        urls = self.cfg.get("urls") or [self.cfg["url"]]
        follow = bool(self.cfg.get("follow_links"))
        conditional = len(urls) == 1 and not follow  # a 304 on one of many pages would hide the rest
        jobs: dict[str, Job] = {}
        for url in urls:
            resp = self.http.get(url, conditional=conditional, check_robots=True)
            for obj in extract_jobpostings(resp.text):
                try:
                    job = jobposting_to_job(self, obj, url)
                except KeyError:
                    log.warning("[%s] JobPosting without title on %s skipped", self.name, url)
                    continue
                jobs[job.external_id] = job
            if follow:
                self._follow(resp.text, url, jobs)
        if not jobs and self.cfg.get("require_jobs", False):
            raise SourceError("No JobPosting JSON-LD found on the configured page(s)")
        return list(jobs.values())

    def _follow(self, html: str, page_url: str, jobs: dict[str, Job]) -> None:
        soup = BeautifulSoup(html, "lxml")
        links: list[str] = []
        for a in soup.select(self.cfg["link_selector"]):
            href = a.get("href")
            if href:
                link = urldefrag(urljoin(page_url, href))[0]
                if link not in links and link != page_url:
                    links.append(link)
        budget = int(self.cfg.get("max_follow", 40))
        for link in links:
            if link in self.known_ids:  # already stored: only mark as seen
                jobs[link] = self.make_job(external_id=link, title="", extra={"unchanged": True})
                continue
            if budget <= 0:
                break
            budget -= 1
            try:
                resp = self.http.get(link, check_robots=True)
            except SourceError as e:
                log.warning("[%s] could not fetch %s: %s", self.name, link, e)
                continue
            for obj in extract_jobpostings(resp.text):
                try:
                    job = jobposting_to_job(self, obj, link)
                except KeyError:
                    continue
                job.external_id = link  # URL is the stable id when following links
                jobs[link] = job
