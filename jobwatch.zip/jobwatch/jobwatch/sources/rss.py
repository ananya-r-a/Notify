"""RSS / Atom feed adapter (job boards, startup newsletters, government notification feeds)."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlsplit

from lxml import etree

from ..models import Job, SourceError
from ..textutil import clean_line, html_to_text
from ..util import parse_dt, sha1
from .base import Source


def _local(tag: Any) -> str:
    return etree.QName(tag).localname if isinstance(tag, str) else ""


def _child_text(el: Any, *names: str) -> str:
    for child in el:
        if _local(child.tag) in names and (child.text or "").strip():
            return child.text.strip()
    return ""


class RssSource(Source):
    """Config: ``url`` (required); optional ``company``, ``assume_location``,
    ``title_regex`` with named groups ``title`` / ``company`` / ``location`` to split titles
    such as ``"Backend Engineer at Acme (Bengaluru)"``, and ``complete: true`` when the feed
    always lists every open job (enables expiry detection; default false because most feeds
    only show the latest N items).
    """

    platform = "rss"
    required = ("url",)
    default_interval = 600
    complete_listing = False

    def __init__(self, name: str, cfg: dict[str, Any], http: Any):
        super().__init__(name, cfg, http)
        self.complete_listing = bool(cfg.get("complete", False))
        self._title_rx = re.compile(cfg["title_regex"]) if cfg.get("title_regex") else None

    @classmethod
    def default_name(cls, cfg: dict[str, Any]) -> str:
        return f"rss:{urlsplit(cfg.get('url', '')).netloc or 'feed'}"

    def fetch(self) -> list[Job]:
        resp = self.http.get(self.cfg["url"], conditional=True, check_robots=False)
        parser = etree.XMLParser(resolve_entities=False, no_network=True, recover=True, huge_tree=False)
        try:
            root = etree.fromstring(resp.content, parser=parser)
        except etree.XMLSyntaxError as e:
            raise SourceError(f"Feed is not valid XML: {e}") from e
        if root is None:
            raise SourceError("Feed is empty or not XML")
        kind = _local(root.tag)
        if kind == "rss":
            channel = next((c for c in root if _local(c.tag) == "channel"), root)
            feed_title = _child_text(channel, "title")
            entries = [e for e in channel if _local(e.tag) == "item"]
        elif kind == "feed":
            feed_title = _child_text(root, "title")
            entries = [e for e in root if _local(e.tag) == "entry"]
        elif kind == "RDF":  # RSS 1.0
            feed_title = ""
            entries = [e for e in root if _local(e.tag) == "item"]
        else:
            raise SourceError(f"Unrecognised feed root element <{kind}>")

        jobs: list[Job] = []
        for e in entries:
            title = clean_line(html_to_text(_child_text(e, "title")))
            if not title:
                continue
            link = _child_text(e, "link")
            if not link:  # Atom: <link href="…"/>
                for c in e:
                    if _local(c.tag) == "link" and c.get("href"):
                        link = c.get("href")
                        break
            guid = _child_text(e, "guid", "id") or link or sha1(title)
            company, location = self.company or feed_title, _child_text(e, "location", "region")
            if self._title_rx:
                m = self._title_rx.search(title)
                if m:
                    gd = m.groupdict()
                    title = clean_line(gd.get("title") or title)
                    company = clean_line(gd.get("company") or company)
                    location = clean_line(gd.get("location") or location)
            summary = _child_text(e, "encoded", "description", "summary", "content")
            jobs.append(
                self.make_job(
                    external_id=guid,
                    title=title,
                    company=company,
                    location=location,
                    description=html_to_text(summary),
                    url=link,
                    posted_at=parse_dt(_child_text(e, "pubDate", "published", "updated", "date")),
                )
            )
        return jobs
