"""Workday career sites (``*.myworkdayjobs.com``) via the JSON endpoint their own front-end uses.

Many large employers (IT, semiconductor, automotive, aerospace) run on Workday. There is no
*published* public API; the career-site front-end calls ``/wday/cxs/{tenant}/{site}/jobs``,
which is widely documented by the community. It can change without notice, so this adapter
fails loudly (never silently) when the payload shape is unexpected.
"""

from __future__ import annotations

import logging
import re
from datetime import timedelta

from ..extract import join_unique
from ..models import Job, SourceError
from ..textutil import clean_line, html_to_text
from ..util import parse_dt, utcnow
from .base import Source

log = logging.getLogger(__name__)


def parse_posted_on(text: str):
    """'Posted Today' / 'Posted 3 Days Ago' / 'Posted 30+ Days Ago' → approximate datetime."""
    t = (text or "").lower()
    if "today" in t:
        return utcnow()
    if "yesterday" in t:
        return utcnow() - timedelta(days=1)
    m = re.search(r"(\d+)\+?\s*day", t)
    return utcnow() - timedelta(days=int(m.group(1))) if m else None


class WorkdaySource(Source):
    """Config: ``host`` (e.g. ``nxp.wd3.myworkdayjobs.com``), ``tenant``, ``site``;
    optional ``search_text`` (default "Bengaluru" — server-side narrowing), ``page_size`` (≤20),
    ``max_pages``, ``fetch_details`` (description for new postings only), ``max_details``.
    """

    platform = "workday"
    required = ("host", "tenant", "site")
    default_interval = 600

    @classmethod
    def default_name(cls, cfg):
        return f"workday:{cfg.get('tenant', '')}/{cfg.get('site', '')}"

    def fetch(self) -> list[Job]:
        host, tenant, site = self.cfg["host"], self.cfg["tenant"], self.cfg["site"]
        scheme = self.cfg.get("scheme", "https")
        root = f"{scheme}://{host}/wday/cxs/{tenant}/{site}"
        page_size = min(int(self.cfg.get("page_size", 20)), 20)
        search = self.cfg.get("search_text", "Bengaluru")
        postings: list[dict] = []
        total = None
        offset = 0
        for _ in range(int(self.cfg.get("max_pages", 25))):
            body = {"appliedFacets": {}, "limit": page_size, "offset": offset, "searchText": search}
            payload = self.http.post(f"{root}/jobs", json=body, headers={"Content-Type": "application/json"}).json()
            if "jobPostings" not in payload:
                raise SourceError("Workday response had no 'jobPostings' key (endpoint format may have changed)")
            batch = payload["jobPostings"] or []
            if total is None and payload.get("total"):
                total = int(payload["total"])  # only reported on the first page by some tenants
            postings.extend(batch)
            offset += len(batch)
            if not batch or (total is not None and offset >= total):
                break

        company = self.company or tenant.upper()
        want_details = bool(self.cfg.get("fetch_details", True))
        budget = int(self.cfg.get("max_details", 30))
        jobs: list[Job] = []
        for p in postings:
            path = p.get("externalPath", "")
            bullets = p.get("bulletFields") or []
            ext = str(bullets[0]) if bullets else path
            url = f"{scheme}://{host}/en-US/{site}{path}"
            description, location, partial = "", p.get("locationsText", ""), False
            employment, posted, extra_locs = "", parse_posted_on(p.get("postedOn", "")), []
            if want_details and path:
                if ext in self.known_ids:
                    partial = True
                elif budget > 0:
                    budget -= 1
                    try:
                        info = self.http.get_json(f"{root}{path}").get("jobPostingInfo") or {}
                        description = html_to_text(info.get("jobDescription"))
                        extra_locs = info.get("additionalLocations") or []
                        location = join_unique([info.get("location") or location, *extra_locs])
                        employment = info.get("timeType", "")
                        posted = parse_dt(info.get("startDate")) or posted
                        url = info.get("externalUrl") or url
                    except SourceError as e:
                        log.warning("[%s] detail fetch failed for %s: %s", self.name, ext, e)
            jobs.append(
                self.make_job(
                    external_id=ext,
                    title=clean_line(p.get("title")),
                    company=company,
                    location=location,
                    description=description,
                    url=url,
                    apply_url=url,
                    posted_at=posted,
                    employment_type=employment,
                    extra={"partial": partial, "external_path": path},
                )
            )
        return jobs
