"""HTML → plain-text helpers used by adapters."""

from __future__ import annotations

import html
import re

from bs4 import BeautifulSoup

_BLOCK_TAGS = ("p", "div", "br", "li", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "section")


def html_to_text(raw: str | None) -> str:
    """Convert (possibly entity-escaped) HTML into readable plain text.

    Greenhouse returns descriptions HTML-escaped (``&lt;p&gt;``), so entities are
    decoded first when no real tags are present. List items become ``- `` bullets
    and block elements become line breaks, which keeps "Requirements" / "Preferred"
    headings on their own lines for the skills splitter.
    """
    if not raw:
        return ""
    text = raw
    for _ in range(2):
        if "<" not in text and ("&lt;" in text or "&amp;lt;" in text):
            text = html.unescape(text)
        else:
            break
    soup = BeautifulSoup(text, "lxml")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    for li in soup.find_all("li"):
        li.insert_before("\n- ")
    for tag in soup.find_all(_BLOCK_TAGS):
        tag.append("\n")
    out = soup.get_text()
    out = out.replace("\xa0", " ")
    out = re.sub(r"[ \t]+", " ", out)
    out = re.sub(r" *\n *", "\n", out)
    out = re.sub(r"\n{3,}", "\n\n", out)
    return out.strip()


def clean_line(text: str | None) -> str:
    """Collapse all whitespace in a short string (titles, locations)."""
    return re.sub(r"\s+", " ", (text or "").replace("\xa0", " ")).strip()
