"""Normalised job data model shared by all source adapters."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from .util import norm, primary_city, sha1, to_iso


@dataclass
class Job:
    """A single job posting in the normalised form every adapter must produce.

    Adapters fill the "raw" fields; :func:`jobwatch.extract.enrich` then derives
    skills, experience, salary and work mode from the text.
    """

    source: str  # adapter instance name, e.g. "greenhouse:razorpay"
    platform: str  # platform family, e.g. "greenhouse"
    external_id: str  # id that is stable for this posting within ``source``
    title: str
    company: str
    location: str = ""
    description: str = ""  # plain text
    url: str = ""  # original posting URL
    apply_url: str = ""
    posted_at: datetime | None = None
    deadline: datetime | None = None
    employment_type: str = ""
    work_mode: str = ""  # "remote" | "hybrid" | "onsite" | ""
    salary_text: str = ""
    department: str = ""
    company_page: str = ""
    experience_text: str = ""  # raw experience hint supplied by the source
    extra: dict[str, Any] = field(default_factory=dict)

    # --- derived by enrich() ---------------------------------------------------
    skills_required: list[str] = field(default_factory=list)
    skills_preferred: list[str] = field(default_factory=list)
    exp_min: float | None = None
    exp_max: float | None = None
    exp_inferred: bool = False
    salary_min_lpa: float | None = None
    salary_max_lpa: float | None = None

    @property
    def uid(self) -> str:
        """Globally unique key: ``<source>|<external_id>``."""
        return f"{self.source}|{self.external_id}"

    def content_hash(self) -> str:
        """Hash of the fields whose change counts as an 'updated description'."""
        return sha1(
            self.title,
            self.company,
            self.location,
            self.description,
            self.employment_type,
            self.salary_text,
            to_iso(self.deadline) or "",
        )

    def apply_hash(self) -> str:
        """Hash of the URLs whose change counts as an 'updated application link'."""
        return sha1(self.url, self.apply_url)

    def fingerprint(self) -> str:
        """Cross-source duplicate key: company + title + primary city."""
        return sha1(norm(self.company), norm(self.title), primary_city(self.location))


class SourceError(Exception):
    """Base class for adapter failures."""


class NotModified(Exception):
    """Raised by an adapter when the remote reported 'nothing changed' (HTTP 304)."""


class SourceNotFound(SourceError):
    """The board / feed does not exist (HTTP 404). Likely a wrong token or slug."""


class SourceBlocked(SourceError):
    """The site refused access (HTTP 401/403/anti-bot). Retrying quickly will not help."""
