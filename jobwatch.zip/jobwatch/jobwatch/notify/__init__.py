"""Notification service: routes alerts to the configured channels and records every outcome."""

from __future__ import annotations

import logging
from typing import Any, Callable

from ..db import Database
from .base import Notifier, NotifyError
from .desktop import DesktopNotifier
from .mailer import EmailNotifier
from .ntfy import NtfyNotifier
from .telegram import TelegramNotifier
from .whatsapp import WhatsAppNotifier

log = logging.getLogger(__name__)

NOTIFIER_CLASSES: dict[str, type[Notifier]] = {
    "telegram": TelegramNotifier,
    "email": EmailNotifier,
    "whatsapp": WhatsAppNotifier,
    "desktop": DesktopNotifier,
    "ntfy": NtfyNotifier,
}

__all__ = ["NotificationService", "Notifier", "NotifyError", "build_notifiers"]


def build_notifiers(cfg: dict[str, Any], sleep: Callable[[float], None] | None = None) -> dict[str, Notifier]:
    """Create every *enabled* channel. Channels that are enabled but incompletely configured are
    still created (so the problem is reported by ``jobwatch check``) but flagged by ``missing()``."""
    out: dict[str, Notifier] = {}
    for name, cls in NOTIFIER_CLASSES.items():
        sub = cfg.get(name) or {}
        if not sub.get("enabled", False):
            continue
        kwargs = {"sleep": sleep} if sleep else {}
        out[name] = cls(sub, **kwargs)
    return out


class NotificationService:
    """Fan-out with per-channel bookkeeping.

    A job is only marked notified once **at least one** channel delivered it, and channels that
    already succeeded are never re-sent on retry (so a flaky second channel cannot cause
    duplicate Telegram messages).
    """

    def __init__(self, db: Database, notifiers: dict[str, Notifier], routing: dict[str, list[str]], whatsapp_only_priority: bool = True):
        self.db = db
        self.notifiers = notifiers
        self.routing = routing
        self.whatsapp_only_priority = whatsapp_only_priority

    # -- helpers -----------------------------------------------------------------------
    def channels_for(self, kind: str, priority: bool = False) -> list[Notifier]:
        names = self.routing.get(kind, [])
        out = []
        for n in names:
            notifier = self.notifiers.get(n)
            if notifier is None:
                continue
            if n == "whatsapp" and kind == "job" and self.whatsapp_only_priority and not priority:
                continue
            out.append(notifier)
        return out

    def has_usable_channel(self) -> bool:
        """True when at least one routed channel is enabled *and* fully configured."""
        return any(n.is_configured() for kind in ("job", "priority") for n in self.channels_for(kind, priority=True))

    # -- jobs --------------------------------------------------------------------------
    def notify_job(self, job: dict[str, Any]) -> bool:
        """Send one job alert. Returns True when at least one channel has it (now or earlier)."""
        priority = bool(job.get("priority"))
        done = self.db.channels_done(job["uid"])
        delivered = bool(done)
        channels = self.channels_for("priority" if priority else "job", priority=priority)
        for notifier in channels:
            if notifier.name in done:
                continue
            if not notifier.is_configured():
                log.warning("Skipping %s: not configured (missing %s)", notifier.name, ", ".join(notifier.missing()))
                continue
            try:
                notifier.send_job(job, priority=priority)
            except NotifyError as e:
                log.error("[%s] failed to send '%s': %s", notifier.name, job["title"], e)
                self.db.record_notification(job["uid"], notifier.name, False, str(e))
            except Exception as e:  # a buggy channel must never stop the others
                log.exception("[%s] unexpected error sending '%s'", notifier.name, job["title"])
                self.db.record_notification(job["uid"], notifier.name, False, f"{type(e).__name__}: {e}")
            else:
                self.db.record_notification(job["uid"], notifier.name, True)
                delivered = True
        if delivered:
            self.db.mark_notified([job["uid"]])
        else:
            self.db.bump_attempts(job["uid"])
        return delivered

    # -- digests / system --------------------------------------------------------------
    def send_digest(self, jobs: list[dict[str, Any]], title: str) -> list[str]:
        """Send a summary on the 'digest' route; returns the channels that succeeded."""
        return self._broadcast("digest", lambda n: n.send_digest(jobs, title))

    def send_system(self, title: str, body: str) -> list[str]:
        """Send an operational message (failures, first-run notice) on the 'system' route."""
        return self._broadcast("system", lambda n: n.send_text(title, body))

    def _broadcast(self, kind: str, action: Callable[[Notifier], None]) -> list[str]:
        ok: list[str] = []
        for notifier in self.channels_for(kind, priority=True):
            if not notifier.is_configured():
                continue
            try:
                action(notifier)
                ok.append(notifier.name)
            except NotifyError as e:
                log.error("[%s] %s message failed: %s", notifier.name, kind, e)
            except Exception:
                log.exception("[%s] unexpected error in %s message", notifier.name, kind)
        return ok

    # -- manual test -------------------------------------------------------------------
    def test(self, only: str | None = None) -> dict[str, str]:
        """Send a test message on every enabled channel. Returns ``{channel: 'ok' | error}``."""
        results: dict[str, str] = {}
        sample_job = {
            "uid": "test|1", "title": "Test: Senior Python Developer", "company": "JobWatch", "location": "Bengaluru, India",
            "work_mode": "hybrid", "exp_min": 3, "exp_max": 5, "score": 88, "source": "test", "posted_at": None,
            "discovered_at": "", "apply_url": "https://example.com/apply", "url": "https://example.com/job",
            "salary_text": "", "skills_required": ["python"], "score_breakdown": {"title": 1.0, "skills": 1.0}, "priority": 1,
        }
        for name, notifier in self.notifiers.items():
            if only and name != only:
                continue
            if not notifier.is_configured():
                results[name] = "NOT CONFIGURED: missing " + ", ".join(notifier.missing())
                continue
            try:
                notifier.send_text("JobWatch test", "If you can read this, notifications work.", "https://example.com")
                if name != "whatsapp" or notifier.cfg.get("provider") == "twilio" or notifier.cfg.get("cloud", {}).get("mode") == "text":
                    notifier.send_job(sample_job, priority=True)
                results[name] = "ok"
            except NotifyError as e:
                results[name] = f"FAILED: {e}"
            except Exception as e:
                results[name] = f"FAILED: {type(e).__name__}: {e}"
        return results
