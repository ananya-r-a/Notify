"""Telegram notifications via the official Bot API (https://core.telegram.org/bots/api)."""

from __future__ import annotations

import html
from typing import Any

from ..util import truncate
from .base import Notifier, NotifyError
from .format import digest_text, telegram_html


class TelegramNotifier(Notifier):
    """Sends messages with ``sendMessage``; job alerts carry inline 'Open' / 'Apply' buttons.

    ``chat_id`` may hold several ids separated by commas (e.g. you and a group).
    """

    name = "telegram"
    required = ("bot_token", "chat_id")

    def _call(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        base = self.cfg.get("api_base", "https://api.telegram.org").rstrip("/")
        resp = self.post(f"{base}/bot{self.cfg['bot_token']}/{method}", json=payload)
        try:
            data = resp.json()
        except ValueError as e:
            raise NotifyError(f"Telegram returned non-JSON (HTTP {resp.status_code})") from e
        if not data.get("ok"):
            params = data.get("parameters") or {}
            if "retry_after" in params and int(params["retry_after"]) <= 30:
                self._sleep(int(params["retry_after"]))
                raise NotifyError(f"Telegram rate limit: {data.get('description')}", transient=True)
            raise NotifyError(f"Telegram error {data.get('error_code', resp.status_code)}: {data.get('description')}")
        return data

    def _chat_ids(self) -> list[str]:
        return [c.strip() for c in str(self.cfg["chat_id"]).split(",") if c.strip()]

    def _send(self, text: str, buttons: list[list[dict[str, str]]] | None = None) -> None:
        for chat in self._chat_ids():
            payload: dict[str, Any] = {
                "chat_id": chat,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            }
            if buttons:
                payload["reply_markup"] = {"inline_keyboard": buttons}
            self.retry(lambda p=payload: self._call("sendMessage", p))

    def send_job(self, job: dict[str, Any], priority: bool = False) -> None:
        url, apply_url = job.get("url") or "", job.get("apply_url") or job.get("url") or ""
        row: list[dict[str, str]] = []
        if url.startswith("http"):
            row.append({"text": "🔗 Open posting", "url": url})
        if apply_url.startswith("http") and apply_url != url:
            row.append({"text": "📝 Apply", "url": apply_url})
        self._send(telegram_html(job, priority), [row] if row else None)

    def send_text(self, title: str, body: str, url: str = "") -> None:
        text = f"<b>{html.escape(title)}</b>\n{html.escape(truncate(body, 3500))}"
        self._send(text, [[{"text": "Open", "url": url}]] if url.startswith("http") else None)

    def send_digest(self, jobs: list[dict[str, Any]], title: str) -> None:
        self.send_text(title, digest_text(jobs, limit=15))

    # -- setup helpers ---------------------------------------------------------------
    def get_me(self) -> dict[str, Any]:
        """Verify the bot token (``getMe``)."""
        return self.retry(lambda: self._call("getMe", {}))["result"]

    def discover_chat_ids(self) -> list[tuple[str, str]]:
        """Chats that recently messaged the bot, as ``(chat_id, description)`` pairs."""
        data = self.retry(lambda: self._call("getUpdates", {"timeout": 0}))
        seen: dict[str, str] = {}
        for upd in data.get("result", []):
            msg = upd.get("message") or upd.get("channel_post") or upd.get("my_chat_member") or {}
            chat = msg.get("chat") or {}
            if "id" in chat:
                name = chat.get("title") or " ".join(x for x in (chat.get("first_name"), chat.get("last_name")) if x) or chat.get("username", "")
                seen[str(chat["id"])] = f"{chat.get('type', 'chat')}: {name}"
        return list(seen.items())
