"""Message formatting shared by all notification channels."""

from __future__ import annotations

import html
from typing import Any

from ..util import truncate


def experience_text(job: dict[str, Any]) -> str:
    lo, hi = job.get("exp_min"), job.get("exp_max")
    if lo is None:
        return "not stated"
    suffix = " (inferred)" if job.get("exp_inferred") else ""
    if hi is None:
        return f"{lo:g}+ yrs{suffix}"
    return f"{lo:g} yrs{suffix}" if lo == hi else f"{lo:g}-{hi:g} yrs{suffix}"


def posted_text(job: dict[str, Any]) -> str:
    return (job.get("posted_at") or "")[:10] or "unknown (discovered " + (job.get("discovered_at") or "")[:10] + ")"


def why_text(job: dict[str, Any]) -> str:
    bd = job.get("score_breakdown") or {}
    reasons = []
    if bd.get("title", 0) >= 1.0:
        reasons.append("priority role")
    if bd.get("skills", 0) >= 0.66:
        reasons.append("strong skills match")
    if bd.get("company", 0) >= 1.0:
        reasons.append("priority company")
    if bd.get("location", 0) >= 1.0:
        reasons.append("preferred city")
    return ", ".join(reasons)


def plain_job(job: dict[str, Any], priority: bool = False) -> str:
    """Multi-line plain-text job alert."""
    head = "🔥 PRIORITY JOB MATCH" if priority else "🔔 New job match"
    lines = [
        f"{head}: {job['title']}",
        f"Company: {job.get('company') or '—'}",
        f"Location: {job.get('location') or '—'}" + (f" ({job['work_mode']})" if job.get("work_mode") else ""),
        f"Experience: {experience_text(job)}",
        f"Relevance: {job.get('score', 0):.0f}/100",
        f"Source: {job.get('source')}",
        f"Posted: {posted_text(job)}",
    ]
    if job.get("salary_text"):
        lines.append(f"Salary: {job['salary_text']}")
    why = why_text(job)
    if why:
        lines.append(f"Why: {why}")
    lines.append(f"Apply: {job.get('apply_url') or job.get('url') or '—'}")
    return "\n".join(lines)


def telegram_html(job: dict[str, Any], priority: bool = False) -> str:
    """Telegram-safe HTML (only <b>, <i>, <a> are used; everything else escaped)."""
    e = html.escape
    head = "🔥 <b>PRIORITY</b> · " if priority else "🔔 "
    parts = [
        f"{head}<b>{e(job['title'])}</b>",
        f"🏢 {e(job.get('company') or '—')}",
        f"📍 {e(job.get('location') or '—')}" + (f" · {e(job['work_mode'])}" if job.get("work_mode") else ""),
        f"🧑‍💻 {e(experience_text(job))}   ⭐ <b>{job.get('score', 0):.0f}/100</b>",
        f"🗂 {e(str(job.get('source')))} · 📅 {e(posted_text(job))}",
    ]
    if job.get("salary_text"):
        parts.append(f"💰 {e(job['salary_text'])}")
    why = why_text(job)
    if why:
        parts.append(f"✅ <i>{e(why)}</i>")
    return truncate("\n".join(parts), 3900)


def digest_text(jobs: list[dict[str, Any]], limit: int = 25) -> str:
    """Compact numbered list of jobs for text-only channels."""
    lines = []
    for i, j in enumerate(jobs[:limit], 1):
        lines.append(f"{i}. {j['title']} — {j.get('company') or '?'} ({j.get('location') or '?'}) "
                     f"[{j.get('score', 0):.0f}]\n   {j.get('apply_url') or j.get('url') or ''}")
    if len(jobs) > limit:
        lines.append(f"…and {len(jobs) - limit} more (see dashboard)")
    return "\n".join(lines) if lines else "No matching jobs."
