"""Mobile push notifications through ntfy (https://ntfy.sh), free and self-hostable."""

from __future__ import annotations

from typing import Any

from ..util import truncate
from .base import Notifier, NotifyError
from .format import digest_text, plain_job


class NtfyNotifier(Notifier):
    """Publishes JSON to the ntfy server root; install the ntfy mobile app and subscribe to your topic.

    A public ntfy.sh topic is readable by anyone who guesses its name: use a long random topic
    (or a self-hosted server with an access token) because job alerts contain personal interests.
    """

    name = "ntfy"
    required = ("server", "topic")

    def _publish(self, payload: dict[str, Any]) -> None:
        headers = {}
        if self.cfg.get("token"):
            headers["Authorization"] = f"Bearer {self.cfg['token']}"
        resp = self.post(str(self.cfg["server"]).rstrip("/"), json={"topic": self.cfg["topic"], **payload}, headers=headers)
        if resp.status_code >= 400:
            raise NotifyError(f"ntfy error HTTP {resp.status_code}: {resp.text[:200]}")

    def send_job(self, job: dict[str, Any], priority: bool = False) -> None:
        url = job.get("apply_url") or job.get("url") or ""
        payload: dict[str, Any] = {
            "title": truncate(f"{job['title']} @ {job.get('company') or '?'}", 200),
            "message": truncate(plain_job(job, priority), 3500),
            "priority": 5 if priority else 3,
            "tags": ["fire"] if priority else ["briefcase"],
        }
        if url.startswith("http"):
            payload["click"] = url
            payload["actions"] = [{"action": "view", "label": "Apply", "url": url}]
        self.retry(lambda: self._publish(payload))

    def send_text(self, title: str, body: str, url: str = "") -> None:
        payload: dict[str, Any] = {"title": truncate(title, 200), "message": truncate(body, 3500)}
        if url.startswith("http"):
            payload["click"] = url
        self.retry(lambda: self._publish(payload))

    def send_digest(self, jobs: list[dict[str, Any]], title: str) -> None:
        self.send_text(title, digest_text(jobs, limit=12))
