"""WhatsApp notifications through official channels only.

* ``cloud``  — Meta's WhatsApp Business Platform Cloud API (graph.facebook.com)
* ``twilio`` — Twilio's WhatsApp API (authorised Meta Business Solution Provider)

No unofficial libraries, no browser automation.
"""

from __future__ import annotations

import re
from typing import Any

from ..util import truncate
from .base import Notifier, NotifyError
from .format import experience_text, plain_job


def normalise_number(value: str) -> str:
    """Digits only, no '+' or leading '00' (E.164 without the plus)."""
    digits = re.sub(r"\D", "", value or "")
    return digits[2:] if digits.startswith("00") else digits


def _param(text: str, limit: int = 300) -> str:
    """Template parameters may not contain newlines/tabs or runs of 4+ spaces."""
    text = re.sub(r"[\r\n\t]+", " ", text or "")
    text = re.sub(r" {4,}", "   ", text).strip()
    return truncate(text, limit) or "-"


class WhatsAppNotifier(Notifier):
    """Config: ``provider`` (cloud|twilio), ``to`` and the provider sub-section.

    Cloud API template mode (the only way to *start* a conversation) needs an approved template
    whose body has six variables, see README "WhatsApp API configuration":

        New job match: {{1}} at {{2}} ({{3}}). Experience: {{4}}. Relevance: {{5}}/100. Apply: {{6}}

    ``mode: text`` sends free-form text but WhatsApp only delivers it inside the 24-hour window after
    *you* last messaged the business number.
    """

    name = "whatsapp"

    def _provider(self) -> str:
        return str(self.cfg.get("provider", "cloud")).lower()

    def missing(self) -> list[str]:
        miss = [] if str(self.cfg.get("to", "")).strip() else ["to"]
        provider = self._provider()
        if provider == "cloud":
            sub = self.cfg.get("cloud", {})
            miss += [f"cloud.{k}" for k in ("access_token", "phone_number_id") if not str(sub.get(k, "")).strip()]
            if sub.get("mode", "template") == "template" and not str(sub.get("template_name", "")).strip():
                miss.append("cloud.template_name")
        elif provider == "twilio":
            sub = self.cfg.get("twilio", {})
            miss += [f"twilio.{k}" for k in ("account_sid", "auth_token", "from_number") if not str(sub.get(k, "")).strip()]
        else:
            miss.append(f"provider (unknown '{provider}')")
        return miss

    # -- Meta Cloud API ---------------------------------------------------------------
    def _cloud_send(self, payload: dict[str, Any]) -> None:
        c = self.cfg["cloud"]
        url = f"{c.get('api_base', 'https://graph.facebook.com').rstrip('/')}/{c.get('api_version', 'v21.0')}/{c['phone_number_id']}/messages"
        payload = {"messaging_product": "whatsapp", "to": normalise_number(self.cfg["to"]), **payload}
        resp = self.post(url, json=payload, headers={"Authorization": f"Bearer {c['access_token']}"})
        try:
            data = resp.json()
        except ValueError as e:
            raise NotifyError(f"WhatsApp Cloud API returned non-JSON (HTTP {resp.status_code})") from e
        if resp.status_code >= 400 or "messages" not in data:
            err = data.get("error", {})
            raise NotifyError(f"WhatsApp Cloud API error {err.get('code', resp.status_code)}: {err.get('message', data)}")

    # -- Twilio -----------------------------------------------------------------------
    def _twilio_send(self, body: str) -> None:
        t = self.cfg["twilio"]
        url = f"{t.get('api_base', 'https://api.twilio.com').rstrip('/')}/2010-04-01/Accounts/{t['account_sid']}/Messages.json"
        frm = t["from_number"] if str(t["from_number"]).startswith("whatsapp:") else f"whatsapp:{t['from_number']}"
        data = {"From": frm, "To": f"whatsapp:+{normalise_number(self.cfg['to'])}", "Body": truncate(body, 1500)}
        resp = self.post(url, data=data, auth=(t["account_sid"], t["auth_token"]))
        if resp.status_code >= 400:
            try:
                err = resp.json()
            except ValueError:
                err = {"message": resp.text[:200]}
            raise NotifyError(f"Twilio error {err.get('code', resp.status_code)}: {err.get('message')}")

    # -- Notifier API -----------------------------------------------------------------
    def send_job(self, job: dict[str, Any], priority: bool = False) -> None:
        if self._provider() == "twilio":
            self.retry(lambda: self._twilio_send(plain_job(job, priority)))
            return
        c = self.cfg["cloud"]
        if c.get("mode", "template") == "text":
            self.retry(lambda: self._cloud_send({"type": "text", "text": {"preview_url": False, "body": truncate(plain_job(job, priority), 3800)}}))
            return
        params = [
            _param(job["title"], 120),
            _param(job.get("company") or "?", 80),
            _param(job.get("location") or "?", 80),
            _param(experience_text(job), 40),
            _param(f"{job.get('score', 0):.0f}", 10),
            _param(job.get("apply_url") or job.get("url") or "-", 500),
        ]
        payload = {
            "type": "template",
            "template": {
                "name": c["template_name"],
                "language": {"code": c.get("template_language", "en")},
                "components": [{"type": "body", "parameters": [{"type": "text", "text": p} for p in params]}],
            },
        }
        self.retry(lambda: self._cloud_send(payload))

    def send_text(self, title: str, body: str, url: str = "") -> None:
        text = f"*{title}*\n{body}" + (f"\n{url}" if url else "")
        if self._provider() == "twilio":
            self.retry(lambda: self._twilio_send(text))
        elif self.cfg["cloud"].get("mode", "template") == "text":
            self.retry(lambda: self._cloud_send({"type": "text", "text": {"preview_url": False, "body": truncate(text, 3800)}}))
        else:
            raise NotifyError(
                "WhatsApp template mode can only send job-alert templates; "
                "use mode: text (24h window) or route system messages to another channel"
            )

    def send_digest(self, jobs: list[dict[str, Any]], title: str) -> None:
        from .format import digest_text

        self.send_text(title, digest_text(jobs, limit=10))
