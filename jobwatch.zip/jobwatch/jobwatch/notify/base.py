"""Notifier base class: configuration check, HTTP helper with retries, shared exceptions."""

from __future__ import annotations

import logging
import random
import time
from abc import ABC, abstractmethod
from typing import Any, Callable

import requests

from ..util import redact

log = logging.getLogger(__name__)


class NotifyError(Exception):
    """A delivery failure. ``transient`` failures are retried; permanent ones are not."""

    def __init__(self, message: str, transient: bool = False):
        super().__init__(redact(message))
        self.transient = transient


class Notifier(ABC):
    """One outbound channel (Telegram, e-mail, …)."""

    name: str = "base"
    #: config keys that must be non-empty for the channel to count as configured
    required: tuple[str, ...] = ()

    def __init__(self, cfg: dict[str, Any], sleep: Callable[[float], None] = time.sleep, session: requests.Session | None = None):
        self.cfg = cfg
        self._sleep = sleep
        self.session = session or requests.Session()

    # -- configuration ---------------------------------------------------------------
    def missing(self) -> list[str]:
        """Names of required settings that are empty."""
        return [k for k in self.required if not str(self.cfg.get(k, "")).strip()]

    def is_configured(self) -> bool:
        return not self.missing()

    # -- API -------------------------------------------------------------------------
    @abstractmethod
    def send_job(self, job: dict[str, Any], priority: bool = False) -> None:
        """Deliver one job alert. Raise :class:`NotifyError` on failure."""

    @abstractmethod
    def send_text(self, title: str, body: str, url: str = "") -> None:
        """Deliver a plain message (system alerts, tests)."""

    def send_digest(self, jobs: list[dict[str, Any]], title: str) -> None:
        """Deliver a summary of several jobs. Default: one text message."""
        from .format import digest_text

        self.send_text(title, digest_text(jobs))

    # -- helpers ---------------------------------------------------------------------
    def retry(self, fn: Callable[[], Any], attempts: int = 3) -> Any:
        """Run ``fn``; retry transient :class:`NotifyError` with exponential backoff."""
        for i in range(attempts):
            try:
                return fn()
            except NotifyError as e:
                if not e.transient or i == attempts - 1:
                    raise
                delay = min(30.0, 1.5 * (2**i)) + random.uniform(0, 0.5)
                log.warning("[%s] transient failure (%s); retry %d/%d in %.1fs", self.name, e, i + 1, attempts - 1, delay)
                self._sleep(delay)
        raise AssertionError("unreachable")  # pragma: no cover

    def post(self, url: str, **kw: Any) -> requests.Response:
        """POST with timeout; maps network errors / 429 / 5xx to transient :class:`NotifyError`."""
        kw.setdefault("timeout", 20)
        try:
            resp = self.session.post(url, **kw)
        except (requests.ConnectionError, requests.Timeout) as e:
            raise NotifyError(f"network error: {type(e).__name__}: {e}", transient=True) from e
        except requests.RequestException as e:
            raise NotifyError(f"request failed: {e}") from e
        if resp.status_code == 429 or resp.status_code >= 500:
            retry_after = resp.headers.get("Retry-After")
            if retry_after and retry_after.isdigit() and int(retry_after) <= 30:
                self._sleep(int(retry_after))
            raise NotifyError(f"HTTP {resp.status_code}: {resp.text[:200]}", transient=True)
        return resp
