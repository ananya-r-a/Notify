"""E-mail notifications over SMTP (Gmail app password, Outlook, any SMTP server)."""

from __future__ import annotations

import html
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from typing import Any

from .base import Notifier, NotifyError
from .format import experience_text, plain_job, posted_text, why_text


def _btn(url: str, label: str, color: str = "#2563eb") -> str:
    if not url.startswith("http"):
        return ""
    return (
        f'<a href="{html.escape(url, quote=True)}" style="display:inline-block;padding:10px 16px;margin:4px 6px 4px 0;'
        f'background:{color};color:#ffffff;text-decoration:none;border-radius:6px;font-weight:600">{html.escape(label)}</a>'
    )


def job_html(job: dict[str, Any], priority: bool) -> str:
    """Self-contained HTML card (inline styles only, so mail clients render it)."""
    e = html.escape
    badge = (
        '<span style="background:#dc2626;color:#fff;padding:2px 8px;border-radius:10px;font-size:12px;font-weight:700">PRIORITY</span> '
        if priority
        else ""
    )
    rows = [
        ("Company", job.get("company") or "—"),
        ("Location", (job.get("location") or "—") + (f" · {job['work_mode']}" if job.get("work_mode") else "")),
        ("Experience", experience_text(job)),
        ("Relevance", f"{job.get('score', 0):.0f} / 100"),
        ("Source", str(job.get("source"))),
        ("Posted", posted_text(job)),
    ]
    if job.get("salary_text"):
        rows.append(("Salary", job["salary_text"]))
    if job.get("skills_required"):
        rows.append(("Skills", ", ".join(job["skills_required"][:12])))
    why = why_text(job)
    if why:
        rows.append(("Why it matched", why))
    table = "".join(
        f'<tr><td style="padding:4px 12px 4px 0;color:#6b7280;white-space:nowrap">{e(k)}</td><td style="padding:4px 0">{e(v)}</td></tr>'
        for k, v in rows
    )
    url, apply_url = job.get("url") or "", job.get("apply_url") or job.get("url") or ""
    buttons = _btn(apply_url, "Apply now") + (_btn(url, "View posting", "#374151") if url and url != apply_url else "")
    return (
        '<div style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;max-width:600px;margin:auto;border:1px solid #e5e7eb;'
        'border-radius:10px;padding:20px;color:#111827">'
        f'<div style="font-size:12px;margin-bottom:6px">{badge}New job match</div>'
        f'<h2 style="margin:0 0 12px 0;font-size:20px">{e(job["title"])}</h2>'
        f'<table style="font-size:14px;border-collapse:collapse">{table}</table>'
        f'<div style="margin-top:16px">{buttons}</div></div>'
    )


def digest_html(jobs: list[dict[str, Any]], title: str, limit: int = 60) -> str:
    e = html.escape
    rows = []
    for j in jobs[:limit]:
        link = j.get("apply_url") or j.get("url") or ""
        name = f'<a href="{e(link, quote=True)}">{e(j["title"])}</a>' if link.startswith("http") else e(j["title"])
        rows.append(
            f'<tr><td style="padding:6px 8px;border-bottom:1px solid #e5e7eb">{name}</td>'
            f'<td style="padding:6px 8px;border-bottom:1px solid #e5e7eb">{e(j.get("company") or "")}</td>'
            f'<td style="padding:6px 8px;border-bottom:1px solid #e5e7eb">{e(j.get("location") or "")}</td>'
            f'<td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;text-align:right">{j.get("score", 0):.0f}</td></tr>'
        )
    more = f"<p>…and {len(jobs) - limit} more in the dashboard.</p>" if len(jobs) > limit else ""
    return (
        '<div style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;max-width:760px;margin:auto;color:#111827">'
        f'<h2>{e(title)}</h2><p>{len(jobs)} job(s), best matches first.</p>'
        '<table style="width:100%;border-collapse:collapse;font-size:14px"><tr style="text-align:left;background:#f3f4f6">'
        '<th style="padding:6px 8px">Role</th><th style="padding:6px 8px">Company</th><th style="padding:6px 8px">Location</th>'
        f'<th style="padding:6px 8px;text-align:right">Score</th></tr>{"".join(rows)}</table>{more}</div>'
    )


class EmailNotifier(Notifier):
    """Sends multipart (plain + HTML) mail through SMTP.

    ``security``: ``ssl`` (port 465), ``starttls`` (port 587) or ``none`` (testing only).
    For Gmail use an *app password* (requires 2-Step Verification), never your real password.
    """

    name = "email"
    required = ("host", "username", "password", "sender", "to")

    def _recipients(self) -> list[str]:
        return [x.strip() for x in str(self.cfg["to"]).split(",") if x.strip()]

    def _deliver(self, msg: EmailMessage) -> None:
        host = self.cfg["host"]
        port = int(self.cfg.get("port") or 465)
        security = str(self.cfg.get("security", "ssl")).lower()
        try:
            if security == "ssl":
                server: smtplib.SMTP = smtplib.SMTP_SSL(host, port, timeout=30, context=ssl.create_default_context())
            else:
                server = smtplib.SMTP(host, port, timeout=30)
            with server:
                server.ehlo()
                if security == "starttls":
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()
                if self.cfg.get("username"):
                    server.login(self.cfg["username"], self.cfg["password"])
                server.send_message(msg)
        except smtplib.SMTPAuthenticationError as e:
            raise NotifyError(f"SMTP authentication failed (use an app password): {e.smtp_code}") from e
        except smtplib.SMTPResponseException as e:
            raise NotifyError(f"SMTP error {e.smtp_code}: {e.smtp_error!r}", transient=400 <= e.smtp_code < 500) from e
        except (smtplib.SMTPException, OSError, ssl.SSLError) as e:
            raise NotifyError(f"SMTP connection problem: {type(e).__name__}: {e}", transient=True) from e

    def _build(self, subject: str, text: str, html_body: str) -> EmailMessage:
        msg = EmailMessage()
        prefix = str(self.cfg.get("subject_prefix", "")).strip()
        msg["Subject"] = f"{prefix} {subject}".strip()
        msg["From"] = self.cfg["sender"]
        msg["To"] = ", ".join(self._recipients())
        msg["Date"] = formatdate(localtime=True)
        msg["Message-ID"] = make_msgid(domain="jobwatch.local")
        msg.set_content(text)
        msg.add_alternative(html_body, subtype="html")
        return msg

    def send_job(self, job: dict[str, Any], priority: bool = False) -> None:
        subject = f"{'🔥 PRIORITY: ' if priority else ''}{job['title']} @ {job.get('company') or '?'} ({job.get('score', 0):.0f}/100)"
        self.retry(lambda: self._deliver(self._build(subject, plain_job(job, priority), job_html(job, priority))))

    def send_text(self, title: str, body: str, url: str = "") -> None:
        e = html.escape
        link = f'<p><a href="{e(url, quote=True)}">{e(url)}</a></p>' if url.startswith("http") else ""
        body_html = f'<div style="font-family:Arial,sans-serif"><h3>{e(title)}</h3><pre style="white-space:pre-wrap">{e(body)}</pre>{link}</div>'
        self.retry(lambda: self._deliver(self._build(title, body + (f"\n{url}" if url else ""), body_html)))

    def send_digest(self, jobs: list[dict[str, Any]], title: str) -> None:
        from .format import digest_text

        self.retry(lambda: self._deliver(self._build(title, digest_text(jobs, limit=60), digest_html(jobs, title))))
