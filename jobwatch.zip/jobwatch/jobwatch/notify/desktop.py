"""Desktop pop-up notifications using each OS's built-in mechanism (no extra packages)."""

from __future__ import annotations

import shutil
import subprocess
import sys
from typing import Any

from ..util import truncate
from .base import Notifier, NotifyError
from .format import experience_text


def _backend() -> str | None:
    if sys.platform.startswith("linux") and shutil.which("notify-send"):
        return "notify-send"
    if sys.platform == "darwin" and shutil.which("osascript"):
        return "osascript"
    if sys.platform in ("win32", "cygwin") and (shutil.which("powershell") or shutil.which("pwsh")):
        return "powershell"
    return None


class DesktopNotifier(Notifier):
    """Linux: ``notify-send``; macOS: ``osascript``; Windows: PowerShell balloon tip.

    A desktop pop-up only works while the monitor runs inside your logged-in desktop session
    (not on a headless server). On a server use Telegram / ntfy / e-mail instead.
    """

    name = "desktop"

    def is_configured(self) -> bool:
        return _backend() is not None

    def missing(self) -> list[str]:
        return [] if self.is_configured() else ["a desktop notification tool (notify-send / osascript / powershell)"]

    def _show(self, title: str, body: str, urgent: bool = False) -> None:
        title, body = truncate(title, 100), truncate(body, 400)
        backend = _backend()
        if backend == "notify-send":
            cmd = ["notify-send", "-a", "JobWatch", "-u", "critical" if urgent else "normal", "-t", "20000", title, body]
        elif backend == "osascript":
            esc = lambda s: s.replace("\\", "\\\\").replace('"', '\\"')  # noqa: E731
            cmd = ["osascript", "-e", f'display notification "{esc(body)}" with title "{esc(title)}"']
        elif backend == "powershell":
            q = lambda s: s.replace("'", "''")  # noqa: E731
            script = (
                "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "
                "$n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Information; "
                f"$n.Visible = $true; $n.ShowBalloonTip(10000, '{q(title)}', '{q(body)}', [System.Windows.Forms.ToolTipIcon]::Info); "
                "Start-Sleep -Seconds 6; $n.Dispose()"
            )
            cmd = [shutil.which("powershell") or "pwsh", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script]
        else:
            raise NotifyError("no desktop notification backend available on this system")
        try:
            subprocess.run(cmd, check=True, timeout=20, capture_output=True)
        except subprocess.CalledProcessError as e:
            raise NotifyError(f"{backend} failed: {(e.stderr or b'').decode(errors='replace')[:200]}") from e
        except (subprocess.TimeoutExpired, OSError) as e:
            raise NotifyError(f"{backend} could not run: {e}") from e

    def send_job(self, job: dict[str, Any], priority: bool = False) -> None:
        title = f"{'PRIORITY: ' if priority else ''}{job['title']} @ {job.get('company') or '?'}"
        body = f"{job.get('location') or ''} · {experience_text(job)} · {job.get('score', 0):.0f}/100\n{job.get('apply_url') or job.get('url') or ''}"
        self._show(title, body, urgent=priority)

    def send_text(self, title: str, body: str, url: str = "") -> None:
        self._show(title, body + (f"\n{url}" if url else ""))
