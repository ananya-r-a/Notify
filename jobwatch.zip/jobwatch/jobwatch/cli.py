"""Command-line interface: ``python -m jobwatch <command>``."""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import signal
import sys
import threading
from pathlib import Path

from .config import ConfigError
from .models import SourceError

log = logging.getLogger("jobwatch")
ROOT = Path(__file__).resolve().parent.parent


def _load(args: argparse.Namespace):
    from .app import build_app, setup_logging

    app = build_app(args.config)
    setup_logging(app.cfg, verbose=getattr(args, "verbose", False))
    return app


def cmd_init(args: argparse.Namespace) -> int:
    """Create config.yaml and .env from the bundled examples (never overwrites)."""
    made = []
    for src, dst in (("config.example.yaml", "config.yaml"), (".env.example", ".env")):
        target = Path(dst)
        if target.exists():
            print(f"= {dst} already exists, left unchanged")
            continue
        shutil.copy(ROOT / src, target)
        made.append(dst)
        print(f"+ created {dst}")
    if made:
        print("\nNext: edit config.yaml (your preferences) and .env (secrets), then run: python -m jobwatch check")
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    """Validate configuration, sources and notification channels (no network unless --live)."""
    problems = 0
    try:
        app = _load(args)
    except ConfigError as e:
        print(f"CONFIG ERROR: {e}")
        return 2
    cfg = app.cfg
    print(f"Config OK  ·  data dir: {cfg.data_dir}  ·  timezone: {cfg.timezone}")
    p = cfg.prefs
    print(f"Preferences: locations={p.locations[:3]}…  experience={p.exp_min:g}-{p.exp_max:g} yrs  min_score={p.min_score:g}")
    print(f"\nSources ({len(app.sources)} enabled):")
    for s in app.sources:
        print(f"  ✓ {s.name:<42} every {s.interval}s")
    if not app.sources:
        print("  ✗ none enabled: add sources to config.yaml (see sources.example.yaml)")
        problems += 1
    print("\nNotification channels:")
    if not app.notifier.notifiers:
        print("  ✗ none enabled")
        problems += 1
    for name, n in app.notifier.notifiers.items():
        miss = n.missing()
        if miss:
            print(f"  ✗ {name:<9} enabled but missing: {', '.join(miss)}")
            problems += 1
        else:
            print(f"  ✓ {name:<9} configured")
    if args.live:
        print("\nLive probe of each source (nothing is stored):")
        for s in app.sources:
            try:
                jobs = s.fetch()
                print(f"  ✓ {s.name:<42} {len(jobs)} job(s)")
            except SourceError as e:
                print(f"  ✗ {s.name:<42} {e}")
                problems += 1
    print("\n" + ("All checks passed." if not problems else f"{problems} problem(s) found."))
    return 1 if problems else 0


def cmd_run(args: argparse.Namespace) -> int:
    """Start the monitor (continuous) or do a single pass (--once)."""
    app = _load(args)
    if args.once:
        for o in app.engine.run_once():
            status = "ok" if o.get("ok") else f"FAILED: {o.get('error')}"
            extra = "" if not o.get("ok") else f" seen={o.get('seen', '-')} new={o.get('new', '-')} matched={o.get('new_matched', '-')}"
            print(f"{o['source']:<42} {status}{extra}")
        return 0
    eng = app.engine

    def stop(signum, _frame):  # noqa: ANN001
        # Keep the handler trivial (no logging/locks inside a signal handler); the engine loop logs the stop.
        if eng.stop_event.is_set():  # second Ctrl+C / SIGTERM: do not wait for in-flight work
            os._exit(130)
        eng.stop_event.set()

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    if args.with_dashboard:
        from .dashboard import create_app

        host, port = app.cfg.dashboard["host"], int(app.cfg.dashboard["port"])
        flask_app = create_app(args.config)
        t = threading.Thread(target=lambda: flask_app.run(host=host, port=port, threaded=True, use_reloader=False), daemon=True, name="dashboard")
        t.start()
        log.info("Dashboard on http://%s:%s", host, port)
    eng.run_forever()
    return 0


def cmd_dashboard(args: argparse.Namespace) -> int:
    from .dashboard import create_app

    app = _load(args)
    host, port = app.cfg.dashboard["host"], int(app.cfg.dashboard["port"])
    print(f"Dashboard: http://{host}:{port}")
    create_app(args.config).run(host=host, port=port, threaded=True, use_reloader=False)
    return 0


def cmd_test_notify(args: argparse.Namespace) -> int:
    """Send a real test message on every enabled channel."""
    app = _load(args)
    results = app.notifier.test(args.channel)
    if not results:
        print("No enabled channels matched.")
        return 1
    bad = 0
    for name, res in results.items():
        print(f"{'✓' if res == 'ok' else '✗'} {name:<9} {res}")
        bad += res != "ok"
    return 1 if bad else 0


def cmd_telegram_id(args: argparse.Namespace) -> int:
    """Verify the bot token and list chats that messaged the bot (to find your chat id)."""
    from .notify.telegram import TelegramNotifier
    from .notify.base import NotifyError

    app = _load(args)
    tg = app.notifier.notifiers.get("telegram") or TelegramNotifier(app.cfg.notifications["telegram"])
    if not str(tg.cfg.get("bot_token", "")).strip():
        print("TELEGRAM_BOT_TOKEN is empty. Create a bot with @BotFather first (see README).")
        return 1
    try:
        me = tg.get_me()
        print(f"Bot OK: @{me.get('username')} ({me.get('first_name')})")
        chats = tg.discover_chat_ids()
    except NotifyError as e:
        print(f"Telegram error: {e}")
        return 1
    if not chats:
        print(f"No chats yet. Open https://t.me/{me.get('username')} , press Start / send any message, then run this again.")
        return 1
    for cid, desc in chats:
        print(f"  chat_id = {cid}    ({desc})")
    return 0


def cmd_sources(args: argparse.Namespace) -> int:
    """Show per-source health (last success, failures, job counts)."""
    app = _load(args)
    states = {s["source"]: s for s in app.db.all_source_states()}
    print(f"{'SOURCE':<42} {'LAST OK':<20} {'FAILS':>5} {'JOBS':>5}  STATUS")
    for s in app.sources:
        st = states.get(s.name, {})
        status = "DISABLED: " + st["disabled_reason"] if st.get("disabled_reason") else (st.get("last_error") or "ok" if st else "not run yet")
        print(f"{s.name:<42} {(st.get('last_success') or '-')[:19]:<20} {st.get('consecutive_failures', 0):>5} {st.get('jobs_stored', 0):>5}  {str(status)[:70]}")
    return 0


def cmd_enable(args: argparse.Namespace) -> int:
    """Re-enable a source that was auto-disabled after repeated 404s."""
    app = _load(args)
    app.db.save_source_state(args.source, disabled_reason=None, consecutive_404=0, consecutive_failures=0, failure_alerted=0)
    print(f"Source {args.source} re-enabled (restart the monitor to pick it up).")
    return 0


def cmd_rescore(args: argparse.Namespace) -> int:
    """Re-evaluate all stored jobs against the current preferences."""
    app = _load(args)
    n = app.pipeline.rescore_all()
    print(f"Re-scored. {n} stored job(s) now match your preferences.")
    return 0


def cmd_jobs(args: argparse.Namespace) -> int:
    """List stored matching jobs in the terminal."""
    app = _load(args)
    rows, total = app.db.query_jobs(q=args.query or "", min_score=args.min_score, limit=args.limit, sort="discovered" if args.newest else "score")
    for j in rows:
        print(f"[{j['score']:>3.0f}] {j['title'][:55]:<55} {j['company'][:22]:<22} {j['location'][:22]:<22} {j['url']}")
    print(f"\n{len(rows)} of {total} matching job(s)")
    return 0


def cmd_probe(args: argparse.Namespace) -> int:
    """Fetch one source live and show how each job would be judged (nothing stored/notified)."""
    from .extract import enrich

    app = _load(args)
    src = next((s for s in app.sources if s.name == args.source), None)
    if src is None:
        print(f"Unknown source '{args.source}'. Available:\n  " + "\n  ".join(s.name for s in app.sources))
        return 1
    try:
        jobs = src.fetch()
    except SourceError as e:
        print(f"FETCH FAILED: {e}")
        return 1
    shown = 0
    print(f"{len(jobs)} job(s) returned by {src.name}")
    for job in jobs:
        enrich(job)
        r = app.matcher.evaluate(job)
        if args.all or r.matched:
            shown += 1
            verdict = "MATCH " if r.matched else "reject"
            print(f"  {verdict} [{r.score:>3.0f}] {job.title[:60]:<60} | {job.location[:30]:<30} | " + ("; ".join(r.rejects) if r.rejects else ", ".join(r.reasons)))
        if shown >= args.limit:
            break
    return 0


def cmd_digest(args: argparse.Namespace) -> int:
    """Send the daily summary now."""
    app = _load(args)
    app.db.set_meta("last_digest_date", "")
    sent = app.engine.maybe_daily_digest()
    print("Digest sent." if sent else "Nothing to send (no matching jobs in the last 24h, or it is before digest_time).")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="jobwatch", description="Real-time job opening monitor with instant notifications")
    p.add_argument("-c", "--config", default="config.yaml", help="path to config.yaml (default: ./config.yaml)")
    p.add_argument("-v", "--verbose", action="store_true", help="debug logging")
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("init", help="create config.yaml and .env from the examples").set_defaults(fn=cmd_init)
    c = sub.add_parser("check", help="validate config, sources and channels")
    c.add_argument("--live", action="store_true", help="also fetch every source once (no storing)")
    c.set_defaults(fn=cmd_check)
    r = sub.add_parser("run", help="start monitoring")
    r.add_argument("--once", action="store_true", help="poll every source once and exit")
    r.add_argument("--with-dashboard", action="store_true", help="also serve the dashboard in this process")
    r.set_defaults(fn=cmd_run)
    sub.add_parser("dashboard", help="serve the web dashboard only").set_defaults(fn=cmd_dashboard)
    t = sub.add_parser("test-notify", help="send a test message on each enabled channel")
    t.add_argument("--channel", help="only this channel")
    t.set_defaults(fn=cmd_test_notify)
    sub.add_parser("telegram-id", help="verify the Telegram bot and find your chat id").set_defaults(fn=cmd_telegram_id)
    sub.add_parser("sources", help="show source health").set_defaults(fn=cmd_sources)
    e = sub.add_parser("enable", help="re-enable an auto-disabled source")
    e.add_argument("source")
    e.set_defaults(fn=cmd_enable)
    sub.add_parser("rescore", help="re-evaluate stored jobs after changing preferences").set_defaults(fn=cmd_rescore)
    j = sub.add_parser("jobs", help="list stored matching jobs")
    j.add_argument("-q", "--query")
    j.add_argument("--min-score", type=float, default=0)
    j.add_argument("--limit", type=int, default=30)
    j.add_argument("--newest", action="store_true", help="sort by discovery time instead of score")
    j.set_defaults(fn=cmd_jobs)
    pr = sub.add_parser("probe", help="fetch one source and show match decisions (nothing stored)")
    pr.add_argument("source")
    pr.add_argument("--all", action="store_true", help="also show rejected jobs")
    pr.add_argument("--limit", type=int, default=40)
    pr.set_defaults(fn=cmd_probe)
    sub.add_parser("digest", help="send the daily summary now").set_defaults(fn=cmd_digest)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.fn(args) or 0)
    except ConfigError as e:
        print(f"CONFIG ERROR: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
