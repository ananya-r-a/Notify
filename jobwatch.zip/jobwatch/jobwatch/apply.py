"""Assisted application kit.

Generates a tailored cover note and the profile answers you usually retype, then hands you
the official apply link. **It never submits an application for you**: LinkedIn, Naukri, Indeed,
Foundit, Instahyre, Cutshort and Wellfound all prohibit automated applications in their terms,
and Greenhouse/Lever/Ashby only expose application-submission APIs to employers, not candidates.
"""

from __future__ import annotations

from typing import Any


class _SafeDict(dict):
    def __missing__(self, key: str) -> str:  # unknown placeholders stay visible instead of crashing
        return "{" + key + "}"


def build_kit(job: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    """Return ``{cover_note, answers, links, apply_url, checklist}`` for one stored job."""
    skills = ", ".join((job.get("skills_required") or [])[:6]) or "software engineering"
    values = _SafeDict(
        company=job.get("company") or "your", title=job.get("title") or "this", skills=skills,
        name=profile.get("name") or "", location=job.get("location") or "", source=job.get("source") or "",
    )
    template = profile.get("cover_note") or ""
    try:
        note = template.format_map(values)
    except (ValueError, IndexError):  # malformed braces in the user's template
        note = template
    answers = {k: str(v) for k, v in (profile.get("answers") or {}).items()}
    for key, label in (("email", "Email"), ("phone", "Phone")):
        if profile.get(key):
            answers.setdefault(label, str(profile[key]))
    missing = [k for k in ("name", "email") if not profile.get(k)]
    checklist = [
        "Open the official posting and confirm the role, location and experience still match.",
        "Paste the cover note below (edit it: generic notes are easy to spot).",
        "Attach your latest résumé; mirror the job's top skills in your summary if they are true for you.",
        "Submit on the company's own page, then click 'Mark applied' here to track it.",
    ]
    if missing:
        checklist.insert(0, "Fill " + ", ".join(f"profile.{m}" for m in missing) + " in config.yaml for a complete kit.")
    return {
        "cover_note": note,
        "answers": answers,
        "links": {k: str(v) for k, v in (profile.get("links") or {}).items()},
        "apply_url": job.get("apply_url") or job.get("url") or "",
        "checklist": checklist,
    }
