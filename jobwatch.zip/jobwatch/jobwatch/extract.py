"""Derive structured fields (skills, experience, salary, work mode) from job text.

These are heuristics over free text. They are deliberately conservative: when the
text does not say, the field stays ``None`` so the matcher can treat it as
"unknown" instead of guessing.
"""

from __future__ import annotations

import re
from typing import Iterable

from .models import Job

# --------------------------------------------------------------------------- skills

#: canonical skill -> aliases (all matched case-insensitively unless noted below)
SKILLS: dict[str, list[str]] = {
    # languages
    "python": ["python", "python3"],
    "java": ["java", "core java", "j2ee"],
    "javascript": ["javascript", "js", "ecmascript", "es6"],
    "typescript": ["typescript"],
    "go": ["golang", "go language", "go programming"],
    "rust": ["rust"],
    "c++": ["c++", "cpp", "modern c++"],
    "c#": ["c#", "csharp"],
    "c": ["embedded c", "c programming", "ansi c"],
    ".net": [".net", "dotnet", "asp.net", ".net core"],
    "kotlin": ["kotlin"],
    "swift": ["swift", "swiftui"],
    "scala": ["scala"],
    "ruby": ["ruby", "ruby on rails", "rails"],
    "php": ["php", "laravel"],
    "perl": ["perl"],
    "bash": ["bash", "shell scripting", "shell script"],
    "sql": ["sql", "t-sql", "pl/sql"],
    "matlab": ["matlab"],
    "simulink": ["simulink"],
    # web / frameworks
    "react": ["react", "react.js", "reactjs"],
    "angular": ["angular", "angularjs"],
    "vue": ["vue", "vue.js", "vuejs"],
    "next.js": ["next.js", "nextjs"],
    "node.js": ["node.js", "nodejs", "node js", "express.js"],
    "django": ["django"],
    "flask": ["flask"],
    "fastapi": ["fastapi"],
    "spring": ["spring", "spring boot", "springboot", "spring framework"],
    "graphql": ["graphql"],
    "rest": ["rest", "restful", "rest api", "rest apis"],
    "grpc": ["grpc"],
    "html": ["html", "html5"],
    "css": ["css", "css3", "sass", "tailwind"],
    "microservices": ["microservices", "micro-services", "microservice"],
    # data / ml
    "machine learning": ["machine learning", "ml"],
    "deep learning": ["deep learning"],
    "nlp": ["nlp", "natural language processing"],
    "computer vision": ["computer vision", "image processing"],
    "llm": ["llm", "llms", "large language models", "generative ai", "genai", "gen ai", "rag"],
    "pytorch": ["pytorch"],
    "tensorflow": ["tensorflow", "keras"],
    "scikit-learn": ["scikit-learn", "sklearn"],
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "spark": ["spark", "pyspark", "apache spark"],
    "hadoop": ["hadoop", "hive"],
    "kafka": ["kafka"],
    "airflow": ["airflow"],
    "dbt": ["dbt"],
    "snowflake": ["snowflake"],
    "databricks": ["databricks"],
    "tableau": ["tableau"],
    "power bi": ["power bi", "powerbi"],
    "data structures": ["data structures", "dsa"],
    "algorithms": ["algorithms"],
    "system design": ["system design", "distributed systems", "low level design", "high level design"],
    # databases
    "postgresql": ["postgresql", "postgres"],
    "mysql": ["mysql"],
    "mongodb": ["mongodb"],
    "redis": ["redis"],
    "elasticsearch": ["elasticsearch", "opensearch", "elk"],
    "cassandra": ["cassandra"],
    "dynamodb": ["dynamodb"],
    "nosql": ["nosql"],
    # cloud / devops
    "aws": ["aws", "amazon web services", "ec2", "s3", "lambda"],
    "azure": ["azure"],
    "gcp": ["gcp", "google cloud"],
    "kubernetes": ["kubernetes", "k8s", "eks", "gke"],
    "docker": ["docker", "containers", "containerization"],
    "terraform": ["terraform", "infrastructure as code", "iac"],
    "ansible": ["ansible"],
    "jenkins": ["jenkins"],
    "ci/cd": ["ci/cd", "cicd", "ci cd", "github actions", "gitlab ci"],
    "git": ["git", "github", "gitlab"],
    "linux": ["linux", "unix"],
    "prometheus": ["prometheus", "grafana"],
    "networking": ["tcp/ip", "networking", "bgp", "routing and switching"],
    # mobile
    "android": ["android"],
    "ios": ["ios", "objective-c"],
    "flutter": ["flutter", "dart"],
    "react native": ["react native"],
    # embedded / systems / semiconductor / automotive
    "embedded": ["embedded", "embedded systems", "embedded software"],
    "firmware": ["firmware"],
    "rtos": ["rtos", "freertos", "zephyr", "threadx"],
    "linux kernel": ["linux kernel", "device drivers", "kernel driver", "bsp", "board bring-up"],
    "yocto": ["yocto", "buildroot"],
    "arm": ["arm cortex", "cortex-m", "cortex-a", "arm architecture", "stm32"],
    "autosar": ["autosar"],
    "can": ["can bus", "can fd", "canoe", "canalyzer"],
    "uds": ["uds", "iso 14229", "diagnostics"],
    "iso 26262": ["iso 26262", "functional safety", "iso26262", "asil"],
    "misra": ["misra"],
    "adas": ["adas", "autonomous driving", "sensor fusion"],
    "ros": ["ros", "ros2"],
    "qnx": ["qnx"],
    "verilog": ["verilog"],
    "systemverilog": ["systemverilog", "system verilog"],
    "vhdl": ["vhdl"],
    "uvm": ["uvm"],
    "fpga": ["fpga"],
    "asic": ["asic", "soc design"],
    "rtl": ["rtl", "rtl design"],
    "vlsi": ["vlsi", "physical design", "design verification", "dft"],
    "pcie": ["pcie", "ddr", "usb", "ethernet"],
    "gpu": ["cuda", "opencl", "gpu programming"],
    "signal processing": ["signal processing", "dsp"],
    # testing / quality / security
    "selenium": ["selenium"],
    "pytest": ["pytest"],
    "junit": ["junit", "testng"],
    "cypress": ["cypress", "playwright"],
    "test automation": ["test automation", "automation testing", "sdet", "qa automation"],
    "api testing": ["postman", "api testing"],
    "owasp": ["owasp"],
    "security": ["cybersecurity", "application security", "appsec", "penetration testing", "pentest", "siem", "threat modeling"],
    "cryptography": ["cryptography", "pki", "tls"],
    # practices
    "agile": ["agile", "scrum"],
    "jira": ["jira"],
    "oop": ["oop", "object oriented", "object-oriented"],
    "tdd": ["tdd", "test driven development"],
    "blockchain": ["blockchain", "solidity", "smart contracts"],
}

_PRE = r"(?<![A-Za-z0-9+#])"
_POST = r"(?![A-Za-z0-9+#])"

#: Skills whose names are ordinary English words or short abbreviations. They are
#: matched case-sensitively, using only the capitalised/upper-case forms below.
_STRICT_PATTERNS: dict[str, str] = {
    "rust": r"Rust",
    "swift": r"Swift(?:UI)?",
    "spring": r"Spring(?: Boot| Framework)?",
    "flask": r"Flask",
    "ruby": r"Ruby(?: on Rails)?|Rails",
    "ros": r"ROS2?",
    "arm": r"ARM Cortex|Cortex-[MA]|ARM architecture|STM32",
    "can": r"CAN bus|CAN FD|CANoe|CANalyzer",
    "rest": r"REST(?:ful)?(?: APIs?)?",
}


def _build_skill_patterns() -> list[tuple[str, re.Pattern[str]]]:
    patterns: list[tuple[str, re.Pattern[str]]] = []
    for canonical, aliases in SKILLS.items():
        if canonical in _STRICT_PATTERNS:
            rx = re.compile(_PRE + "(?:" + _STRICT_PATTERNS[canonical] + ")" + _POST)
        else:
            body = "|".join(sorted((re.escape(a) for a in aliases), key=len, reverse=True))
            rx = re.compile(_PRE + "(?:" + body + ")" + _POST, re.I)
        patterns.append((canonical, rx))
    return patterns


_SKILL_PATTERNS = _build_skill_patterns()
# Bare "Go" (the language) is only accepted when listed alongside other technologies.
_GO_LIST = re.compile(_PRE + r"Go(?=\s*(?:,|/|;|\)|\band\b|\bor\b))")


def canonical_skill(name: str) -> str:
    """Map a user-supplied skill name to its canonical form (or the lower-cased name)."""
    low = name.strip().lower()
    if low in SKILLS:
        return low
    for canonical, aliases in SKILLS.items():
        if low in (a.lower() for a in aliases):
            return canonical
    return low


def find_skills(text: str) -> set[str]:
    """Return the canonical skills mentioned in ``text``."""
    found: set[str] = set()
    for canonical, rx in _SKILL_PATTERNS:
        if rx.search(text):
            found.add(canonical)
    if _GO_LIST.search(text):
        found.add("go")
    return found


_PREFERRED_HEADING = re.compile(
    r"^(?:preferred|nice[- ]to[- ]have|good[- ]to[- ]have|bonus|bonus points|pluses|plus|desirable|added advantage|"
    r"what would (?:be )?(?:a )?(?:plus|great)|extra credit|it(?:'|’)s a plus)\b",
    re.I,
)
_REQUIRED_HEADING = re.compile(
    r"^(?:requirements?|qualifications?|must[- ]have|required|minimum|what you(?:'|’)ll need|what we(?:'|’)re looking for|"
    r"skills|key skills|technical skills|about you|who you are|you have|you bring|responsibilities|"
    r"what you(?:'|’)ll do|the role|basic qualifications)\b",
    re.I,
)
_INLINE_PREFERRED = re.compile(
    r"\b(?:preferred|nice to have|good to have|a plus|is a plus|are a plus|bonus|desirable|added advantage|advantageous)\b", re.I
)


def split_skills(description: str) -> tuple[list[str], list[str]]:
    """Return ``(required, preferred)`` skills found in a plain-text description.

    Lines under headings such as "Nice to have"/"Preferred" (or containing "a plus",
    "bonus", …) count as preferred; everything else counts as required. A skill
    that appears in both ends up in ``required``.
    """
    required: set[str] = set()
    preferred: set[str] = set()
    mode = "required"
    for raw in description.splitlines():
        line = raw.strip()
        if not line:
            continue
        head = line.lstrip("-•*·#: \t").rstrip(": \t")
        if len(head) <= 80:
            if _PREFERRED_HEADING.match(head):
                mode = "preferred"
                if len(head) > 25:  # heading with content on the same line
                    preferred |= find_skills(line)
                continue
            if _REQUIRED_HEADING.match(head):
                mode = "required"
                continue
        skills = find_skills(line)
        if not skills:
            continue
        if _INLINE_PREFERRED.search(line) or mode == "preferred":
            preferred |= skills
        else:
            required |= skills
    return sorted(required), sorted(preferred - required)


# --------------------------------------------------------------------------- experience

_NUM = r"(\d{1,2}(?:\.\d)?)"
_RANGE = re.compile(_NUM + r"\s*(?:-|–|—|to)\s*" + _NUM + r"\s*\+?\s*(?:years?|yrs?)\b", re.I)
_PLUS = re.compile(_NUM + r"\s*\+\s*(?:years?|yrs?)\b", re.I)
_MIN = re.compile(r"(?:minimum|min\.?|at least|atleast|over|more than)\s*(?:of\s*)?" + _NUM + r"\s*(?:\+\s*)?(?:years?|yrs?)\b", re.I)
_PLAIN = re.compile(
    _NUM + r"\s*(?:years?|yrs?)\s*(?:of\s*)?(?:relevant\s*|professional\s*|work\s*|industry\s*|hands[- ]on\s*|total\s*|overall\s*)?(?:experience|exp)\b",
    re.I,
)
_FRESHER = re.compile(r"\b(?:freshers?|fresh graduates?|entry[- ]level|no experience (?:required|needed)|new grads?|recent graduates?)\b", re.I)


def _near_experience(text: str, start: int, end: int) -> bool:
    window = text[max(0, start - 80) : end + 80].lower()
    return "experience" in window or " exp" in window


def parse_experience(text: str, strict: bool = True) -> tuple[float, float | None] | None:
    """Extract ``(min_years, max_years)`` from text, or ``None`` if not stated.

    ``strict=True`` (descriptions) requires the word "experience" near the number
    so company ages ("10+ years in business") are ignored; ``strict=False`` is for
    short source-provided hints such as "2-5 Yrs".
    """
    if not text:
        return None
    for m in _RANGE.finditer(text):
        if not strict or _near_experience(text, m.start(), m.end()):
            lo, hi = float(m.group(1)), float(m.group(2))
            if lo <= hi <= 40:
                return lo, hi
    mins: list[float] = []
    for rx in (_PLUS, _MIN, _PLAIN):
        for m in rx.finditer(text):
            if not strict or _near_experience(text, m.start(), m.end()):
                value = float(m.group(1))
                if value <= 40:
                    mins.append(value)
    if mins:
        return max(mins), None
    if _FRESHER.search(text):
        return 0.0, 1.0
    return None


_SENIORITY: list[tuple[re.Pattern[str], tuple[float, float | None]]] = [
    (re.compile(r"\b(?:intern|internship|trainee|apprentice)\b", re.I), (0, 0)),
    (re.compile(r"\b(?:graduate|fresher|entry[- ]level|campus)\b", re.I), (0, 1)),
    (re.compile(r"\b(?:junior|jr\.?)\b", re.I), (0, 2)),
    (re.compile(r"\b(?:senior|sr\.?)\b", re.I), (4, None)),
    (re.compile(r"\b(?:lead|tech lead)\b", re.I), (6, None)),
    (re.compile(r"\b(?:staff)\b", re.I), (8, None)),
    (re.compile(r"\b(?:principal|distinguished|fellow)\b", re.I), (10, None)),
    (re.compile(r"\b(?:director|head of|vp|vice president)\b", re.I), (12, None)),
]


def infer_seniority(title: str) -> tuple[float, float | None] | None:
    """Rough experience band implied by seniority words in the title (heuristic)."""
    for rx, band in _SENIORITY:
        if rx.search(title or ""):
            return float(band[0]), (float(band[1]) if band[1] is not None else None)
    return None


# --------------------------------------------------------------------------- work mode / type

def detect_work_mode(text: str, hint: str = "") -> str:
    """Return 'remote', 'hybrid', 'onsite' or '' from a source hint and/or free text."""
    blob = f"{hint} {text}".lower()
    if re.search(r"\bhybrid\b", blob):
        return "hybrid"
    if re.search(r"\b(?:fully |100% |completely )?remote\b|work from home|\bwfh\b|work-from-home", blob):
        if not re.search(r"\b(?:not|no|non)[- ]remote\b|remote work is not|cannot be remote", blob):
            return "remote"
    if re.search(r"\bon[- ]?site\b|work from office|\bwfo\b|in[- ]office|office[- ]based", blob):
        return "onsite"
    return ""


def normalise_work_mode(value: str) -> str:
    """Normalise source-provided work-mode labels ("OnSite", "TELECOMMUTE", …)."""
    low = (value or "").strip().lower().replace("-", "").replace("_", "").replace(" ", "")
    if low in ("remote", "telecommute", "fullyremote", "wfh", "workfromhome"):
        return "remote"
    if low == "hybrid":
        return "hybrid"
    if low in ("onsite", "inoffice", "office", "wfo", "onsiteonly"):
        return "onsite"
    return ""


def normalise_employment_type(value: str, text: str = "") -> str:
    """Map assorted labels to 'Full-time', 'Part-time', 'Contract', 'Internship', 'Temporary' or ''."""
    low = f"{value or ''}".lower().replace("_", " ").replace("-", " ")
    if not low.strip():
        low = text.lower()[:400] if text else ""
        if not re.search(r"\b(?:full time|part time|contract|intern(?:ship)?|temporary)\b", low.replace("-", " ")):
            return ""
    if "intern" in low:
        return "Internship"
    if "part time" in low or "parttime" in low:
        return "Part-time"
    if "contract" in low or "freelance" in low or "consultant" in low:
        return "Contract"
    if "temp" in low:
        return "Temporary"
    if "full time" in low or "fulltime" in low or "permanent" in low or "regular" in low:
        return "Full-time"
    return ""


# --------------------------------------------------------------------------- salary

_LPA_RANGE = re.compile(
    r"(?:₹|INR|Rs\.?)?\s*(\d{1,3}(?:\.\d+)?)\s*(?:-|–|—|to)\s*(\d{1,3}(?:\.\d+)?)\s*(?:LPA|lpa|lakhs?|lacs?|L\b)(?:\s*(?:per annum|p\.?a\.?))?",
)
_LPA_SINGLE = re.compile(r"(?:₹|INR|Rs\.?)?\s*(\d{1,3}(?:\.\d+)?)\s*(?:LPA|lpa|lakhs? per annum|lacs? per annum)")
_INR_ABS = re.compile(
    r"(?:₹|INR|Rs\.?)\s*(\d{1,3}(?:,\d{2,3})+|\d{5,9})\s*(?:-|–|—|to)\s*(?:₹|INR|Rs\.?)?\s*(\d{1,3}(?:,\d{2,3})+|\d{5,9})"
    r"(?:\s*(?:per|/|a)\s*(month|year|annum|yr|mo))?",
    re.I,
)
_OTHER_CCY = re.compile(r"(?:\$|USD|€|EUR|£|GBP)\s?\d[\d,.]*\s?[kK]?\s*(?:-|–|—|to)\s*(?:\$|USD|€|EUR|£|GBP)?\s?\d[\d,.]*\s?[kK]?(?:\s*(?:per|/)\s*(?:year|yr|annum|hour|hr|month))?")


def parse_salary(text: str) -> tuple[str, float | None, float | None]:
    """Extract ``(salary_text, min_lpa, max_lpa)`` — LPA = lakh INR per annum.

    Non-INR salaries are returned as text only (no currency conversion is attempted).
    """
    if not text:
        return "", None, None
    m = _LPA_RANGE.search(text)
    if m:
        lo, hi = float(m.group(1)), float(m.group(2))
        if lo <= hi <= 500:
            return m.group(0).strip(), lo, hi
    m = _INR_ABS.search(text)
    if m:
        lo = float(m.group(1).replace(",", ""))
        hi = float(m.group(2).replace(",", ""))
        unit = (m.group(3) or "").lower()
        if unit in ("month", "mo") or (not unit and hi < 300000 and re.search(r"per month|monthly|/month", text, re.I)):
            lo, hi = lo * 12, hi * 12
        if 0 < lo <= hi:
            return m.group(0).strip(), round(lo / 100000, 2), round(hi / 100000, 2)
    m = _LPA_SINGLE.search(text)
    if m:
        v = float(m.group(1))
        return m.group(0).strip(), v, v
    m = _OTHER_CCY.search(text)
    if m:
        return m.group(0).strip(), None, None
    return "", None, None


# --------------------------------------------------------------------------- enrich

def enrich(job: Job) -> Job:
    """Fill every derived field on ``job`` in place and return it."""
    text = f"{job.title}\n{job.description}"

    # skills
    job.skills_required, job.skills_preferred = split_skills(job.description)
    title_skills = find_skills(job.title)
    if title_skills:
        job.skills_required = sorted(set(job.skills_required) | title_skills)
        job.skills_preferred = [s for s in job.skills_preferred if s not in title_skills]

    # experience: source hint → description → title seniority
    exp = parse_experience(job.experience_text, strict=False) if job.experience_text else None
    if exp is None:
        exp = parse_experience(job.description, strict=True)
    job.exp_inferred = False
    if exp is None:
        exp = infer_seniority(job.title)
        job.exp_inferred = exp is not None
    if exp is not None:
        job.exp_min, job.exp_max = exp

    # salary
    if job.salary_text or job.description:
        stext, lo, hi = parse_salary(job.salary_text or "")
        if not stext:
            stext, lo, hi = parse_salary(job.description)
        if stext and not job.salary_text:
            job.salary_text = stext
        job.salary_min_lpa, job.salary_max_lpa = lo, hi

    # work mode / employment type
    mode = normalise_work_mode(job.work_mode)
    if not mode:
        mode = detect_work_mode(job.location + " " + job.title, hint=job.work_mode)
    if not mode:
        mode = detect_work_mode(job.description[:1500])
    job.work_mode = mode
    job.employment_type = normalise_employment_type(job.employment_type, text) or job.employment_type
    return job


def join_unique(parts: Iterable[str], sep: str = "; ") -> str:
    """Join non-empty strings, dropping duplicates while keeping order."""
    seen: list[str] = []
    for part in parts:
        part = (part or "").strip()
        if part and part not in seen:
            seen.append(part)
    return sep.join(seen)
