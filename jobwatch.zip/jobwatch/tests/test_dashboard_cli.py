import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

from jobwatch.apply import build_kit
from jobwatch.cli import main
from jobwatch.dashboard import create_app

ROOT = Path(__file__).resolve().parent.parent


def write_cfg(tmp_path, extra=None):
    cfg = {"data_dir": str(tmp_path / "data"), "sources": [], "dashboard": {"host": "127.0.0.1", "token": "s3cret-token"},
           "profile": {"name": "Asha", "email": "asha@x.test", "answers": {"Notice period": "30 days"}, "links": {"GitHub": "https://github.com/asha"}},
           "notifications": {"telegram": {"enabled": False}, "email": {"enabled": False}, "desktop": {"enabled": False}}}
    cfg.update(extra or {})
    p = tmp_path / "config.yaml"
    p.write_text(yaml.safe_dump(cfg))
    return str(p)


def seed(db):
    for i, (title, score, mode) in enumerate([("Python Developer", 90, "hybrid"), ("Embedded Engineer", 60, "onsite"), ("Weird <script>alert(1)</script> Role", 40, "")], 1):
        db.insert_job(dict(uid=f"s|{i}", source="s", platform="p", external_id=str(i), title=title, company="Acme", location="Bengaluru",
                           description="Build <b>things</b> in Python", url=f"https://x.test/{i}", apply_url=f"https://x.test/{i}/apply", matched=1, score=score,
                           work_mode=mode, discovered_at="2026-11-18T00:00:00+00:00", last_seen_at="2026-11-18T00:00:00+00:00", skills_required=["python"],
                           score_breakdown={"title": 1.0, "skills": 0.5, "_reasons": ["priority role"], "_rejects": []}))


@pytest.fixture()
def client(tmp_path):
    app = create_app(write_cfg(tmp_path))
    from jobwatch.db import Database

    seed(Database(tmp_path / "data" / "jobwatch.db"))
    return app.test_client()


def login(c):
    return c.post("/login", data={"token": "s3cret-token"})


def test_requires_login_and_rejects_wrong_token(client):
    assert client.get("/").status_code == 302 and "/login" in client.get("/").headers["Location"]
    assert client.get("/api/jobs").status_code == 401
    assert "Wrong token" in client.post("/login", data={"token": "nope"}).get_data(as_text=True)
    assert client.get("/healthz").status_code == 200  # public liveness probe
    assert login(client).status_code == 302 and client.get("/").status_code == 200


def test_open_redirect_blocked_on_login(client):
    r = client.post("/login?next=//evil.test", data={"token": "s3cret-token"})
    assert r.headers["Location"] == "/"


def test_index_search_filter_sort(client):
    login(client)
    html = client.get("/").get_data(as_text=True)
    assert "Python Developer" in html and "Embedded Engineer" in html
    assert "Embedded Engineer" not in client.get("/?q=python+developer").get_data(as_text=True)
    assert "Python Developer" not in client.get("/?min_score=70&work_mode=onsite").get_data(as_text=True)
    api = client.get("/api/jobs?sort=score").get_json()
    assert [j["title"] for j in api["jobs"]][:2] == ["Python Developer", "Embedded Engineer"] and api["total"] == 3 and "description" not in api["jobs"][0]


def test_html_is_escaped_in_pages(client):
    login(client)
    jid = client.get("/api/jobs?q=Weird").get_json()["jobs"][0]["id"]
    page = client.get(f"/job/{jid}").get_data(as_text=True)
    assert "<script>alert(1)</script>" not in page and "&lt;script&gt;" in page


def test_job_detail_shows_score_and_assist_kit(client):
    login(client)
    jid = client.get("/api/jobs?q=Python").get_json()["jobs"][0]["id"]
    page = client.get(f"/job/{jid}").get_data(as_text=True)
    assert "Relevance 90/100" in page and "Cover note" in page and "Notice period" in page and "30 days" in page
    assert "https://x.test/1/apply" in page and client.get("/job/9999").status_code == 404


def test_status_update_and_filter(client):
    login(client)
    jid = client.get("/api/jobs?q=Python").get_json()["jobs"][0]["id"]
    assert client.post(f"/job/{jid}/status", data={"user_status": "applied", "notes": "referral from Ravi"}).status_code == 302
    api = client.get("/api/jobs?user_status=applied").get_json()
    assert api["total"] == 1 and api["jobs"][0]["notes"] == "referral from Ravi"
    assert client.post(f"/job/{jid}/status", data={"user_status": "bogus"}).status_code == 400
    assert client.get("/api/stats").get_json()["applied"] == 1


def test_csrf_cross_origin_post_blocked(client):
    login(client)
    r = client.post("/job/1/status", data={"user_status": "applied"}, headers={"Origin": "http://evil.test"})
    assert r.status_code == 403


def test_sources_page_and_commands(client, tmp_path):
    login(client)
    assert client.get("/sources").status_code == 200
    assert client.post("/sources/run", data={"source": ""}).status_code == 302
    from jobwatch.db import Database

    assert [c["kind"] for c in Database(tmp_path / "data" / "jobwatch.db").pop_commands()] == ["run_now"]


def test_refuses_public_bind_without_token(tmp_path):
    with pytest.raises(RuntimeError, match="no dashboard.token"):
        create_app(write_cfg(tmp_path, {"dashboard": {"host": "0.0.0.0", "token": ""}}))


def test_no_token_localhost_is_open(tmp_path):
    app = create_app(write_cfg(tmp_path, {"dashboard": {"host": "127.0.0.1", "token": ""}}))
    assert app.test_client().get("/").status_code == 200


def test_build_kit_fills_placeholders_and_flags_missing_profile():
    kit = build_kit({"company": "Acme", "title": "SRE", "skills_required": ["python", "aws"], "url": "https://x"},
                    {"name": "", "cover_note": "Hi {company}, {title} with {skills}. {unknown}"})
    assert kit["cover_note"] == "Hi Acme, SRE with python, aws. {unknown}" and any("profile.name" in c for c in kit["checklist"])


# ---------------------------------------------------------------- CLI (in-process and real subprocess)
def test_cli_check_reports_problems(tmp_path, capsys):
    cfgp = write_cfg(tmp_path, {"notifications": {"telegram": {"enabled": True, "bot_token": "", "chat_id": ""}}})
    assert main(["-c", cfgp, "check"]) == 1
    out = capsys.readouterr().out
    assert "telegram" in out and "missing: bot_token, chat_id" in out and "none enabled" in out


def test_cli_invalid_config_message(tmp_path, capsys):
    p = tmp_path / "bad.yaml"
    p.write_text("preferences:\n  work_modes: [moon]\n")
    assert main(["-c", str(p), "check"]) == 2 and "work_modes" in capsys.readouterr().out
    p.write_text("sources:\n  - type: greenhouse\n")
    assert main(["-c", str(p), "check"]) == 2 and "board" in capsys.readouterr().out


def test_cli_subprocess_run_once_against_fake_board(tmp_path, server):
    """Real process, real config file, real HTTP: the closest thing to what a user runs."""
    server.on("GET", "/v1/boards/acme/jobs", 200, {"jobs": [
        {"id": 1, "title": "Python Developer", "location": {"name": "Bengaluru"}, "absolute_url": "https://b.example/1", "content": "3-5 years of experience in Python"}]})
    token = "9:" + "z" * 30
    server.on("POST", f"/bot{token}/sendMessage", 200, {"ok": True})
    cfgp = write_cfg(tmp_path, {
        "sources": [{"type": "greenhouse", "board": "acme", "company": "Acme", "api_base": server.base}],
        "notifications": {"telegram": {"enabled": True, "bot_token": token, "chat_id": "1", "api_base": server.base},
                          "routing": {"job": ["telegram"], "priority": ["telegram"], "digest": ["telegram"], "system": ["telegram"]}},
        "engine": {"first_run": "notify"}, "http": {"min_host_interval": 0}})
    run = lambda *a: subprocess.run([sys.executable, "-m", "jobwatch", "-c", cfgp, *a], cwd=ROOT, capture_output=True, text=True, timeout=60)  # noqa: E731
    r = run("run", "--once")
    assert r.returncode == 0 and "greenhouse:acme" in r.stdout and "new=1" in r.stdout, r.stdout + r.stderr
    assert len(server.hits(f"/bot{token}/sendMessage")) == 1
    j = run("jobs")
    assert "Python Developer" in j.stdout
    again = run("run", "--once")  # second process: persisted DB prevents a repeat alert
    assert again.returncode == 0 and len(server.hits(f"/bot{token}/sendMessage")) == 1
    assert "greenhouse:acme" in run("sources").stdout
    log = (tmp_path / "data" / "jobwatch.log").read_text()
    assert token not in log and "zzzzzzzz" not in log  # secrets never reach the log file
    probe = run("probe", "greenhouse:acme")
    assert probe.returncode == 0 and "MATCH" in probe.stdout


def test_cli_test_notify_sends_real_messages(tmp_path, server):
    token = "9:" + "q" * 30
    server.on("POST", f"/bot{token}/sendMessage", 200, {"ok": True})
    cfgp = write_cfg(tmp_path, {"notifications": {"telegram": {"enabled": True, "bot_token": token, "chat_id": "1", "api_base": server.base}}})
    assert main(["-c", cfgp, "test-notify"]) == 0
    assert len(server.hits(f"/bot{token}/sendMessage")) == 2


def test_cli_telegram_id_helper(tmp_path, server, capsys):
    token = "9:" + "w" * 30
    server.on("POST", f"/bot{token}/getMe", 200, {"ok": True, "result": {"username": "jw", "first_name": "JW"}})
    server.on("POST", f"/bot{token}/getUpdates", 200, {"ok": True, "result": [{"message": {"chat": {"id": 555, "type": "private", "first_name": "A"}}}]})
    cfgp = write_cfg(tmp_path, {"notifications": {"telegram": {"enabled": True, "bot_token": token, "chat_id": "", "api_base": server.base}}})
    assert main(["-c", cfgp, "telegram-id"]) == 0 and "chat_id = 555" in capsys.readouterr().out


def test_init_creates_files_without_overwriting(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    assert main(["init"]) == 0 and (tmp_path / "config.yaml").exists() and (tmp_path / ".env").exists()
    (tmp_path / "config.yaml").write_text("# mine\n")
    main(["init"])
    assert (tmp_path / "config.yaml").read_text() == "# mine\n"
