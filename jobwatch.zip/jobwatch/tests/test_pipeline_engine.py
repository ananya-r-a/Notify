"""End-to-end flows: fake Greenhouse board + fake Telegram API → real engine, DB and notifier."""

import json
import time

import pytest

from conftest import make_config
from jobwatch.app import build_http
from jobwatch.db import Database
from jobwatch.engine import Engine
from jobwatch.matching import Matcher
from jobwatch.notify import NotificationService, build_notifiers
from jobwatch.pipeline import Pipeline
from jobwatch.sources import build_sources

TOKEN = "1:" + "t" * 30
SEND = f"/bot{TOKEN}/sendMessage"


def gh_job(i, title="Backend Engineer", loc="Bengaluru, India", content="3-5 years of experience in Python. Requirements: Python, AWS", url=None):
    return {"id": i, "title": title, "location": {"name": loc}, "absolute_url": url or f"https://boards.example/acme/jobs/{i}",
            "updated_at": "2026-11-18T00:00:00Z", "content": content}


def build(tmp_path, server, jobs, overrides=None, sources=None):
    cfg = make_config(tmp_path, {
        "notifications": {"telegram": {"enabled": True, "bot_token": TOKEN, "chat_id": "42", "api_base": server.base}},
        "sources": sources or [{"type": "greenhouse", "board": "acme", "company": "Acme", "api_base": server.base, "interval": 1}],
        **(overrides or {}),
    })
    db = Database(cfg.db_path)
    http = build_http(cfg, db)
    srcs = build_sources(cfg.sources, http, min_interval=1)
    pipeline = Pipeline(db, Matcher(cfg.prefs), cfg.engine)
    notifier = NotificationService(db, build_notifiers(cfg.notifications, sleep=lambda s: None), cfg.notifications["routing"])
    return cfg, db, Engine(cfg, db, srcs, pipeline, notifier)


def set_board(server, jobs):
    server.on("GET", "/v1/boards/acme/jobs", 200, {"jobs": jobs})


def sent_texts(server):
    return [json.loads(r["body"])["text"] for r in server.hits(SEND)]


@pytest.fixture()
def telegram(server):
    server.on("POST", SEND, 200, {"ok": True, "result": {}})
    return server


def test_new_matching_job_triggers_exactly_one_notification(tmp_path, telegram):
    set_board(telegram, [gh_job(1), gh_job(2, title="Sales Executive"), gh_job(3, loc="Hyderabad")])
    _, db, eng = build(tmp_path, telegram, None)
    out = eng.run_once()
    assert out[0]["ok"] and out[0]["seen"] == 3 and out[0]["new"] == 3 and out[0]["new_matched"] == 1
    texts = sent_texts(telegram)
    assert len(texts) == 1 and "Backend Engineer" in texts[0] and "Acme" in texts[0]
    eng.run_once()  # nothing changed → no more messages
    assert len(sent_texts(telegram)) == 1
    stored = {j["external_id"]: j for j in db.query_jobs(matched_only=False, limit=10)[0]}
    assert stored["1"]["matched"] == 1 and stored["2"]["matched"] == 0 and stored["3"]["matched"] == 0
    assert "location" in " ".join(stored["3"]["score_breakdown"]["_rejects"])


def test_second_poll_notifies_only_the_newly_posted_job(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    _, db, eng = build(tmp_path, telegram, None)
    eng.run_once()
    set_board(telegram, [gh_job(1), gh_job(5, title="Python Developer")])
    eng.run_once()
    texts = sent_texts(telegram)
    assert len(texts) == 2 and "Python Developer" in texts[1]


def test_restart_does_not_renotify_and_keeps_data(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    cfg, db, eng = build(tmp_path, telegram, None)
    eng.run_once()
    # "restart": brand-new objects on the same data dir
    _, db2, eng2 = build(tmp_path, telegram, None)
    eng2.run_once()
    assert len(sent_texts(telegram)) == 1
    assert db2.get_source_state("greenhouse:acme")["last_success"]  # last monitoring time persisted
    assert db2.query_jobs(limit=5)[1] == 1


def test_description_and_apply_url_updates_are_detected(tmp_path, telegram):
    set_board(telegram, [gh_job(1, content="3-5 years of experience in Python")])
    _, db, eng = build(tmp_path, telegram, None)
    eng.run_once()
    set_board(telegram, [gh_job(1, content="3-5 years of experience in Python and Go", url="https://boards.example/acme/jobs/1?new")])
    out = eng.run_once()
    assert out[0]["updated"] == 1
    kinds = [e["kind"] for e in db.recent_events(20)]
    assert "description_updated" in kinds and "apply_url_changed" in kinds
    row = db.query_jobs(limit=1)[0][0]
    assert row["apply_url"].endswith("?new") and row["updated_at"]
    assert len(sent_texts(telegram)) == 1  # an update alone is not a new-job alert


def test_removed_jobs_expire_after_misses_and_reappear(tmp_path, telegram):
    set_board(telegram, [gh_job(1), gh_job(2)])
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"expire_after_misses": 2}})
    eng.run_once()
    set_board(telegram, [gh_job(2)])
    eng.run_once()
    assert db.get_job("greenhouse:acme|1")["status"] == "active"  # one miss: could be a blip
    eng.run_once()
    assert db.get_job("greenhouse:acme|1")["status"] == "expired" and db.get_job("greenhouse:acme|2")["status"] == "active"
    set_board(telegram, [gh_job(1), gh_job(2)])
    eng.run_once()
    assert db.get_job("greenhouse:acme|1")["status"] == "active"
    assert len(sent_texts(telegram)) == 2  # the reappearing job is not announced again


def test_empty_response_does_not_expire_everything(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"expire_after_misses": 1}})
    eng.run_once()
    set_board(telegram, [])
    eng.run_once()
    assert db.get_job("greenhouse:acme|1")["status"] == "active"
    assert "0 jobs" in db.get_source_state("greenhouse:acme")["last_warning"]


def test_failing_source_does_not_stop_others_and_state_is_recorded(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    telegram.on("GET", "/v0/postings/broken", 500, "boom")
    srcs = [{"type": "greenhouse", "board": "acme", "company": "Acme", "api_base": telegram.base, "interval": 1},
            {"type": "lever", "site": "broken", "api_base": telegram.base, "interval": 1}]
    _, db, eng = build(tmp_path, telegram, None, sources=srcs)
    out = {o["source"]: o for o in eng.run_once()}
    assert out["greenhouse:acme"]["ok"] and not out["lever:broken"]["ok"]
    st = db.get_source_state("lever:broken")
    assert st["consecutive_failures"] == 1 and "500" in st["last_error"] or "Giving up" in st["last_error"]
    assert eng._next_run["lever:broken"] > time.time()  # backed off
    assert len(sent_texts(telegram)) == 1


def test_backoff_grows_and_failure_alert_sent_once_then_recovery(tmp_path, telegram):
    telegram.on("GET", "/v1/boards/acme/jobs", 500, "boom")
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"fail_alert_threshold": 3, "max_backoff": 10_000}})
    delays = []
    for _ in range(4):
        eng.run_source("greenhouse:acme")
        delays.append(eng._next_run["greenhouse:acme"] - time.time())
    assert delays[3] > delays[0]
    alerts = [t for t in sent_texts(telegram) if "Source failing" in t]
    assert len(alerts) == 1  # sent at the 3rd failure, not again at the 4th
    set_board(telegram, [gh_job(1)])
    eng.run_source("greenhouse:acme")
    assert any("Source recovered" in t for t in sent_texts(telegram))
    assert db.get_source_state("greenhouse:acme")["consecutive_failures"] == 0


def test_404_source_disabled_after_threshold(tmp_path, telegram):
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"dead_source_after_404": 2}})
    # no route registered for the board → 404
    eng.run_source("greenhouse:acme")
    assert not db.get_source_state("greenhouse:acme").get("disabled_reason")
    eng.run_source("greenhouse:acme")
    st = db.get_source_state("greenhouse:acme")
    assert "404" in st["disabled_reason"] and "greenhouse:acme" not in eng._next_run
    assert eng.run_once() == []  # disabled sources are skipped


def test_unexpected_payload_is_recorded_not_raised(tmp_path, telegram):
    telegram.on("GET", "/v1/boards/acme/jobs", 200, {"jobs": [{"title": "no id field"}]})
    _, db, eng = build(tmp_path, telegram, None)
    out = eng.run_source("greenhouse:acme")
    assert not out["ok"] and "KeyError" in out["error"]
    assert db.get_source_state("greenhouse:acme")["last_error"]


def test_first_run_summary_sends_one_digest_not_a_flood(tmp_path, telegram):
    set_board(telegram, [gh_job(i) for i in range(1, 9)])
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"first_run": "summary"}})
    eng.run_once()
    texts = sent_texts(telegram)
    assert len(texts) == 1 and "Initial scan: 8 matching jobs" in texts[0]
    set_board(telegram, [gh_job(i) for i in range(1, 9)] + [gh_job(99, title="Python Developer")])
    eng.run_once()
    assert len(sent_texts(telegram)) == 2  # post-baseline job is announced individually


def test_first_run_silent(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"first_run": "silent"}})
    eng.run_once()
    assert sent_texts(telegram) == []
    assert db.pending_notifications(10, 5) == []


def test_burst_is_capped_and_rest_goes_in_digest(tmp_path, telegram):
    set_board(telegram, [gh_job(i, title=f"Backend Engineer {i}") for i in range(1, 16)])
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"max_individual_per_flush": 4}})
    eng.run_once()
    texts = sent_texts(telegram)
    assert len(texts) == 5 and "11 more matching jobs" in texts[-1]
    assert db.pending_notifications(100, 5) == []


def test_same_job_on_two_sources_notified_once(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    telegram.on("GET", "/v0/postings/acme", 200, [{"id": "L1", "text": "Backend Engineer", "hostedUrl": "https://jobs.lever.co/acme/L1",
                                                  "categories": {"location": "Bengaluru"}, "descriptionPlain": "3-5 years of experience in Python", "createdAt": 1_762_000_000_000}])
    srcs = [{"type": "greenhouse", "board": "acme", "company": "Acme", "api_base": telegram.base, "interval": 1},
            {"type": "lever", "site": "acme", "company": "Acme", "api_base": telegram.base, "interval": 1}]
    _, db, eng = build(tmp_path, telegram, None, sources=srcs)
    eng.run_once()
    assert len(sent_texts(telegram)) == 1


def test_failed_alert_is_retried_after_backoff_not_lost(tmp_path, server):
    set_board(server, [gh_job(1)])
    n = {"c": 0}

    def tg_flaky(rec):
        n["c"] += 1
        return (503, "down", {}) if n["c"] <= 3 else (200, {"ok": True}, {})  # the notifier makes 3 attempts; all fail

    server.on_fn("POST", SEND, tg_flaky)
    _, db, eng = build(tmp_path, server, None)
    eng.run_once()
    uid = "greenhouse:acme|1"
    assert db.get_job(uid)["notified_at"] is None and db.get_job(uid)["notify_attempts"] == 1  # kept for retry
    assert eng._retry_after[uid] > time.time() + 20  # time-based backoff, not "next 5s flush"
    calls = n["c"]
    for _ in range(10):  # a long outage of rapid flushes must not burn through the attempt budget
        eng.flush_notifications()
    assert n["c"] == calls and db.get_job(uid)["notify_attempts"] == 1
    eng._retry_after[uid] = 0  # backoff elapsed
    eng.flush_notifications()
    assert db.get_job(uid)["notified_at"] is not None and uid not in eng._retry_after


def test_giving_up_after_max_attempts_sends_system_alert(tmp_path, server):
    set_board(server, [gh_job(1)])
    server.on("POST", SEND, 400, {"ok": False, "error_code": 400, "description": "chat not found"})
    _, db, eng = build(tmp_path, server, None, {"engine": {"max_notify_attempts": 2}})
    eng.run_once()
    eng._retry_after.clear()
    eng.flush_notifications()
    assert db.get_job("greenhouse:acme|1")["notify_attempts"] == 2
    eng._retry_after.clear()
    eng.flush_notifications()  # exhausted: not attempted again
    assert db.get_job("greenhouse:acme|1")["notify_attempts"] == 2
    assert any("could not be delivered" in t for t in sent_texts(server))


def test_no_usable_channel_warns_once_and_keeps_jobs_pending(tmp_path, server, caplog):
    set_board(server, [gh_job(1)])
    _, db, eng = build(tmp_path, server, None, {"notifications": {"telegram": {"enabled": False}}})
    with caplog.at_level("WARNING"):
        eng.run_once()
        for _ in range(5):
            eng.flush_notifications()
    assert len([r for r in caplog.records if "No notification channel" in r.message]) == 1
    assert [j["uid"] for j in db.pending_notifications(10, 12)] == ["greenhouse:acme|1"]  # announced once a channel is configured


def test_rescore_after_preference_change(tmp_path, telegram):
    set_board(telegram, [gh_job(1, loc="Pune")])
    cfg, db, eng = build(tmp_path, telegram, None)
    eng.run_once()
    assert db.query_jobs(limit=5)[1] == 0
    cfg2, _, eng2 = build(tmp_path, telegram, None, {"preferences": {"locations": ["pune"]}})
    assert eng2.pipeline.rescore_all() == 1
    assert db.query_jobs(limit=5)[1] == 1


def test_daily_digest_sent_once_per_day(tmp_path, telegram):
    set_board(telegram, [gh_job(1)])
    _, db, eng = build(tmp_path, telegram, None, {"engine": {"digest_time": "00:00"}})
    eng.run_once()
    assert eng.maybe_daily_digest() is True and eng.maybe_daily_digest() is False
    assert any("Daily job summary" in t for t in sent_texts(telegram))


def test_run_forever_polls_and_stops_cleanly(tmp_path, telegram):
    import threading

    set_board(telegram, [gh_job(1)])
    _, db, eng = build(tmp_path, telegram, None)
    t = threading.Thread(target=eng.run_forever)
    t.start()
    deadline = time.time() + 15
    while time.time() < deadline and not sent_texts(telegram):
        time.sleep(0.2)
    set_board(telegram, [gh_job(1), gh_job(7, title="Python Developer")])
    db.add_command("run_now", "greenhouse:acme")  # dashboard-style command
    while time.time() < deadline and len(sent_texts(telegram)) < 2:
        time.sleep(0.2)
    eng.stop_event.set()
    t.join(timeout=15)
    assert not t.is_alive()
    assert len(sent_texts(telegram)) == 2
