from datetime import timedelta

import pytest

from jobwatch.config import ConfigError, Preferences, DEFAULTS, deep_merge
from jobwatch.extract import (
    detect_work_mode, enrich, find_skills, infer_seniority, normalise_employment_type, parse_experience, parse_salary, split_skills,
)
from jobwatch.matching import Matcher
from jobwatch.models import Job
from jobwatch.util import parse_dt, primary_city, redact, utcnow


def prefs(**over):
    d = deep_merge(DEFAULTS["preferences"], over)
    return Preferences.from_dict(d)


def job(title="Senior Python Developer", loc="Bengaluru, India", desc="", **kw):
    j = Job(source="s", platform="p", external_id=kw.pop("eid", "1"), title=title, company=kw.pop("company", "Acme"), location=loc, description=desc, **kw)
    return enrich(j)


# ---------------------------------------------------------------- extraction
@pytest.mark.parametrize(
    "text,expected",
    [
        ("3-5 years of experience in Python", (3.0, 5.0)),
        ("Minimum 7 years of experience", (7.0, None)),
        ("5+ years experience building APIs", (5.0, None)),
        ("2 to 4 yrs exp", (2.0, 4.0)),
        ("Freshers welcome to apply", (0.0, 1.0)),
        ("We are a company with 10+ years in business", None),
        ("", None),
    ],
)
def test_parse_experience(text, expected):
    assert parse_experience(text) == expected


def test_parse_experience_lenient_hint():
    assert parse_experience("2-5 Yrs", strict=False) == (2.0, 5.0)


def test_seniority_inference():
    assert infer_seniority("Senior Staff Engineer") == (4.0, None)  # 'senior' matches first in table order
    assert infer_seniority("Software Engineering Intern") == (0.0, 0.0)
    assert infer_seniority("Software Engineer") is None


def test_skills_split_required_preferred():
    desc = "Requirements:\n- Python and Django\n- AWS\nNice to have:\n- Kafka\n- Terraform is a plus"
    req, pref = split_skills(desc)
    assert {"python", "django", "aws"} <= set(req)
    assert {"kafka", "terraform"} <= set(pref)


def test_skills_ambiguous_words_not_matched():
    assert "rust" not in find_skills("this will rust over time")
    assert "go" not in find_skills("we go the extra mile")
    assert "go" in find_skills("Python, Go, Java")
    assert "c++" in find_skills("Strong C++ skills")
    assert "java" not in find_skills("JavaScript only")  # word-boundary check
    assert "javascript" in find_skills("JavaScript only")


def test_salary_parsing():
    assert parse_salary("₹18-28 LPA")[1:] == (18.0, 28.0)
    assert parse_salary("INR 1,200,000 - 1,800,000 per year")[1:] == (12.0, 18.0)
    assert parse_salary("$120k - $150k") [1:] == (None, None) and parse_salary("$120k - $150k")[0]
    assert parse_salary("competitive") == ("", None, None)


def test_work_mode_and_type():
    assert detect_work_mode("This is a hybrid role") == "hybrid"
    assert detect_work_mode("fully remote") == "remote"
    assert detect_work_mode("remote work is not available") != "remote"
    assert normalise_employment_type("FullTime") == "Full-time"
    assert normalise_employment_type("INTERN") == "Internship"


def test_enrich_end_to_end():
    j = job(desc="About us: 12 years in business.\nRequirements:\n- 3-5 years of experience in Python, AWS\nNice to have:\n- Kafka\nSalary 18-28 LPA. Hybrid.")
    assert (j.exp_min, j.exp_max) == (3.0, 5.0) and not j.exp_inferred
    assert j.work_mode == "hybrid" and j.salary_max_lpa == 28.0
    assert "python" in j.skills_required and "kafka" in j.skills_preferred


def test_parse_dt_formats():
    assert parse_dt("2026-11-18T10:00:00Z").year == 2026
    assert parse_dt(1_700_000_000_000).year == 2023  # ms epoch
    assert parse_dt("Wed, 18 Nov 2026 10:00:00 +0530").hour == 10
    assert parse_dt("garbage") is None and parse_dt(None) is None


def test_primary_city_aliases():
    assert primary_city("Bangalore, Karnataka") == primary_city("Bengaluru") == "bengaluru"


def test_redact_masks_secrets(monkeypatch):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ012345")
    assert "ABCDEFGH" not in redact("POST https://api.telegram.org/bot123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ012345/sendMessage")
    assert "hunter2" not in redact("password=hunter2&x=1")
    assert "abcdefghijk" not in redact("Authorization: Bearer abcdefghijklmnop")


# ---------------------------------------------------------------- matching
def test_location_filter():
    m = Matcher(prefs())
    assert m.evaluate(job(loc="Bangalore, Karnataka")).passed
    assert not m.evaluate(job(loc="Hyderabad, India")).passed
    assert not m.evaluate(job(loc="")).passed  # unknown location rejected by default
    assert Matcher(prefs(allow_unknown_location=True)).evaluate(job(loc="")).passed


def test_remote_india_allowed_only_when_enabled():
    j = job(loc="Remote - India", desc="fully remote role")
    assert Matcher(prefs()).evaluate(j).passed
    assert not Matcher(prefs(include_remote_india=False)).evaluate(j).passed
    assert not Matcher(prefs()).evaluate(job(loc="Remote - USA", desc="fully remote")).passed


def test_role_include_exclude():
    m = Matcher(prefs())
    assert m.evaluate(job(title="Backend Engineer")).passed
    assert not m.evaluate(job(title="Sales Executive")).passed
    assert not m.evaluate(job(title="Office Manager")).passed  # no wanted-role keyword


def test_experience_window():
    m = Matcher(prefs(experience={"my_years": 3}))  # window 1..4
    assert m.evaluate(job(title="Software Engineer", desc="2-4 years of experience")).passed
    assert not m.evaluate(job(title="Software Engineer", desc="8+ years of experience")).passed
    assert Matcher(prefs(experience={"min": 0, "max": 2})).evaluate(job(title="Software Engineer")).passed  # unknown allowed
    assert not Matcher(prefs(experience={"min": 0, "max": 2, "unknown": "reject"})).evaluate(job(title="Software Engineer")).passed


def test_keywords_and_excludes():
    m = Matcher(prefs(keywords={"include": ["kubernetes"], "exclude": ["unpaid"]}))
    assert m.evaluate(job(title="Software Engineer", desc="we use Kubernetes")).passed
    assert not m.evaluate(job(title="Software Engineer", desc="we use docker")).passed
    assert not m.evaluate(job(title="Software Engineer", desc="kubernetes, unpaid internship")).passed


def test_work_mode_salary_age_company_filters():
    assert not Matcher(prefs(work_modes=["remote"])).evaluate(job(title="Software Engineer", desc="onsite only")).passed
    assert not Matcher(prefs(salary_min_lpa=30)).evaluate(job(title="Software Engineer", desc="₹10-20 LPA")).passed
    assert Matcher(prefs(salary_min_lpa=30)).evaluate(job(title="Software Engineer")).passed  # unknown salary kept
    old = job(title="Software Engineer", posted_at=utcnow() - timedelta(days=100))
    assert not Matcher(prefs(max_age_days=30)).evaluate(old).passed
    assert not Matcher(prefs(exclude_companies=["acme"])).evaluate(job(title="Software Engineer")).passed


def test_scoring_orders_relevance_and_priority():
    p = prefs(roles={"priority": ["python developer"]}, skills={"core": ["python", "aws", "docker"], "nice": []},
              experience={"my_years": 4}, priority_companies=["acme"])
    m = Matcher(p)
    strong = m.evaluate(job(title="Python Developer", desc="Requirements:\n- 3-5 years of experience\n- Python, AWS, Docker", posted_at=utcnow()))
    weak = m.evaluate(job(title="Software Tester", desc="Requirements:\n- 3-5 years of experience\n- Selenium", company="Other"))
    assert strong.score > weak.score + 20
    assert strong.priority and strong.matched
    assert all(0 <= v <= 1 for v in strong.breakdown.values())


def test_invalid_preferences_rejected():
    with pytest.raises(ConfigError):
        prefs(work_modes=["moon"])
    with pytest.raises(ConfigError):
        prefs(experience={"min": 5, "max": 2})
    with pytest.raises(ConfigError):
        prefs(experience={"unknown": "maybe"})
