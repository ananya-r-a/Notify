"""Shared fixtures: local fake HTTP servers and a minimal SMTP server (real sockets, no mocks of our code)."""

from __future__ import annotations

import json
import socketserver
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from jobwatch.config import build_config  # noqa: E402
from jobwatch.db import Database  # noqa: E402
from jobwatch.httpclient import HttpClient  # noqa: E402


class FakeServer:
    """Tiny programmable HTTP server. ``routes[(method, path)]`` = callable(handler, body) → (status, body, headers)."""

    def __init__(self) -> None:
        self.routes: dict[tuple[str, str], Callable[..., tuple[int, Any, dict[str, str]]]] = {}
        self.requests: list[dict[str, Any]] = []
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def _handle(self, method: str) -> None:
                length = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(length) if length else b""
                path = self.path.split("?")[0]
                rec = {"method": method, "path": path, "query": self.path.partition("?")[2], "headers": dict(self.headers), "body": raw}
                outer.requests.append(rec)
                fn = outer.routes.get((method, path))
                if fn is None:
                    status, body, hdrs = 404, {"error": "no route"}, {}
                else:
                    status, body, hdrs = fn(rec)
                if isinstance(body, (dict, list)):
                    payload, ctype = json.dumps(body).encode(), "application/json"
                elif isinstance(body, bytes):
                    payload, ctype = body, "application/octet-stream"
                else:
                    payload, ctype = str(body).encode(), "text/html; charset=utf-8"
                self.send_response(status)
                self.send_header("Content-Type", hdrs.pop("Content-Type", ctype))
                self.send_header("Content-Length", str(len(payload)))
                for k, v in hdrs.items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self) -> None:  # noqa: N802
                self._handle("GET")

            def do_POST(self) -> None:  # noqa: N802
                self._handle("POST")

            def log_message(self, *a: Any) -> None:
                pass

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self.httpd.server_address[1]
        self.base = f"http://127.0.0.1:{self.port}"
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def on(self, method: str, path: str, status: int = 200, body: Any = "", headers: dict[str, str] | None = None) -> None:
        self.routes[(method, path)] = lambda rec, s=status, b=body, h=headers: (s, b, dict(h or {}))

    def on_fn(self, method: str, path: str, fn: Callable[..., tuple[int, Any, dict[str, str]]]) -> None:
        self.routes[(method, path)] = fn

    def hits(self, path: str, method: str | None = None) -> list[dict[str, Any]]:
        return [r for r in self.requests if r["path"] == path and (method is None or r["method"] == method)]

    def close(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()


@pytest.fixture()
def server():
    s = FakeServer()
    yield s
    s.close()


class FakeSMTP:
    """Minimal SMTP server (no auth/TLS) that stores received messages."""

    def __init__(self, require_login: bool = False):
        self.messages: list[bytes] = []
        self.logins: list[str] = []
        outer = self

        class H(socketserver.StreamRequestHandler):
            def handle(self) -> None:
                w = lambda s: self.wfile.write((s + "\r\n").encode())  # noqa: E731
                w("220 fake ESMTP")
                data_mode, buf = False, []
                while True:
                    line = self.rfile.readline()
                    if not line:
                        return
                    text = line.decode(errors="replace").rstrip("\r\n")
                    if data_mode:
                        if text == ".":
                            outer.messages.append("\r\n".join(buf).encode())
                            data_mode, buf = False, []
                            w("250 OK queued")
                        else:
                            buf.append(text[1:] if text.startswith("..") else text)
                        continue
                    cmd = text.upper()
                    if cmd.startswith("EHLO"):
                        self.wfile.write(b"250-fake\r\n250 AUTH PLAIN LOGIN\r\n")
                    elif cmd.startswith("HELO"):
                        w("250 fake")
                    elif cmd.startswith("AUTH"):
                        outer.logins.append(text)
                        w("235 ok")
                    elif cmd.startswith(("MAIL", "RCPT", "RSET", "NOOP")):
                        w("250 OK")
                    elif cmd.startswith("DATA"):
                        w("354 go")
                        data_mode = True
                    elif cmd.startswith("QUIT"):
                        w("221 bye")
                        return
                    else:
                        w("500 what")

        class Srv(socketserver.ThreadingTCPServer):
            allow_reuse_address = True
            daemon_threads = True

        self.srv = Srv(("127.0.0.1", 0), H)
        self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self) -> None:
        self.srv.shutdown()
        self.srv.server_close()


@pytest.fixture()
def smtp():
    s = FakeSMTP()
    yield s
    s.close()


@pytest.fixture()
def db(tmp_path):
    return Database(tmp_path / "t.db")


@pytest.fixture()
def http(db):
    """HTTP client with no waiting between retries or hosts."""
    sleeps: list[float] = []
    client = HttpClient(timeout=5, max_retries=3, backoff_base=1, min_host_interval=0, respect_robots=False, db=db, sleep=sleeps.append)
    client.sleeps = sleeps  # type: ignore[attr-defined]
    return client


def make_config(tmp_path: Path, overrides: dict[str, Any] | None = None):
    """Config pointing at ``tmp_path`` with fast, deterministic engine settings."""
    base: dict[str, Any] = {
        "data_dir": str(tmp_path / "data"),
        "engine": {"workers": 2, "min_interval": 1, "jitter": 0, "first_run": "notify"},
        "http": {"min_host_interval": 0, "max_retries": 1, "backoff_base": 0.01, "respect_robots": False},
        "notifications": {"routing": {"job": ["telegram"], "priority": ["telegram"], "digest": ["telegram"], "system": ["telegram"]}},
    }
    from jobwatch.config import deep_merge

    return build_config(deep_merge(base, overrides or {}), tmp_path)
