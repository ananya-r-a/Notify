"""Adapters are exercised over real HTTP against payloads shaped like each platform's documented API."""

import email.message
import json

import pytest

from jobwatch.models import SourceError
from jobwatch.sources import SOURCE_TYPES, build_sources
from jobwatch.sources.email_alerts import _classify, parse_alert_message
from jobwatch.sources.jsonld import extract_jobpostings
from jobwatch.sources.workday import parse_posted_on
from jobwatch.config import ConfigError


def make(kind, cfg, http, server):
    cfg = {"type": kind, "api_base": server.base, **cfg}
    cls = SOURCE_TYPES[kind]
    return cls(cls.default_name(cfg), cfg, http)


def test_greenhouse(server, http):
    server.on("GET", "/v1/boards/acme/jobs", 200, {"jobs": [
        {"id": 101, "internal_job_id": 1, "title": "Backend Engineer", "updated_at": "2026-11-01T10:00:00-05:00",
         "location": {"name": "Bengaluru"}, "absolute_url": "https://boards.greenhouse.io/acme/jobs/101", "requisition_id": "R1",
         "content": "&lt;p&gt;Requirements&lt;/p&gt;&lt;ul&gt;&lt;li&gt;3-5 years of experience in Python&lt;/li&gt;&lt;/ul&gt;",
         "departments": [{"id": 1, "name": "Engineering"}], "offices": [{"id": 2, "name": "BLR", "location": "Bengaluru, India"}]}]})
    jobs = make("greenhouse", {"board": "acme", "company": "Acme"}, http, server).fetch()
    assert len(jobs) == 1
    j = jobs[0]
    assert (j.external_id, j.title, j.department) == ("101", "Backend Engineer", "Engineering")
    assert "Bengaluru" in j.location and "<p>" not in j.description and "3-5 years" in j.description
    assert j.url.endswith("/101") and "content=true" in server.requests[0]["query"]


def test_lever_paginates_and_maps_fields(server, http):
    def page(rec):
        skip = int(dict(p.split("=") for p in rec["query"].split("&"))["skip"])
        items = [{"id": f"id{skip + i}", "text": f"Engineer {skip + i}", "hostedUrl": f"https://jobs.lever.co/x/{skip + i}",
                  "applyUrl": f"https://jobs.lever.co/x/{skip + i}/apply", "createdAt": 1_762_000_000_000,
                  "categories": {"location": "Bengaluru", "commitment": "Full-time", "team": "Core", "department": "Eng"},
                  "workplaceType": "hybrid", "descriptionPlain": "Build things", "lists": [{"text": "Requirements", "content": "<li>Go</li>"}]}
                 for i in range(100 if skip == 0 else 5)]
        return 200, items, {}

    server.on_fn("GET", "/v0/postings/x", page)
    jobs = make("lever", {"site": "x", "company": "X"}, http, server).fetch()
    assert len(jobs) == 105 and len({j.external_id for j in jobs}) == 105
    j = jobs[0]
    assert j.work_mode == "hybrid" and j.employment_type == "Full-time" and j.posted_at.year == 2025
    assert j.apply_url.endswith("/apply") and "Requirements" in j.description


def test_ashby_uses_url_id_and_skips_unlisted(server, http):
    server.on("GET", "/posting-api/job-board/co", 200, {"apiVersion": "1", "jobs": [
        {"title": "SRE", "location": "Bengaluru", "isListed": True, "workplaceType": "Hybrid", "employmentType": "FullTime",
         "descriptionHtml": "<p>Run <b>prod</b></p>", "publishedAt": "2026-11-10T08:00:00.000+00:00",
         "jobUrl": "https://jobs.ashbyhq.com/co/abc-123", "applyUrl": "https://jobs.ashbyhq.com/co/abc-123/application",
         "secondaryLocations": [{"location": "Remote India"}]},
        {"title": "Hidden", "location": "Bengaluru", "isListed": False, "jobUrl": "https://jobs.ashbyhq.com/co/zzz"}]})
    jobs = make("ashby", {"board": "co"}, http, server).fetch()
    assert [j.title for j in jobs] == ["SRE"]
    assert jobs[0].external_id == "abc-123" and "Remote India" in jobs[0].location and jobs[0].work_mode == "Hybrid"


def test_smartrecruiters_details_only_for_new(server, http):
    listing = {"totalFound": 2, "limit": 100, "offset": 0, "content": [
        {"id": "1", "name": "Embedded Engineer", "releasedDate": "2026-11-12T00:00:00.000Z", "company": {"identifier": "Bosch", "name": "Bosch"},
         "location": {"city": "Bengaluru", "region": "KA", "country": "in", "remote": False, "hybrid": True},
         "typeOfEmployment": {"label": "Full-time"}, "department": {"label": "R&D"}, "experienceLevel": {"name": "Mid-Senior Level"}},
        {"id": "2", "name": "Test Engineer", "releasedDate": "2026-11-13T00:00:00.000Z", "location": {"city": "Pune", "country": "in"}}]}
    server.on("GET", "/v1/companies/Bosch/postings", 200, listing)
    server.on("GET", "/v1/companies/Bosch/postings/1", 200, {"postingUrl": "https://jobs.smartrecruiters.com/Bosch/1-x", "applyUrl": "https://jobs.smartrecruiters.com/Bosch/1-x?apply",
        "jobAd": {"sections": {"jobDescription": {"title": "Job Description", "text": "<p>3-5 years of experience in C++</p>"}}}})
    server.on("GET", "/v1/companies/Bosch/postings/2", 200, {"jobAd": {"sections": {}}})
    src = make("smartrecruiters", {"company_id": "Bosch"}, http, server)
    jobs = src.fetch()
    assert jobs[0].work_mode == "hybrid" and jobs[0].location == "Bengaluru, KA, India"
    assert "C++" in jobs[0].description and jobs[0].apply_url.endswith("?apply")
    src.known_ids = {"1", "2"}
    server.requests.clear()
    again = src.fetch()
    assert not server.hits("/v1/companies/Bosch/postings/1") and all(j.extra["partial"] for j in again)


def test_workable(server, http):
    server.on("GET", "/api/v1/widget/accounts/wk", 200, {"name": "Wk Inc", "jobs": [
        {"title": "Dev", "shortcode": "ABC1", "url": "https://apply.workable.com/wk/j/ABC1/", "published_on": "2026-11-01",
         "locations": [{"city": "Bengaluru", "region": "Karnataka", "country_name": "India"}], "telecommuting": False,
         "description": "<p>Do work</p>", "employment_type": "Full-time"}]})
    j = make("workable", {"account": "wk"}, http, server).fetch()[0]
    assert j.external_id == "ABC1" and j.company == "Wk Inc" and j.location == "Bengaluru, Karnataka, India"


def test_workday_paginates_and_fetches_details(server, http):
    def jobs(rec):
        body = json.loads(rec["body"])
        batch = [{"title": f"Eng {body['offset'] + i}", "externalPath": f"/job/Bengaluru/Eng_{body['offset'] + i}", "locationsText": "Bengaluru",
                  "postedOn": "Posted 3 Days Ago", "bulletFields": [f"R{body['offset'] + i}"]} for i in range(min(20, 25 - body["offset"]))]
        return 200, {"total": 25, "jobPostings": batch}, {}

    server.on_fn("POST", "/wday/cxs/acme/ext/jobs", jobs)
    for i in range(25):
        server.on("GET", f"/wday/cxs/acme/ext/job/Bengaluru/Eng_{i}", 200, {"jobPostingInfo": {"jobDescription": "<p>5+ years of experience</p>", "location": "Bengaluru", "timeType": "Full time", "startDate": "2026-11-10"}})
    src = make("workday", {"host": "unused", "tenant": "acme", "site": "ext", "scheme": "http"}, http, server)
    src.cfg["host"] = server.base.replace("http://", "")
    out = src.fetch()
    assert len(out) == 25 and out[0].external_id == "R0" and "5+ years" in out[0].description and out[0].employment_type == "Full time"
    assert parse_posted_on("Posted Today") is not None and parse_posted_on("???") is None


JSONLD = """<html><head><script type="application/ld+json">
{"@context":"https://schema.org","@graph":[{"@type":"JobPosting","title":"Firmware Engineer","identifier":{"@type":"PropertyValue","value":"FW-9"},
"description":"&lt;p&gt;3-6 years of experience. Hybrid.&lt;/p&gt;","datePosted":"2026-11-15","validThrough":"2026-12-31",
"employmentType":["FULL_TIME"],"hiringOrganization":{"@type":"Organization","name":"ChipCo"},
"jobLocation":{"@type":"Place","address":{"@type":"PostalAddress","addressLocality":"Bengaluru","addressRegion":"KA","addressCountry":"IN"}},
"baseSalary":{"@type":"MonetaryAmount","currency":"INR","value":{"@type":"QuantitativeValue","minValue":2000000,"maxValue":3000000,"unitText":"YEAR"}}}]}
</script><script type="application/ld+json">{ broken json </script></head><body></body></html>"""


def test_jsonld_extraction_and_adapter(server, http):
    assert len(extract_jobpostings(JSONLD)) == 1  # broken second block skipped, not fatal
    server.on("GET", "/careers", 200, JSONLD)
    src = make("jsonld", {"url": server.base + "/careers"}, http, server)
    j = src.fetch()[0]
    assert (j.external_id, j.company, j.location) == ("FW-9", "ChipCo", "Bengaluru, KA, India")
    assert j.deadline.year == 2026 and "2,000,000" in j.salary_text and "<p>" not in j.description


def test_jsonld_follow_links(server, http):
    server.on("GET", "/list", 200, '<a href="/jobs/1">One</a><a href="/jobs/2">Two</a><a href="/about">About</a>')
    page = JSONLD.replace("FW-9", "X")
    server.on("GET", "/jobs/1", 200, page)
    server.on("GET", "/jobs/2", 200, page.replace("Firmware Engineer", "Driver Engineer"))
    src = make("jsonld", {"url": server.base + "/list", "follow_links": True, "link_selector": "a[href*='/jobs/']"}, http, server)
    jobs = src.fetch()
    assert sorted(j.title for j in jobs) == ["Driver Engineer", "Firmware Engineer"]
    assert all(j.external_id.startswith(server.base) for j in jobs)


def test_htmllist(server, http):
    server.on("GET", "/careers", 200, '<ul class="jobs"><li><a href="/j/1">Embedded Engineer</a><span class="loc">Bengaluru</span></li>'
                                      '<li><a href="/j/2">Accountant</a><span class="loc">Delhi</span></li></ul>')
    src = make("htmllist", {"url": server.base + "/careers", "item_selector": "ul.jobs li", "location_selector": ".loc", "company": "Org"}, http, server)
    jobs = src.fetch()
    assert [(j.title, j.location) for j in jobs] == [("Embedded Engineer", "Bengaluru"), ("Accountant", "Delhi")]
    assert jobs[0].external_id == server.base + "/j/1"


RSS = """<?xml version="1.0"?><rss version="2.0"><channel><title>Feed Co</title>
<item><title>Backend Engineer at Acme (Bengaluru)</title><link>https://x.test/1</link><guid>g1</guid><pubDate>Wed, 18 Nov 2026 04:00:00 GMT</pubDate><description>&lt;p&gt;Python&lt;/p&gt;</description></item>
<item><title>Plain title</title><link>https://x.test/2</link></item></channel></rss>"""


def test_rss_with_title_regex(server, http):
    server.on("GET", "/feed.xml", 200, RSS, {"Content-Type": "application/rss+xml"})
    src = make("rss", {"url": server.base + "/feed.xml", "title_regex": r"^(?P<title>.+?) at (?P<company>.+?) \((?P<location>.+?)\)$"}, http, server)
    jobs = src.fetch()
    assert (jobs[0].title, jobs[0].company, jobs[0].location) == ("Backend Engineer", "Acme", "Bengaluru")
    assert jobs[1].company == "Feed Co" and src.complete_listing is False


def test_rss_rejects_non_feed(server, http):
    server.on("GET", "/feed.xml", 200, "<html><body>nope</body></html>")
    with pytest.raises(SourceError):
        make("rss", {"url": server.base + "/feed.xml"}, http, server).fetch()


def test_hn_hiring(server, http):
    server.on("GET", "/api/v1/search_by_date", 200, {"hits": [{"objectID": "900", "title": "Ask HN: Who is hiring? (November 2026)"}]})

    def comments(rec):
        if "story_900" not in rec["query"] and "story_900" not in rec["query"].replace("%2C", ","):
            return 200, {"hits": [{"objectID": "900", "title": "Ask HN: Who is hiring? (November 2026)"}]}, {}
        return 200, {"nbPages": 1, "hits": [
            {"objectID": "1", "parent_id": 900, "created_at": "2026-11-02T00:00:00Z", "author": "a",
             "comment_text": "Acme | Backend Engineer | Bengaluru, India | Hybrid<p>We use Python. <a href=\"https://acme.test/jobs\">apply</a>"},
            {"objectID": "2", "parent_id": 900, "comment_text": "Other | Designer | NYC", "created_at": "2026-11-02T00:00:00Z"},
            {"objectID": "3", "parent_id": 1, "comment_text": "reply in Bengaluru", "created_at": "2026-11-02T00:00:00Z"}]}, {}

    server.on_fn("GET", "/api/v1/search_by_date", comments)
    jobs = make("hn_hiring", {}, http, server).fetch()
    assert len(jobs) == 1
    assert (jobs[0].company, jobs[0].title, jobs[0].location) == ("Acme", "Backend Engineer", "Bengaluru, India")
    assert jobs[0].apply_url == "https://acme.test/jobs"


# ---------------------------------------------------------------- portal alert e-mails
def _mail(html: str, subject="Jobs for you", sender="jobs-noreply@linkedin.com"):
    m = email.message.EmailMessage()
    m["From"], m["Subject"], m["Date"] = sender, subject, "Wed, 18 Nov 2026 04:30:00 +0000"
    m.set_content("plain fallback")
    m.add_alternative(html, subtype="html")
    return m


def test_classify_portal_links():
    assert _classify("https://www.linkedin.com/comm/jobs/view/3912345678/?trackingId=x")[:2] == ("linkedin", "3912345678")
    assert _classify("https://in.indeed.com/viewjob?jk=abcdef0123456789&from=alert")[:2] == ("indeed", "abcdef0123456789")
    assert _classify("https://www.naukri.com/job-listings-python-developer-acme-bengaluru-3-to-5-years-101120250123?src=x")[1] == "101120250123"
    assert _classify("https://example.com/other") is None
    wrapped = _classify("https://click.example.com/r?url=https%3A%2F%2Fwww.linkedin.com%2Fjobs%2Fview%2F3911111111")
    assert wrapped and wrapped[1] == "3911111111"


def test_parse_linkedin_style_alert():
    html = """<table><tr><td><a href="https://www.linkedin.com/comm/jobs/view/3900000001?x=1">Senior Python Developer</a>
    <p>Acme Corp · Bengaluru, Karnataka, India</p><a href="https://www.linkedin.com/comm/jobs/view/3900000001?x=2">View job</a></td></tr>
    <tr><td><a href="https://www.linkedin.com/comm/jobs/view/3900000002?x=1">Embedded Engineer</a><p>ChipCo · Bengaluru</p></td></tr>
    <tr><td><a href="https://www.linkedin.com/comm/jobs/search?x">See all jobs</a></td></tr></table>"""
    recs = parse_alert_message(_mail(html))
    assert [r["job_id"] for r in recs] == ["3900000001", "3900000002"]
    assert recs[0]["title"] == "Senior Python Developer" and recs[0]["company"] == "Acme Corp" and "Bengaluru" in recs[0]["location"]
    assert recs[0]["url"] == "https://www.linkedin.com/jobs/view/3900000001"  # tracking stripped


def test_imap_adapter_builds_jobs(http, monkeypatch):
    from jobwatch.sources.email_alerts import ImapAlertSource

    cfg = {"host": "h", "username": "me@x.test", "password": "pw", "assume_location": "Bengaluru"}
    src = ImapAlertSource("email_alerts:me", cfg, http)
    msg = _mail('<a href="https://www.naukri.com/job-listings-qa-engineer-acme-bengaluru-2-to-4-years-070725000111">QA Engineer</a><p>Acme</p>', sender="alerts@naukri.com")
    monkeypatch.setattr(src, "fetch_messages", lambda: [msg])
    jobs = src.fetch()
    assert len(jobs) == 1 and jobs[0].external_id == "naukri:070725000111" and jobs[0].extra["via"] == "naukri"
    assert jobs[0].extra["location_assumed"] and jobs[0].location == "Bengaluru"


def test_imap_validate_requires_password():
    from jobwatch.sources.email_alerts import ImapAlertSource

    assert any("password" in p for p in ImapAlertSource.validate({"host": "h", "username": "u"}))


# ---------------------------------------------------------------- registry
def test_build_sources_reports_all_problems_at_once(http):
    with pytest.raises(ConfigError) as ei:
        build_sources([{"type": "greenhouse"}, {"type": "nope"}, {"type": "htmllist", "url": "x"}], http)
    msg = str(ei.value)
    assert "board" in msg and "unknown type" in msg and "item_selector" in msg


def test_build_sources_skips_disabled_and_rejects_duplicates(http):
    ok = build_sources([{"type": "greenhouse", "board": "a", "enabled": False}, {"type": "greenhouse", "board": "b"}], http, min_interval=60)
    assert [s.name for s in ok] == ["greenhouse:b"] and ok[0].interval >= 60
    with pytest.raises(ConfigError, match="duplicate"):
        build_sources([{"type": "greenhouse", "board": "b"}, {"type": "greenhouse", "board": "b"}], http)
