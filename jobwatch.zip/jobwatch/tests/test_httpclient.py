import pytest

from jobwatch.models import NotModified, SourceBlocked, SourceError, SourceNotFound


def test_retries_5xx_with_exponential_backoff_then_succeeds(server, http):
    calls = {"n": 0}

    def flaky(rec):
        calls["n"] += 1
        return (503, "busy", {}) if calls["n"] < 3 else (200, {"ok": True}, {})

    server.on_fn("GET", "/x", flaky)
    assert http.get_json(server.base + "/x") == {"ok": True}
    assert calls["n"] == 3
    # backoff_base=1: attempt 0 → 1s (+≤25% jitter), attempt 1 → 2s (+≤25% jitter)
    assert len(http.sleeps) == 2
    assert 1.0 <= http.sleeps[0] <= 1.25 and 2.0 <= http.sleeps[1] <= 2.5


def test_gives_up_after_max_retries(server, http):
    server.on("GET", "/x", 500, "boom")
    with pytest.raises(SourceError, match="Giving up"):
        http.get(server.base + "/x")
    assert len(server.hits("/x")) == 4  # 1 + max_retries(3)


def test_429_honours_retry_after(server, http):
    n = {"c": 0}

    def limited(rec):
        n["c"] += 1
        return (429, "slow", {"Retry-After": "7"}) if n["c"] == 1 else (200, {"ok": 1}, {})

    server.on_fn("GET", "/x", limited)
    http.get(server.base + "/x")
    assert 7.0 in http.sleeps


def test_404_and_403_are_not_retried(server, http):
    server.on("GET", "/gone", 404, "no")
    server.on("GET", "/blocked", 403, "no")
    with pytest.raises(SourceNotFound):
        http.get(server.base + "/gone")
    with pytest.raises(SourceBlocked):
        http.get(server.base + "/blocked")
    assert len(server.hits("/gone")) == 1 and len(server.hits("/blocked")) == 1


def test_connection_refused_is_retried_then_reported(http):
    with pytest.raises(SourceError, match="Giving up"):
        http.get("http://127.0.0.1:9/never")  # port 9 (discard) is closed


def test_invalid_json_raises_source_error(server, http):
    server.on("GET", "/j", 200, "<html>not json</html>")
    with pytest.raises(SourceError, match="not valid JSON"):
        http.get_json(server.base + "/j")


def test_conditional_get_uses_etag_and_raises_not_modified(server, http):
    def page(rec):
        if rec["headers"].get("If-None-Match") == '"v1"':
            return 304, "", {}
        return 200, "hello", {"ETag": '"v1"'}

    server.on_fn("GET", "/p", page)
    assert http.get(server.base + "/p", conditional=True).text == "hello"
    with pytest.raises(NotModified):
        http.get(server.base + "/p", conditional=True)


def test_robots_txt_respected(server, db):
    from jobwatch.httpclient import HttpClient

    server.on("GET", "/robots.txt", 200, "User-agent: *\nDisallow: /private\n")
    server.on("GET", "/private/jobs", 200, "secret")
    server.on("GET", "/public", 200, "ok")
    client = HttpClient(min_host_interval=0, respect_robots=True, db=db)
    with pytest.raises(SourceBlocked, match="robots.txt"):
        client.get(server.base + "/private/jobs", check_robots=True)
    assert client.get(server.base + "/public", check_robots=True).text == "ok"
    assert not server.hits("/private/jobs")  # never requested
