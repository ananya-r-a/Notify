import email
import json
from email import policy

import pytest

from jobwatch.notify import NotificationService, build_notifiers
from jobwatch.notify.base import NotifyError
from jobwatch.notify.desktop import DesktopNotifier
from jobwatch.notify.mailer import EmailNotifier
from jobwatch.notify.ntfy import NtfyNotifier
from jobwatch.notify.telegram import TelegramNotifier
from jobwatch.notify.whatsapp import WhatsAppNotifier, normalise_number

JOB = {
    "uid": "greenhouse:acme|1", "title": "Senior <Python> Developer & Co", "company": "Acme", "location": "Bengaluru", "work_mode": "hybrid",
    "exp_min": 3.0, "exp_max": 5.0, "exp_inferred": 0, "score": 82.4, "source": "greenhouse:acme", "posted_at": "2026-11-17T10:00:00+00:00",
    "discovered_at": "2026-11-18T04:00:00+00:00", "url": "https://boards.example/acme/1", "apply_url": "https://boards.example/acme/1/apply",
    "salary_text": "₹18-28 LPA", "skills_required": ["python", "aws"], "score_breakdown": {"title": 1.0, "skills": 0.9, "location": 1.0}, "priority": 1,
}
nosleep = lambda s: None  # noqa: E731


def tg(server, **over):
    cfg = {"bot_token": "123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456", "chat_id": "42", "api_base": server.base, **over}
    return TelegramNotifier(cfg, sleep=nosleep)


# ---------------------------------------------------------------- telegram
def test_telegram_job_message_has_fields_escaping_and_buttons(server):
    server.on("POST", "/bot123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456/sendMessage", 200, {"ok": True, "result": {}})
    tg(server).send_job(JOB, priority=True)
    body = json.loads(server.requests[0]["body"])
    text = body["text"]
    assert body["chat_id"] == "42" and body["parse_mode"] == "HTML"
    for needle in ("Acme", "Bengaluru", "3-5 yrs", "82/100", "greenhouse:acme", "2026-11-17", "PRIORITY", "₹18-28 LPA"):
        assert needle in text
    assert "&lt;Python&gt;" in text and "&amp; Co" in text and "<Python>" not in text  # HTML-escaped
    buttons = body["reply_markup"]["inline_keyboard"][0]
    assert [b["url"] for b in buttons] == [JOB["url"], JOB["apply_url"]]


def test_telegram_multiple_chat_ids(server):
    server.on("POST", "/bot123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456/sendMessage", 200, {"ok": True})
    tg(server, chat_id="1, 2").send_text("t", "b")
    assert [json.loads(r["body"])["chat_id"] for r in server.requests] == ["1", "2"]


def test_telegram_api_error_is_permanent_and_token_not_leaked(server):
    path = "/bot123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456/sendMessage"
    server.on("POST", path, 400, {"ok": False, "error_code": 400, "description": "Bad Request: chat not found"})
    with pytest.raises(NotifyError, match="chat not found") as ei:
        tg(server).send_text("t", "b")
    assert len(server.requests) == 1  # permanent → no retry
    assert "ABCDEFGHIJKLMNOP" not in str(ei.value)


def test_telegram_retries_transient_and_rate_limit(server):
    path = "/bot123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456/sendMessage"
    n = {"c": 0}

    def flaky(rec):
        n["c"] += 1
        if n["c"] == 1:
            return 502, "bad gateway", {}
        if n["c"] == 2:
            return 429, {"ok": False, "error_code": 429, "description": "Too Many Requests", "parameters": {"retry_after": 1}}, {}
        return 200, {"ok": True}, {}

    server.on_fn("POST", path, flaky)
    tg(server).send_text("t", "b")
    assert n["c"] == 3


def test_telegram_get_me_and_chat_discovery(server):
    base = "/bot123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456"
    server.on("POST", base + "/getMe", 200, {"ok": True, "result": {"username": "jw_bot", "first_name": "JW"}})
    server.on("POST", base + "/getUpdates", 200, {"ok": True, "result": [{"message": {"chat": {"id": 777, "type": "private", "first_name": "Asha"}}}]})
    n = tg(server)
    assert n.get_me()["username"] == "jw_bot"
    assert n.discover_chat_ids() == [("777", "private: Asha")]


def test_telegram_network_failure_is_transient_error():
    n = TelegramNotifier({"bot_token": "1:" + "a" * 30, "chat_id": "1", "api_base": "http://127.0.0.1:9"}, sleep=nosleep)
    with pytest.raises(NotifyError, match="network error"):
        n.send_text("t", "b")


# ---------------------------------------------------------------- email
def smtp_notifier(smtp, **over):
    cfg = {"host": "127.0.0.1", "port": smtp.port, "security": "none", "username": "u", "password": "p", "sender": "jobwatch@x.test",
           "to": "me@x.test, you@x.test", "subject_prefix": "[JW]", **over}
    return EmailNotifier(cfg, sleep=nosleep)


def test_email_job_alert_is_multipart_html(smtp):
    smtp_notifier(smtp).send_job(JOB, priority=True)
    assert len(smtp.messages) == 1 and smtp.logins
    msg = email.message_from_bytes(smtp.messages[0], policy=policy.default)
    assert msg["Subject"].startswith("[JW] 🔥 PRIORITY: Senior <Python> Developer") and "82/100" in msg["Subject"]
    assert "me@x.test" in msg["To"] and "you@x.test" in msg["To"]
    html = msg.get_body(preferencelist=("html",)).get_content()
    plain = msg.get_body(preferencelist=("plain",)).get_content()
    assert "&lt;Python&gt;" in html and "Apply now" in html and JOB["apply_url"] in html and "Skills" in html
    assert "Company: Acme" in plain and "Apply: " + JOB["apply_url"] in plain


def test_email_digest_and_failure_notice(smtp):
    n = smtp_notifier(smtp)
    n.send_digest([JOB, {**JOB, "title": "Other", "uid": "u2"}], "Daily summary")
    n.send_text("Source failing: x", "5 consecutive failures")
    assert len(smtp.messages) == 2
    d = email.message_from_bytes(smtp.messages[0], policy=policy.default)
    assert "Daily summary" in d["Subject"] and "Other" in d.get_body(preferencelist=("html",)).get_content()


def test_email_connection_failure_reported():
    n = EmailNotifier({"host": "127.0.0.1", "port": 9, "security": "none", "username": "", "password": "x", "sender": "a@b.c", "to": "d@e.f"}, sleep=nosleep)
    with pytest.raises(NotifyError, match="SMTP connection"):
        n.send_text("t", "b")


def test_email_missing_settings_listed():
    assert set(EmailNotifier({"host": "h"}).missing()) == {"username", "password", "sender", "to"}


# ---------------------------------------------------------------- whatsapp
def wa(server, **over):
    cfg = {"provider": "cloud", "to": "+91 98765-43210", "cloud": {"access_token": "EAAGsecrettokenvalue", "phone_number_id": "555", "api_base": server.base,
           "api_version": "v21.0", "mode": "template", "template_name": "job_alert", "template_language": "en"},
           "twilio": {"account_sid": "ACxxxxxxxx", "auth_token": "tw-token-secret", "from_number": "whatsapp:+14155238886", "api_base": server.base}, **over}
    return WhatsAppNotifier(cfg, sleep=nosleep)


def test_whatsapp_number_normalisation():
    assert normalise_number("+91 98765-43210") == "919876543210" and normalise_number("0091 98765 43210") == "919876543210"


def test_whatsapp_cloud_template_payload(server):
    server.on("POST", "/v21.0/555/messages", 200, {"messages": [{"id": "wamid.1"}]})
    wa(server).send_job(JOB, priority=True)
    req = server.requests[0]
    assert req["headers"]["Authorization"] == "Bearer EAAGsecrettokenvalue"
    body = json.loads(req["body"])
    assert body["to"] == "919876543210" and body["messaging_product"] == "whatsapp" and body["type"] == "template"
    params = [p["text"] for p in body["template"]["components"][0]["parameters"]]
    assert len(params) == 6 and params[1] == "Acme" and params[4] == "82" and params[5] == JOB["apply_url"]
    assert all("\n" not in p for p in params)


def test_whatsapp_cloud_error_surface_and_secret_hidden(server):
    server.on("POST", "/v21.0/555/messages", 400, {"error": {"code": 132001, "message": "Template name does not exist"}})
    with pytest.raises(NotifyError, match="132001"):
        wa(server).send_job(JOB)
    assert len(server.requests) == 1


def test_whatsapp_template_mode_refuses_free_text(server):
    with pytest.raises(NotifyError, match="template mode"):
        wa(server).send_text("t", "b")


def test_whatsapp_text_mode(server):
    server.on("POST", "/v21.0/555/messages", 200, {"messages": [{"id": "x"}]})
    n = wa(server)
    n.cfg["cloud"]["mode"] = "text"
    n.send_job(JOB)
    assert json.loads(server.requests[0]["body"])["text"]["body"].startswith("🔔")


def test_whatsapp_twilio(server):
    server.on("POST", "/2010-04-01/Accounts/ACxxxxxxxx/Messages.json", 201, {"sid": "SM1"})
    wa(server, provider="twilio").send_job(JOB)
    req = server.requests[0]
    assert req["headers"]["Authorization"].startswith("Basic ")
    form = dict(p.split("=", 1) for p in req["body"].decode().split("&"))
    assert form["To"] == "whatsapp%3A%2B919876543210" and form["From"] == "whatsapp%3A%2B14155238886"


def test_whatsapp_twilio_error(server):
    server.on("POST", "/2010-04-01/Accounts/ACxxxxxxxx/Messages.json", 400, {"code": 63007, "message": "no channel"})
    with pytest.raises(NotifyError, match="63007"):
        wa(server, provider="twilio").send_job(JOB)


def test_whatsapp_missing_config_per_provider():
    assert "cloud.access_token" in WhatsAppNotifier({"provider": "cloud", "to": "1", "cloud": {}}).missing()
    assert "twilio.auth_token" in WhatsAppNotifier({"provider": "twilio", "to": "1", "twilio": {}}).missing()


# ---------------------------------------------------------------- ntfy / desktop
def test_ntfy_publish(server):
    server.on("POST", "/", 200, {"id": "x"})
    NtfyNotifier({"server": server.base, "topic": "t0pic", "token": "tk_secret_value"}, sleep=nosleep).send_job(JOB, priority=True)
    body = json.loads(server.requests[0]["body"])
    assert body["topic"] == "t0pic" and body["priority"] == 5 and body["click"] == JOB["apply_url"]
    assert server.requests[0]["headers"]["Authorization"] == "Bearer tk_secret_value"


def test_desktop_uses_available_backend(monkeypatch):
    calls = []
    monkeypatch.setattr("jobwatch.notify.desktop._backend", lambda: "notify-send")
    monkeypatch.setattr("jobwatch.notify.desktop.subprocess.run", lambda cmd, **kw: calls.append(cmd))
    DesktopNotifier({}).send_job(JOB, priority=True)
    assert calls[0][0] == "notify-send" and "critical" in calls[0] and any("Senior" in a for a in calls[0])


def test_desktop_unavailable_reports_not_configured(monkeypatch):
    monkeypatch.setattr("jobwatch.notify.desktop._backend", lambda: None)
    n = DesktopNotifier({})
    assert not n.is_configured()
    with pytest.raises(NotifyError):
        n.send_text("t", "b")


# ---------------------------------------------------------------- service
class Recorder:
    def __init__(self, name, fail=False, configured=True):
        self.name, self.fail, self.sent, self.cfg = name, fail, [], {}
        self._configured = configured

    def is_configured(self): return self._configured
    def missing(self): return [] if self._configured else ["x"]

    def send_job(self, job, priority=False):
        if self.fail:
            raise NotifyError("down")
        self.sent.append(job["uid"])

    def send_text(self, title, body, url=""):
        if self.fail:
            raise NotifyError("down")
        self.sent.append(title)

    def send_digest(self, jobs, title):
        self.send_text(title, "")


def stored(db, uid="s|1", **kw):
    row = dict(uid=uid, source="s", platform="p", external_id=uid.split("|")[1], title="T", company="C", discovered_at="2026-11-18T00:00:00+00:00",
               last_seen_at="2026-11-18T00:00:00+00:00", matched=1, score=80)
    row.update(kw)
    db.insert_job(row)
    return db.get_job(uid)


def test_service_partial_failure_marks_notified_and_never_resends_ok_channels(db):
    a, b = Recorder("a"), Recorder("b", fail=True)
    svc = NotificationService(db, {"a": a, "b": b}, {"job": ["a", "b"], "priority": ["a", "b"]})
    job = stored(db)
    assert svc.notify_job(job) is True
    assert db.get_job("s|1")["notified_at"] and a.sent == ["s|1"]
    b.fail = False
    svc.notify_job(db.get_job("s|1"))  # retry: 'a' must not be re-sent, 'b' now delivers
    assert a.sent == ["s|1"] and b.sent == ["s|1"]


def test_service_all_channels_fail_increments_attempts_and_leaves_pending(db):
    svc = NotificationService(db, {"a": Recorder("a", fail=True)}, {"job": ["a"], "priority": ["a"]})
    job = stored(db)
    assert svc.notify_job(job) is False
    row = db.get_job("s|1")
    assert row["notified_at"] is None and row["notify_attempts"] == 1
    assert [j["uid"] for j in db.pending_notifications(10, 5)] == ["s|1"]
    assert [j["uid"] for j in db.pending_notifications(10, 1)] == []  # attempts exhausted


def test_service_whatsapp_only_for_priority_and_unconfigured_skipped(db):
    wa_, tg_, bad = Recorder("whatsapp"), Recorder("telegram"), Recorder("email", configured=False)
    svc = NotificationService(db, {"whatsapp": wa_, "telegram": tg_, "email": bad}, {"job": ["telegram", "whatsapp", "email"], "priority": ["telegram", "whatsapp"]})
    svc.notify_job(stored(db, "s|1", priority=0))
    svc.notify_job(stored(db, "s|2", priority=1))
    assert wa_.sent == ["s|2"] and tg_.sent == ["s|1", "s|2"]


def test_service_test_reports_each_channel(server, smtp):
    server.on("POST", "/bot1:" + "a" * 30 + "/sendMessage", 200, {"ok": True})
    notifiers = build_notifiers({
        "telegram": {"enabled": True, "bot_token": "1:" + "a" * 30, "chat_id": "1", "api_base": server.base},
        "email": {"enabled": True, "host": "127.0.0.1", "port": smtp.port, "security": "none", "username": "u", "password": "p", "sender": "a@b.c", "to": "d@e.f"},
        "whatsapp": {"enabled": True, "provider": "cloud", "to": "", "cloud": {}},
        "ntfy": {"enabled": False},
    }, sleep=nosleep)
    res = NotificationService(None, notifiers, {}).test()
    assert res["telegram"] == "ok" and res["email"] == "ok" and res["whatsapp"].startswith("NOT CONFIGURED")
    assert len(smtp.messages) == 2 and len(server.requests) == 2  # text + sample job each
