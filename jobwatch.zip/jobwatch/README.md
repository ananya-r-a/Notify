# JobWatch: real-time job monitor with instant alerts

JobWatch watches job sources continuously, scores every posting against **your** criteria (Bengaluru by default),
and pushes the new matches to Telegram / e-mail / WhatsApp / desktop / mobile within minutes of them appearing.
It runs as a background service, stores everything in SQLite (survives restarts), and has a web dashboard.

> **Read section 20 before relying on it.** Some of the sources you listed (LinkedIn, Naukri, Indeed, …) have no public
> API and forbid scraping, so JobWatch reads *their alert e-mails* instead of scraping them. What was and was not verified is spelled out below.

## Contents
1 [Overview](#1-project-overview) · 2 [Features](#2-features) · 3 [Architecture](#3-architecture) · 4 [Tech stack](#4-technology-stack) · 5 [Prerequisites](#5-prerequisites) ·
6 [Install](#6-installation) · 7 [Python env](#7-python-environment) · 8 [Telegram](#8-telegram-bot-configuration) · 9 [E-mail](#9-e-mail-configuration) · 10 [WhatsApp](#10-whatsapp-api-configuration) ·
11 [Add sources](#11-adding-job-sources) · 12 [Company pages](#12-adding-company-career-pages) · 13 [Preferences](#13-configuring-job-preferences) · 14 [Run](#14-running-the-monitoring-service) ·
15 [Dashboard](#15-accessing-the-dashboard) · 16 [Tests](#16-running-tests) · 17 [Troubleshooting](#17-troubleshooting) · 18 [Deploy](#18-deployment) · 19 [Security](#19-security-recommendations) · 20 [Limitations](#20-known-source-integration-limitations)

---

## 1. Project overview
Polls each configured source on its own interval → normalises every posting → scores it → detects **new / updated / expired** jobs →
sends alerts. A failing source never blocks the others; failed alerts are retried; nothing is announced twice.

## 2. Features
| Requirement | Status |
|---|---|
| Continuous background service, independent of the dashboard | ✅ `python -m jobwatch run` |
| Per-source polling intervals, jitter, minimum interval guard | ✅ |
| Exponential backoff on failures (requests **and** per-source scheduling), `Retry-After` honoured | ✅ tested |
| Conditional requests (ETag / Last-Modified), per-host throttling, robots.txt for scraped pages | ✅ tested |
| Last successful run time persisted; schedule resumes after restart (no thundering herd) | ✅ tested |
| New-job detection, **updated description / apply-URL** detection, **expired/removed** detection | ✅ tested |
| Safeguards: an empty response never expires everything; expiry needs 3 consecutive misses | ✅ tested |
| Cross-source duplicate suppression (same company+title+city on *different* sources) | ✅ tested |
| Extraction: id, title, company, location, description, required/preferred skills, experience, employment type, work mode, salary (LPA), posted/discovered/deadline dates, apply + original URL, source, company page, status, score | ✅ |
| Filters: Bengaluru spellings, remote-India, role include/exclude, experience window, keywords, work mode, salary floor, max age, excluded companies | ✅ |
| 0-100 relevance score (title, skills, experience, location, recency, salary, company) with per-component breakdown | ✅ |
| Notifications: Telegram, e-mail (HTML, digest, priority, failure), WhatsApp (Meta Cloud API / Twilio), desktop, ntfy mobile push | ✅ each tested against local fake servers; **see §20 for what was not tested live** |
| First-run protection (one summary instead of hundreds of alerts), burst cap + digest | ✅ tested |
| Source health alerts (failure after N tries, recovery, auto-disable after repeated 404) | ✅ tested |
| Dashboard: search, filter, sort, status tracking, notes, score breakdown, source health, JSON API | ✅ tested |
| Assisted applications: cover-note + answers kit, link-out, "mark applied" | ✅ (assisted only; auto-submit is deliberately **not** built, see §20) |
| Secrets redacted from logs and error messages | ✅ tested |

## 3. Architecture
```
              ┌──────────────────────────── sources (independent adapters) ───────────────────────────┐
              │ greenhouse lever ashby smartrecruiters workable workday │ jsonld htmllist rss hn_hiring │ email_alerts (IMAP) │
              └───────────────┬───────────────────────────────────────────────────────────────────────┘
                              │ HttpClient: retries · backoff · throttle · ETag · robots.txt
        ┌─────────────────────▼──────────────────────┐
        │ Engine (thread pool, per-source schedule)  │◄── commands (run now / rescore) ◄── Dashboard
        │  fetch → Pipeline → store → flush alerts   │
        └───────┬─────────────────────────┬──────────┘
                │ Pipeline                │ NotificationService (routing, per-channel bookkeeping, retries)
   enrich(skills,exp,salary) → Matcher     └─► Telegram · E-mail · WhatsApp · Desktop · ntfy
   (filters + score) → new/updated/expired
                ▼
        SQLite (jobs, source_state, notifications, events, http_cache)  ◄── Flask dashboard + JSON API
```
Alerts are decoupled from fetching: a job is stored first, announced by a separate flusher, and stays pending until a channel confirms delivery, so a crash or an outage cannot lose an alert.

## 4. Technology stack
Python 3.10+ · `requests` · `beautifulsoup4` + `lxml` · `Flask` · `PyYAML` · `python-dotenv` · SQLite (WAL) · `pytest`. All free/open-source; no database server, no paid APIs except optional WhatsApp.

## 5. Prerequisites
* Python 3.10 or newer (developed on 3.13), `pip`, internet access.
* Optional: a Telegram account (free), a Gmail/other SMTP mailbox, a WhatsApp Business/Twilio account (paid), Docker.

## 6. Installation
```bash
git clone <your-copy-of-this-project> jobwatch && cd jobwatch      # or unzip it
python3 -m venv .venv && source .venv/bin/activate                 # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m jobwatch init            # creates config.yaml and .env from the examples
```

## 7. Python environment
`pip install -r requirements.txt` is all that is needed. Every command is `python -m jobwatch <command>`:

| Command | Purpose |
|---|---|
| `init` | create `config.yaml` + `.env` (never overwrites) |
| `check [--live]` | validate config, sources, channels; `--live` also fetches each source once (stores nothing) |
| `probe <source> [--all]` | fetch one source and show **why** each job matches/is rejected |
| `test-notify [--channel telegram]` | send real test messages |
| `telegram-id` | verify bot token and find your chat id |
| `run [--once] [--with-dashboard]` | start monitoring |
| `dashboard` | dashboard only |
| `sources` · `jobs -q python` · `rescore` · `digest` · `enable <source>` | status, listing, re-score after editing preferences, send summary now, re-enable an auto-disabled source |

## 8. Telegram bot configuration
Free and the fastest channel. Uses the official [Bot API](https://core.telegram.org/bots/api).
1. In Telegram open **@BotFather** → `/newbot` → pick a name and a username ending in `bot`. Copy the token (`123456:ABC…`).
2. Put it in `.env`: `TELEGRAM_BOT_TOKEN=…`
3. Open your new bot in Telegram and press **Start** (a bot cannot message you until you do).
4. Run `python -m jobwatch telegram-id`; it prints `chat_id = …`. Put it in `.env` as `TELEGRAM_CHAT_ID` (several ids can be comma-separated, e.g. you + a group).
5. In `config.yaml`: `notifications.telegram.enabled: true` → `python -m jobwatch test-notify --channel telegram`.

Each alert shows title, company, location, experience, score, source, date posted, and has **Open posting** and **Apply** buttons.

## 9. E-mail configuration
Gmail: enable 2-Step Verification, create an **App Password** (Google Account → Security → App passwords), then in `.env`:
`SMTP_HOST=smtp.gmail.com SMTP_PORT=465 SMTP_SECURITY=ssl SMTP_USER=you@gmail.com SMTP_PASSWORD=<app password> EMAIL_FROM=you@gmail.com EMAIL_TO=you@gmail.com`
(Other providers: change host/port; `SMTP_SECURITY=starttls` for port 587.) Enable with `notifications.email.enabled: true`, then `test-notify --channel email`.
Sends: individual HTML job alerts, 🔥 priority alerts, the daily summary (`engine.digest_time`), and source-failure notices (routed via `routing.system`).

## 10. WhatsApp API configuration
Official channels only (no unofficial libraries/automation). Two providers, **both need an account; sending is not free.**

**Cost facts (checked against [Meta's pricing page](https://developers.facebook.com/docs/whatsapp/pricing)):** Meta bills **per delivered message**, by category (marketing / utility / authentication) and by *recipient country*; India (+91) has its own rate card (not reproduced here, look it up in Meta's rate card). Each number gets 1,000 free *service* messages/month; per that page, service messages beyond it and utility messages inside the customer-service window become chargeable from **1 Oct 2026**. Meta decides a template's category, so you cannot assume a job alert will be priced as "utility". BSPs such as Twilio add their own per-message fee on top.

**A. Meta WhatsApp Business Cloud API (recommended for production)**
1. Create a Meta developer app + WhatsApp Business account, add a sending phone number, generate a **permanent system-user access token**.
2. Create and get approved a message template named `job_alert`, language `en`, body with six variables:
   `New job match: {{1}} at {{2}} ({{3}}). Experience: {{4}}. Relevance: {{5}}/100. Apply: {{6}}`
3. `.env`: `WHATSAPP_PROVIDER=cloud WHATSAPP_TO=91XXXXXXXXXX WHATSAPP_ACCESS_TOKEN=… WHATSAPP_PHONE_NUMBER_ID=… WHATSAPP_TEMPLATE_NAME=job_alert`
4. `notifications.whatsapp.enabled: true`. By default it only sends **priority** alerts (`only_priority: true`) to limit cost.
Template mode is required to message you outside the 24-hour window; `mode: text` sends free text but only inside that window.

**B. Twilio** (`WHATSAPP_PROVIDER=twilio`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM`).
The [Twilio sandbox](https://www.twilio.com/docs/whatsapp/sandbox) is free for testing only: from your phone send `join <your-code>` to the sandbox number (membership lasts 3 days).
**Limitation of this implementation:** the Twilio path sends free-form text, which WhatsApp only delivers inside the 24-hour window. It is therefore suitable for sandbox testing, not for unattended production alerts. For production use option A (templates) or Telegram/ntfy.

Failures are retried (transient errors with backoff) and surfaced; credentials never appear in logs.

## 11. Adding job sources
Add entries under `sources:` in `config.yaml` (or a `sources.yaml` listed in `sources_files`). See `sources.example.yaml` for every type.

| type | Use it for | Key fields |
|---|---|---|
| `greenhouse` · `lever` · `ashby` · `smartrecruiters` · `workable` · `workday` | any company whose careers page runs on that ATS (very common among startups, product and engineering companies) | `board` / `site` / `company_id` / `account` / `host+tenant+site` |
| `jsonld` | any careers page publishing schema.org `JobPosting` (Google-for-Jobs data) | `url`, optional `follow_links` + `link_selector` |
| `htmllist` | a listing page with no structured data (incl. government/PSU/R&D notification pages) | `url`, `item_selector`, `title_selector`, `location_selector` |
| `rss` | RSS/Atom feeds | `url`, optional `title_regex` |
| `hn_hiring` | startup hiring announcements (monthly "Who is hiring?") via the official HN API | `keywords` |
| `email_alerts` | **LinkedIn, Naukri, Indeed, Foundit, Instahyre, Cutshort, Wellfound, Work at a Startup** via your saved-search alert e-mails (read-only IMAP) | `host`, `username`, `password` |

Workflow for every new source: add it → `python -m jobwatch check --live` (does it fetch?) → `python -m jobwatch probe <name> --all` (are the right jobs matching?).
Each source can set `interval` (seconds, never below `engine.min_interval`=60), `company`, `assume_location`, `enabled`.

**Portals via alert e-mail:** create a saved search on each platform for your role + Bengaluru, set alerts to the most frequent option, point them at a mailbox you control
(Gmail: app password; IMAP enabled), and enable the `email_alerts` source. Freshness = the platform's alert frequency (`interval: 120` is how often *your mailbox* is checked).

## 12. Adding company career pages
1. Open the company's careers page and look at the job-detail URL: `boards.greenhouse.io/<x>`, `jobs.lever.co/<x>`, `jobs.ashbyhq.com/<x>`, `jobs.smartrecruiters.com/<X>`, `apply.workable.com/<x>`, `<x>.myworkdayjobs.com/<site>` → use that adapter with the id from the URL.
2. Otherwise view-source the page and search for `application/ld+json` + `JobPosting` → use `jsonld`.
3. Otherwise use `htmllist` with CSS selectors (browser dev-tools → copy selector). If the site is JavaScript-rendered you will see an empty list; look for the site's JSON endpoint in the Network tab or use its ATS.
4. Government/PSU/R&D bodies: use `htmllist` on the "current openings" page or `rss` if they publish a feed. Set `assume_location: Bengaluru` when the page omits it.
HTML-structure changes are handled loudly, not silently: if a page that had jobs suddenly returns zero, nothing is expired and a warning is shown on the dashboard.

## 13. Configuring job preferences
Everything lives under `preferences:` in `config.yaml` (fully commented in `config.example.yaml`): `locations`, `roles.priority/include/exclude`,
`skills.core/nice`, `keywords`, `experience.my_years` (or `min/max`; `unknown: allow|reject`), `work_modes`, `employment_types`, `salary_min_lpa`, `max_age_days`,
`exclude_companies`, `priority_companies`, `min_score` (35: notify at or above) and `priority_score` (70: priority channels incl. WhatsApp). Score weights are in `weights`.
After editing: `python -m jobwatch rescore` (or the dashboard button) re-evaluates stored jobs. Role defaults already cover software, IT/CS, data/ML, embedded/firmware, VLSI/semiconductor, automotive software (AUTOSAR/ADAS), R&D, DevOps, QA and security titles.
Experience when a posting doesn't state it: inferred from seniority words in the title (marked "inferred", slightly down-weighted) or treated as unknown (`allow` by default).

## 14. Running the monitoring service
```bash
python -m jobwatch check              # fix everything it reports
python -m jobwatch test-notify        # confirm you receive messages
python -m jobwatch run --with-dashboard
```
On the **first** poll of a source the existing jobs become a *baseline*; you get **one** summary message ("Initial scan: N matching jobs…") instead of a flood (`engine.first_run: summary|silent|notify`). After that, every newly posted match is announced individually, highest score first; more than `max_individual_per_flush` in one go are batched into a digest. Ctrl+C stops cleanly (press again to force).

## 15. Accessing the dashboard
`http://127.0.0.1:8765` (host/port via `dashboard:` or `DASHBOARD_HOST`/`DASHBOARD_PORT`). Search, filter (source, score, work mode, age, status), sort, open a job for the score breakdown, notes, status (new/saved/applied/interview/offer/rejected/ignored) and the **assisted application kit** (cover note from `profile.cover_note`, your saved answers, apply link). "Sources & health" shows last success, failures and recent events, and can trigger "poll all now" / "re-score". JSON: `/api/jobs`, `/api/stats`, `/api/sources`, `/healthz`.
It binds to localhost; binding elsewhere **requires** `DASHBOARD_TOKEN` (it refuses to start otherwise).

## 16. Running tests
```bash
python -m pytest tests -q          # 113 tests, ~45 s
```
Tests use real HTTP/SMTP sockets against local fake servers (Greenhouse, Lever, Telegram, WhatsApp, Twilio, ntfy, SMTP…) and a real subprocess run of the CLI, not mocks of this project's own code. They never contact the internet.

## 17. Troubleshooting
| Symptom | Fix |
|---|---|
| `check` says a channel is "missing: …" | fill the listed variable in `.env`; names map as in `.env.example` |
| Telegram: `chat not found` | press **Start** on the bot first; re-run `telegram-id` |
| Gmail: authentication failed | use an *App Password*, not your login password |
| Source auto-disabled "404" | wrong board/slug; fix it, `python -m jobwatch enable <source>` |
| Source `HTTP 403 / anti-bot` | the site blocks automated access: don't fight it; use its alert e-mails or its ATS |
| Matching jobs stored but no alerts | the log says "No notification channel…": run `check`; alerts stay pending and are sent once a channel works |
| Too many / too few alerts | `probe <source> --all` shows the reason per job; adjust `preferences`, then `rescore` |
| A page returns 0 jobs | JS-rendered page or changed layout; see §12 |
| Desktop pop-ups do nothing | they need a graphical session (`notify-send` on Linux); on servers use Telegram/ntfy |
Logs: console and `data/jobwatch.log` (rotating, secrets masked). `-v` for debug.

## 18. Deployment
* **Linux server (systemd):** `deploy/jobwatch.service` (edit user/paths). **Docker:** `docker compose up -d` (`Dockerfile`, `docker-compose.yml`; mounts `config.yaml`, uses `.env`, keeps data in a volume; dashboard published on 127.0.0.1 only).
* ⚠ **The systemd unit and the Docker image were written but not run in the build environment** (no Docker daemon / systemd there). The unit file passed `systemd-analyze` aside from install paths, and `docker-compose.yml` parses; expect to fix small things on first use.
* Desktop pop-ups need your own desktop session, so run it on your laptop/PC if you want them; a cheap VPS or always-on Raspberry Pi is better for 24×7 monitoring with Telegram/ntfy/e-mail.
* Expose the dashboard only behind HTTPS (e.g. Caddy/nginx reverse proxy) with `DASHBOARD_TOKEN` set.

## 19. Security recommendations
* Secrets only in `.env` (git-ignored); `config.yaml` references them as `${NAME}`. `chmod 600 .env`.
* Use app passwords (Gmail/IMAP), a dedicated mailbox for alerts, and a Meta system-user token with minimal scope. Rotate anything that leaks.
* The IMAP source opens the mailbox **read-only** and never marks/deletes mail.
* Dashboard: token required off-localhost, same-origin check on writes, HTML-escaped output, CSP and security headers. Put TLS in front.
* ntfy.sh topics are public-by-name: use a long random topic or a self-hosted server with a token.
* Respect each site's terms: JobWatch honours robots.txt on scraped pages, throttles per host, identifies itself, and never bypasses logins, CAPTCHAs or anti-bot systems.

## 20. Known source integration limitations
**What I could and could not verify.** The build environment had **no access to job sites or any real third-party service** (all outbound requests except package-registry/search tooling were blocked). Therefore:
* ✅ Verified: all code paths, over real HTTP/SMTP sockets, against local servers shaped like each provider's documented API (113 tests; mutation-checked on critical behaviours).
* ❌ **Not verified live:** no adapter has fetched a real company board, and no notification has reached a real Telegram/Gmail/WhatsApp account. Run `check --live` and `test-notify` on your machine; that is the real acceptance test. Treat everything below as "built from documentation, unproven against production".

| Source | How it is covered | Honest status / limits |
|---|---|---|
| **LinkedIn, Naukri, Indeed, Foundit, Instahyre, Cutshort, Wellfound** | `email_alerts`: reads *your own* saved-search alert e-mails | No public job-search API exists and their terms prohibit scraping, so **no direct scraping adapter is provided, deliberately**. Latency = their alert frequency (some only offer daily). The e-mail parser recognises each platform's job-link format and takes title/company/location from the text near the link; it was tested only on **synthetic** e-mails modelled on those formats. Real e-mail layouts change; if a platform's mails aren't parsed, run with `-v` and extend `PLATFORM_PATTERNS` in `sources/email_alerts.py`. |
| **Y Combinator – Work at a Startup** | `email_alerts` (WaaS alerts), `hn_hiring`, and the ATS boards of YC companies (most use Greenhouse/Lever/Ashby/Workable) | **No direct Work-at-a-Startup adapter**: it has no official API, and I could not inspect the site from the build environment. |
| Greenhouse | official Job Board API | schema confirmed from Greenhouse docs. The list endpoint has no `first_published`, so "date posted" is unknown for these jobs (the dashboard shows the discovery time). |
| Lever | official Postings API (incl. EU host) | field names from Lever's open-source docs/community write-ups. |
| Ashby | official public posting API | documented schema has no job `id`; the id is derived from `jobUrl`. |
| SmartRecruiters | official Posting API | list schema confirmed from docs; the **per-posting detail response shape (`jobAd.sections`, `postingUrl`, `applyUrl`) is not confirmed** by the docs I could read. If descriptions come back empty, check this first. Descriptions are fetched only for new postings (≤30 per run). |
| Workable | public widget endpoint | no official schema; fields read defensively from third-party documentation. |
| Workday | the JSON endpoint Workday's own career sites call | unofficial/undocumented and may change without notice; fails loudly, never silently. |
| Company career pages / startup portals | `jsonld`, `htmllist`, `rss` | only as good as the page: JS-rendered pages need their underlying JSON/ATS. No government portal is pre-configured (I could not verify any URL); add yours per §12. |
| Telegram / e-mail / ntfy / desktop | official APIs / SMTP / OS tools | desktop: Linux `notify-send`, macOS `osascript`, Windows PowerShell; only the Linux path is exercised by tests (mocked subprocess). |
| WhatsApp | Meta Cloud API templates; Twilio free-text | see §10 (cost, templates, 24-hour window, Twilio limitation). |

**Other limits:** "near-real-time" means ≤ your polling interval (default 5-10 min for ATS boards; lower `interval` to 60 s minimum). Experience/skills/salary come from heuristics over free text and can be wrong or absent, so use `probe` to audit them. Posting dates are unknown for some sources. **Automated one-click applying is intentionally not implemented:** the platforms prohibit it, and Greenhouse/Lever/Ashby expose application-submission APIs to employers only; JobWatch prepares the material and you submit on the official page.
